%% easir_example.m
% Demonstrates using the EASIR DLL from MATLAB via clib().
%
% Prerequisites:
%   1. Build the 'easir' DLL:
%        cmake --build build_vs --config Release --target easir
%   2. Run easir_define.m ONCE to generate the clib interface.
%   3. Vulkan SDK installed (vulkan-1.dll must be on PATH).
%   4. MATLAB R2022b or later.
%
% Usage:
%   >> cd('path/to/EASIR/matlab')
%   >> easir_define          % one-time: generates interface
%   >> easir_example         % runs this demo

%% --- 0. Setup ---
repo_root   = fullfile(fileparts(mfilename('fullpath')), '..');
config_path = fullfile(repo_root, 'configs', 'default_config.json');
state_path  = fullfile(repo_root, 'configs', 'default_state.json');

% Ensure the DLL directory is on the system PATH so MATLAB can find it.
dll_dir = fullfile(repo_root, 'build_vs', 'bin', 'Release');
if ~contains(getenv('PATH'), dll_dir)
    setenv('PATH', [dll_dir ';' getenv('PATH')]);
end

%% --- 1. Inspect defaults ---
def_cfg = jsondecode(clib.easir.easir_get_default_config());
def_st  = jsondecode(clib.easir.easir_get_default_state());

fprintf('Default config fields: %s\n', strjoin(fieldnames(def_cfg), ', '));
fprintf('Default state  fields: %s\n', strjoin(fieldnames(def_st), ', '));

%% --- 2. Build config ---
cfg = jsondecode(fileread(config_path));

% Set data_root so the DLL can find assets relative to the repo.
cfg.data_root = strrep(repo_root, '\', '/');

% Set render resolution.
cfg.camera.width  = 1280;
cfg.camera.height = 720;

config_json = jsonencode(cfg);

%% --- 3. Create renderer (headless — DLL mode) ---
handle = clib.easir.easir_create(config_json);
if handle == 0
    err = clib.easir.easir_get_last_error();
    error('easir_create failed: %s', err);
end
disp('Renderer created.');

%% --- 4. Set dynamic state ---
st = jsondecode(fileread(state_path));
st.camera_position    = [0; 0; 10];
st.camera_orientation = [0; 0; 0; 1];
st.sun_direction      = [0.7071; 0.7071; 0];

rc = clib.easir.easir_set_state(handle, jsonencode(st));
assert(rc == 0, 'easir_set_state failed: rc=%d', rc);

%% --- 5. Render ---
for i = 1:3
    rc = clib.easir.easir_render(handle);
    fprintf('  render frame %d: rc=%d\n', i, rc);
end

%% --- 6. Retrieve the rendered image ---
[rc, img_w, img_h, img_ch] = clib.easir.easir_get_image_info(handle);

if rc == 0
    fprintf('Image: %dx%d, %d channels (RGBA)\n', img_w, img_h, img_ch);

    % Allocate buffer and copy pixel data from the renderer.
    buf = zeros(img_w * img_h * img_ch, 1, 'uint8');
    rc = clib.easir.easir_get_image(handle, buf, int32(numel(buf)));

    % Reshape row-major RGBA to [H, W, C].
    img = reshape(buf, [img_ch, img_w, img_h]);
    img = permute(img, [3, 2, 1]);

    % Display RGB (drop alpha).
    figure('Name', 'EASIR Render');
    imshow(img(:,:,1:3));
    title(sprintf('EASIR — %dx%d', img_w, img_h));
    drawnow;

    % Save.
    out_path = fullfile(repo_root, 'easir_matlab_output.png');
    imwrite(img(:,:,1:3), out_path);
    fprintf('Saved: %s\n', out_path);
else
    warning('easir_get_image failed: %s', clib.easir.easir_get_last_error());
end

%% --- 7. Round-trip config/state ---
live_cfg = jsondecode(clib.easir.easir_get_config(handle));
disp('Round-trip config verified.');

%% --- 8. Cleanup ---
clib.easir.easir_destroy(handle);
disp('Done.');
