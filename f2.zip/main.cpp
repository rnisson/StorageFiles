/**
 * @file main.cpp
 * @brief Entry point for the easir_app standalone executable.
 *
 * Usage:
 *   easir_app [config.json] [state.json]
 *
 * Defaults:
 *   config.json -> configs/default_config.json
 *   state.json  -> configs/default_state.json
 */

#include <cmath>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <set>
#include <sstream>
#include <string>
#include <vector>

#include <vsg/all.h>

#include "easir/config.h"
#include "easir/state.h"
#include "easir/renderer.h"
#include "easir/trace.h"

namespace fs = std::filesystem;

// ---------------------------------------------------------------------------
// Keyboard handler — tracks which keys are currently held down.
// ---------------------------------------------------------------------------

class KeyTracker : public vsg::Inherit<vsg::Visitor, KeyTracker> {
public:
    std::set<vsg::KeySymbol> held;

    void apply(vsg::KeyPressEvent& e) override {
        held.insert(e.keyBase);
    }
    void apply(vsg::KeyReleaseEvent& e) override {
        held.erase(e.keyBase);
    }

    bool is_held(vsg::KeySymbol k) const { return held.count(k) > 0; }
};

// ---------------------------------------------------------------------------
// Quaternion helpers (for dev harness only)
// ---------------------------------------------------------------------------

/// Multiply two quaternions [x,y,z,w].
static std::array<double,4> qmul(const std::array<double,4>& a,
                                  const std::array<double,4>& b) {
    return {
        a[3]*b[0] + a[0]*b[3] + a[1]*b[2] - a[2]*b[1],
        a[3]*b[1] - a[0]*b[2] + a[1]*b[3] + a[2]*b[0],
        a[3]*b[2] + a[0]*b[1] - a[1]*b[0] + a[2]*b[3],
        a[3]*b[3] - a[0]*b[0] - a[1]*b[1] - a[2]*b[2],
    };
}

/// Construct a quaternion from axis (must be unit) and angle in radians.
static std::array<double,4> qfrom_axis_angle(double ax, double ay, double az, double angle) {
    double s = std::sin(angle * 0.5);
    return {ax * s, ay * s, az * s, std::cos(angle * 0.5)};
}

/// Normalize a quaternion.
static void qnormalize(std::array<double,4>& q) {
    double len = std::sqrt(q[0]*q[0] + q[1]*q[1] + q[2]*q[2] + q[3]*q[3]);
    if (len > 0.0) { q[0] /= len; q[1] /= len; q[2] /= len; q[3] /= len; }
}

// ---------------------------------------------------------------------------
// Utilities
// ---------------------------------------------------------------------------

/// Walk up from exe directory looking for a sibling "configs/" folder.
/// Returns the directory containing it, or empty path if not found.
static fs::path find_data_root(const fs::path& exe_path) {
    fs::path dir = exe_path.parent_path();
    for (int i = 0; i < 8; ++i) {  // up to 8 levels
        if (fs::is_directory(dir / "configs")) {
            return dir;
        }
        auto parent = dir.parent_path();
        if (parent == dir) break;  // filesystem root
        dir = parent;
    }
    return {};
}

static std::string read_file(const fs::path& path) {
    std::ifstream f(path);
    if (!f.is_open()) {
        throw std::runtime_error("Cannot open file: " + path.string());
    }
    std::ostringstream ss;
    ss << f.rdbuf();
    return ss.str();
}

// ---------------------------------------------------------------------------
// Main
// ---------------------------------------------------------------------------

int main(int argc, char* argv[]) {
    // --trace flag enables verbose DLL-side logging (console + easir_trace.log)
    std::vector<std::string> pos_args;
    for (int i = 1; i < argc; ++i) {
        if (std::strcmp(argv[i], "--trace") == 0) {
#ifdef _WIN32
            _putenv_s("EASIR_TRACE", "1");
#else
            setenv("EASIR_TRACE", "1", 1);
#endif
            std::cout << "[EASIR] Trace logging enabled\n";
        } else {
            pos_args.emplace_back(argv[i]);
        }
    }
    EASIR_TRACE_INIT();

    // Auto-detect data root by walking up from the executable location.
    fs::path data_root = find_data_root(fs::path(argv[0]));
    if (data_root.empty()) {
        // Fallback: try CWD
        data_root = fs::current_path();
    }

    fs::path config_path = data_root / "configs" / "default_config.json";
    fs::path state_path;

    if (pos_args.size() >= 1) {
        config_path = pos_args[0];
    }
    if (pos_args.size() >= 2) {
        state_path = pos_args[1];
    }

    // --- Load configuration ---
    easir::EasirConfig config{};
    try {
        if (fs::exists(config_path)) {
            std::string json = read_file(config_path);
            config = easir::config_from_json_string(json);
            std::cout << "[EASIR] Loaded config from: " << config_path << '\n';
        } else {
            std::cout << "[EASIR] Config file not found (" << config_path
                      << "), using defaults.\n";
        }
    } catch (const std::exception& ex) {
        std::cerr << "[EASIR] Config error: " << ex.what() << '\n';
        return 1;
    }

    // Set data_root so the renderer can resolve relative asset paths.
    if (config.data_root.empty()) {
        config.data_root = data_root.string();
        std::cout << "[EASIR] Data root: " << config.data_root << '\n';
    }

    // --- Load initial state ---
    easir::EasirState state{};
    if (state_path.empty()) {
        state_path = data_root / "configs" / "default_state.json";
    }
    try {
        if (fs::exists(state_path)) {
            std::string json = read_file(state_path);
            state = easir::state_from_json_string(json);
            std::cout << "[EASIR] Loaded state from: " << state_path << '\n';
        } else {
            std::cout << "[EASIR] No state file found, using defaults.\n";
        }
    } catch (const std::exception& ex) {
        std::cerr << "[EASIR] State error: " << ex.what() << '\n';
        return 1;
    }

    // --- Create renderer in windowed mode ---
    std::unique_ptr<easir::EasirRenderer> renderer;
    try {
        renderer = std::make_unique<easir::EasirRenderer>(config, easir::RenderMode::Windowed);
        renderer->set_state(state);
    } catch (const std::exception& ex) {
        std::cerr << "[EASIR] Renderer init error: " << ex.what() << '\n';
        return 1;
    }

    // Register the keyboard tracker with the viewer.
    auto keys = KeyTracker::create();
    renderer->viewer()->addEventHandler(keys);

    std::cout << "[EASIR] Entering render loop. Close the window to exit.\n";
    std::cout << "[EASIR] Keys: Q/W = rotate X, A/S = rotate Y, Z/X = rotate Z, K/L = translate Z\n";

    constexpr double rot_speed = 0.02;  // radians per frame
    constexpr double move_speed = 0.1;  // metres per frame

    // --- Render loop ---
    while (renderer->render()) {
        // Apply keyboard-driven rotation to the first scene object.
        if (!state.scene_objects.empty()) {
            auto& q = state.scene_objects.front().orientation;
            bool changed = false;

            if (keys->is_held(vsg::KEY_q)) {
                q = qmul(qfrom_axis_angle(1,0,0, rot_speed), q);
                changed = true;
            }
            if (keys->is_held(vsg::KEY_w)) {
                q = qmul(qfrom_axis_angle(1,0,0, -rot_speed), q);
                changed = true;
            }
            if (keys->is_held(vsg::KEY_a)) {
                q = qmul(qfrom_axis_angle(0,1,0, rot_speed), q);
                changed = true;
            }
            if (keys->is_held(vsg::KEY_s)) {
                q = qmul(qfrom_axis_angle(0,1,0, -rot_speed), q);
                changed = true;
            }
            if (keys->is_held(vsg::KEY_z)) {
                q = qmul(qfrom_axis_angle(0,0,1, rot_speed), q);
                changed = true;
            }
            if (keys->is_held(vsg::KEY_x)) {
                q = qmul(qfrom_axis_angle(0,0,1, -rot_speed), q);
                changed = true;
            }

            // K/L = translate along Z (camera look direction).
            auto& pos = state.scene_objects.front().position;
            if (keys->is_held(vsg::KEY_k)) {
                pos[2] -= move_speed;  // toward camera
                changed = true;
            }
            if (keys->is_held(vsg::KEY_l)) {
                pos[2] += move_speed;  // away from camera
                changed = true;
            }

            if (changed) {
                qnormalize(q);
                renderer->set_state(state);
            }
        }
    }

    std::cout << "[EASIR] Render loop exited cleanly.\n";
    return 0;
}
