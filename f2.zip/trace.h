#pragma once
/**
 * @file trace.h
 * @brief Crash-safe diagnostic tracing for the EASIR DLL.
 *
 * Writes to easir_trace.log next to the DLL and optionally opens a
 * visible console window.  Every line is flushed immediately so the
 * log survives crashes.
 *
 * Enable at runtime by setting the environment variable EASIR_TRACE=1
 * before loading the DLL (or before calling easir_create).
 *
 * Usage:
 *   EASIR_TRACE_INIT();          // call once (idempotent)
 *   EASIR_TRACE("step %d", 42); // printf-style, auto-flushed + newline
 */

#include <cstdio>
#include <cstdarg>
#include <cstdlib>

#ifdef _WIN32
#  ifndef WIN32_LEAN_AND_MEAN
#    define WIN32_LEAN_AND_MEAN
#  endif
#  include <windows.h>
#endif

namespace easir { namespace trace {

inline FILE*& log_file() { static FILE* f = nullptr; return f; }
inline bool&  inited()   { static bool  v = false;   return v; }

inline bool enabled() {
    static int cached = -1;
    if (cached < 0) {
        const char* env = std::getenv("EASIR_TRACE");
        cached = (env && env[0] == '1') ? 1 : 0;
    }
    return cached == 1;
}

inline void init() {
    if (inited()) return;
    inited() = true;
    if (!enabled()) return;

#ifdef _WIN32
    // Open a visible console window so the user can see output in real time.
    if (AllocConsole()) {
        // Redirect stdout/stderr to the new console.
        FILE* dummy = nullptr;
        freopen_s(&dummy, "CONOUT$", "w", stdout);
        freopen_s(&dummy, "CONOUT$", "w", stderr);
    }

    // Place the log file next to the DLL.
    char dll_path[MAX_PATH] = {};
    HMODULE hm = nullptr;
    GetModuleHandleExA(
        GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
        reinterpret_cast<LPCSTR>(&init), &hm);
    GetModuleFileNameA(hm, dll_path, MAX_PATH);
    // Replace "easir.dll" with "easir_trace.log"
    char* last_sep = strrchr(dll_path, '\\');
    if (!last_sep) last_sep = strrchr(dll_path, '/');
    if (last_sep) {
        *(last_sep + 1) = '\0';
        strcat_s(dll_path, "easir_trace.log");
    } else {
        strcpy_s(dll_path, "easir_trace.log");
    }
    fopen_s(&log_file(), dll_path, "w");
#else
    log_file() = fopen("easir_trace.log", "w");
#endif

    if (log_file()) {
        fprintf(log_file(), "=== EASIR trace started ===\n");
        fflush(log_file());
    }
    fprintf(stdout, "[EASIR] Trace logging enabled — writing to easir_trace.log\n");
    fflush(stdout);
}

inline void log(const char* fmt, ...) {
    if (!enabled()) return;

    va_list args;
    va_start(args, fmt);

    // Write to log file
    if (log_file()) {
        va_list args2;
        va_copy(args2, args);
        vfprintf(log_file(), fmt, args2);
        fprintf(log_file(), "\n");
        fflush(log_file());
        va_end(args2);
    }

    // Also write to console (if allocated)
    vfprintf(stdout, fmt, args);
    fprintf(stdout, "\n");
    fflush(stdout);

    va_end(args);
}

}} // namespace easir::trace

#define EASIR_TRACE_INIT()    easir::trace::init()
#define EASIR_TRACE(fmt, ...) easir::trace::log(fmt, ##__VA_ARGS__)
