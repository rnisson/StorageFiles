/**
 * @file test_dll.cpp
 * @brief Minimal test harness that exercises the easir.dll C API.
 *
 * Usage:  easir_test_dll [config.json] [state.json]
 *
 * Exercises the same code path MATLAB would use:
 *   easir_create → easir_set_state → easir_render → easir_get_image → easir_destroy
 *
 * On success, writes "easir_test_output.bmp" next to the executable.
 */

#include "easir/easir_api.h"

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <string>
#include <vector>
#include <filesystem>

// ---------------------------------------------------------------------------
// Tiny BMP writer (no dependencies)
// ---------------------------------------------------------------------------
static bool write_bmp(const char* path, const unsigned char* rgba,
                      int width, int height) {
    const int row_bytes  = width * 3;
    const int pad        = (4 - (row_bytes % 4)) % 4;
    const int stride     = row_bytes + pad;
    const int pixel_size = stride * height;
    const int file_size  = 54 + pixel_size;

    unsigned char header[54] = {};
    // BM magic
    header[0] = 'B'; header[1] = 'M';
    // File size
    std::memcpy(&header[2],  &file_size,  4);
    // Pixel data offset
    int offset = 54;
    std::memcpy(&header[10], &offset,     4);
    // DIB header size
    int dib = 40;
    std::memcpy(&header[14], &dib,        4);
    std::memcpy(&header[18], &width,      4);
    std::memcpy(&header[22], &height,     4);
    short planes = 1, bpp = 24;
    std::memcpy(&header[26], &planes,     2);
    std::memcpy(&header[28], &bpp,        2);
    std::memcpy(&header[34], &pixel_size, 4);

    std::ofstream f(path, std::ios::binary);
    if (!f) return false;
    f.write(reinterpret_cast<const char*>(header), 54);

    // BMP stores rows bottom-to-top, as BGR.
    std::vector<unsigned char> row_buf(static_cast<size_t>(stride), 0);
    for (int y = height - 1; y >= 0; --y) {
        for (int x = 0; x < width; ++x) {
            const int src = (y * width + x) * 4;
            row_buf[static_cast<size_t>(x * 3 + 0)] = rgba[src + 2]; // B
            row_buf[static_cast<size_t>(x * 3 + 1)] = rgba[src + 1]; // G
            row_buf[static_cast<size_t>(x * 3 + 2)] = rgba[src + 0]; // R
        }
        f.write(reinterpret_cast<const char*>(row_buf.data()), stride);
    }
    return f.good();
}

// ---------------------------------------------------------------------------
// Helper: read entire file to string
// ---------------------------------------------------------------------------
static std::string read_file(const char* path) {
    std::ifstream f(path);
    if (!f) return {};
    return {std::istreambuf_iterator<char>(f), std::istreambuf_iterator<char>()};
}

// ---------------------------------------------------------------------------
// Helper: find data root by walking up from the exe directory
// ---------------------------------------------------------------------------
static std::string find_data_root() {
    namespace fs = std::filesystem;
    auto dir = fs::current_path();
    for (int i = 0; i < 6; ++i) {
        if (fs::exists(dir / "configs")) return dir.string();
        if (dir.has_parent_path() && dir.parent_path() != dir)
            dir = dir.parent_path();
        else break;
    }
    return {};
}

// ---------------------------------------------------------------------------
// Main
// ---------------------------------------------------------------------------
int main(int argc, char* argv[]) {
    // --trace flag enables verbose DLL-side logging (console + easir_trace.log)
    for (int i = 1; i < argc; ++i) {
        if (std::strcmp(argv[i], "--trace") == 0) {
#ifdef _WIN32
            _putenv_s("EASIR_TRACE", "1");
#else
            setenv("EASIR_TRACE", "1", 1);
#endif
            std::printf("[easir_test_dll] Trace logging enabled\n");
        }
    }

    std::printf("[easir_test_dll] EASIR DLL C-API test harness\n");

    // --- Introspection: default config/state -------------------------------
    std::printf("\n--- easir_get_default_config() ---\n");
    const char* def_cfg = easir_get_default_config();
    if (def_cfg) {
        std::printf("  (length %zu): %.200s...\n", std::strlen(def_cfg), def_cfg);
        easir_free_string(def_cfg);
    } else {
        std::printf("  ERROR: %s\n", easir_get_last_error());
    }

    std::printf("\n--- easir_get_default_state() ---\n");
    const char* def_st = easir_get_default_state();
    if (def_st) {
        std::printf("  (length %zu): %.200s...\n", std::strlen(def_st), def_st);
        easir_free_string(def_st);
    } else {
        std::printf("  ERROR: %s\n", easir_get_last_error());
    }

    // --- Load config -------------------------------------------------------
    // Collect positional args (skip --trace flag).
    std::vector<std::string> pos_args;
    for (int i = 1; i < argc; ++i) {
        if (std::strcmp(argv[i], "--trace") != 0)
            pos_args.emplace_back(argv[i]);
    }

    std::string data_root = find_data_root();
    std::string config_path = pos_args.size() > 0 ? pos_args[0] : data_root + "/configs/default_config.json";
    std::string state_path  = pos_args.size() > 1 ? pos_args[1] : data_root + "/configs/default_state.json";

    std::printf("\n--- Loading config: %s ---\n", config_path.c_str());
    std::string config_json = read_file(config_path.c_str());
    if (config_json.empty()) {
        std::printf("  WARNING: Could not read config, using defaults\n");
        config_json = "{}";
    }

    // Inject data_root into config so asset paths resolve.
    if (!data_root.empty() && config_json.find("\"data_root\"") == std::string::npos) {
        // Insert data_root as the first field after the opening brace.
        auto pos = config_json.find('{');
        if (pos != std::string::npos) {
            std::string injection = "\"data_root\": \"" + data_root + "\", ";
            // Escape backslashes for JSON.
            std::string escaped;
            for (char c : injection) {
                if (c == '\\') escaped += "\\\\";
                else escaped += c;
            }
            config_json.insert(pos + 1, escaped);
        }
    }

    // --- easir_create -------------------------------------------------------
    std::printf("\n--- easir_create() ---\n");
    EasirHandle h = easir_create(config_json.c_str());
    if (h == 0) {
        std::printf("  FAILED: %s\n", easir_get_last_error());
        return 1;
    }
    std::printf("  OK (handle = 0x%llx)\n", (unsigned long long)h);

    // --- easir_set_state ----------------------------------------------------
    std::printf("\n--- easir_set_state() ---\n");
    std::string state_json = read_file(state_path.c_str());
    if (state_json.empty()) {
        std::printf("  WARNING: Could not read state, using defaults\n");
        state_json = "{}";
    }
    int rc = easir_set_state(h, state_json.c_str());
    std::printf("  rc = %d\n", rc);

    // --- easir_render (3 frames to let the pipeline settle) -----------------
    std::printf("\n--- easir_render() x3 ---\n");
    for (int i = 0; i < 3; ++i) {
        rc = easir_render(h);
        std::printf("  frame %d: rc = %d\n", i, rc);
    }

    // --- easir_get_image ----------------------------------------------------
    std::printf("\n--- easir_get_image_info() + easir_get_image() ---\n");
    int w = 0, img_h = 0, ch = 0;
    rc = easir_get_image_info(h, &w, &img_h, &ch);
    std::printf("  info: rc = %d, %dx%d, %d channels\n", rc, w, img_h, ch);

    std::vector<unsigned char> img_buf;
    unsigned char* data = nullptr;
    if (rc == 0) {
        img_buf.resize(static_cast<size_t>(w) * img_h * ch);
        rc = easir_get_image(h, img_buf.data(), static_cast<int>(img_buf.size()));
        std::printf("  copy: rc = %d\n", rc);
        if (rc == 0) data = img_buf.data();
    }

    if (rc == 0 && data) {
        // Check if image is non-trivial (not all zeros).
        size_t total = static_cast<size_t>(w) * img_h * ch;
        size_t nonzero = 0;
        for (size_t i = 0; i < total; ++i) {
            if (data[i] != 0) ++nonzero;
        }
        std::printf("  Non-zero pixels: %zu / %zu bytes (%.1f%%)\n",
                    nonzero, total, 100.0 * nonzero / total);

        // Write BMP.
        std::string bmp_path = data_root.empty() ? "easir_test_output.bmp"
                                                  : data_root + "/easir_test_output.bmp";
        if (write_bmp(bmp_path.c_str(), data, w, img_h)) {
            std::printf("  Wrote: %s\n", bmp_path.c_str());
        } else {
            std::printf("  ERROR: Failed to write BMP\n");
        }
    }

    // --- easir_get_config / easir_get_state ----------------------------------
    std::printf("\n--- easir_get_config() ---\n");
    const char* cfg = easir_get_config(h);
    if (cfg) {
        std::printf("  (length %zu) OK\n", std::strlen(cfg));
        easir_free_string(cfg);
    }

    std::printf("\n--- easir_get_state() ---\n");
    const char* st = easir_get_state(h);
    if (st) {
        std::printf("  (length %zu) OK\n", std::strlen(st));
        easir_free_string(st);
    }

    // --- easir_destroy ------------------------------------------------------
    std::printf("\n--- easir_destroy() ---\n");
    easir_destroy(h);
    std::printf("  OK\n");

    std::printf("\n[easir_test_dll] All tests passed.\n");
    return 0;
}
