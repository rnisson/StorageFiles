#include "easir/easir_api.h"
#include "easir/renderer.h"
#include "easir/config.h"
#include "easir/state.h"
#include "easir/trace.h"

#include <memory>
#include <string>
#include <stdexcept>

// ---------------------------------------------------------------------------
// Thread-local buffers
// ---------------------------------------------------------------------------
static thread_local std::string g_last_error;
static thread_local std::string g_return_buf;

/// Store a string in thread-local storage and return a pointer that stays
/// valid until the next call to return_string() on the same thread.
static const char* return_string(std::string&& s) {
    g_return_buf = std::move(s);
    return g_return_buf.c_str();
}

static void set_last_error(const std::string& msg) {
    g_last_error = msg;
}

static EasirHandle make_null_handle(const std::string& reason) {
    set_last_error(reason);
    return 0;
}

static inline easir::EasirRenderer* handle_to_ptr(EasirHandle h) {
    return reinterpret_cast<easir::EasirRenderer*>(static_cast<uintptr_t>(h));
}

static inline EasirHandle ptr_to_handle(easir::EasirRenderer* p) {
    return static_cast<EasirHandle>(reinterpret_cast<uintptr_t>(p));
}

// ---------------------------------------------------------------------------
// Lifecycle
// ---------------------------------------------------------------------------

extern "C" EASIR_API EasirHandle easir_create(const char* config_json) {
    EASIR_TRACE_INIT();
    EASIR_TRACE("easir_create: enter");
    try {
        std::string json_str = (config_json && *config_json) ? config_json : "{}";
        EASIR_TRACE("easir_create: parsing config JSON (%zu bytes)", json_str.size());
        auto cfg = easir::config_from_json_string(json_str);
        EASIR_TRACE("easir_create: config parsed OK, creating renderer...");
        auto* renderer = new easir::EasirRenderer(cfg, easir::RenderMode::Headless);
        EASIR_TRACE("easir_create: renderer created OK, handle=%p", (void*)renderer);
        return ptr_to_handle(renderer);
    } catch (const std::exception& ex) {
        EASIR_TRACE("easir_create: EXCEPTION: %s", ex.what());
        return make_null_handle(ex.what());
    } catch (...) {
        EASIR_TRACE("easir_create: UNKNOWN EXCEPTION");
        return make_null_handle("easir_create: unknown exception");
    }
}

extern "C" EASIR_API void easir_destroy(EasirHandle handle) {
    if (!handle) {
        return;
    }
    delete handle_to_ptr(handle);
}

// ---------------------------------------------------------------------------
// State updates
// ---------------------------------------------------------------------------

extern "C" EASIR_API int easir_set_state(EasirHandle handle, const char* state_json) {
    EASIR_TRACE("easir_set_state: enter, handle=%llu", (unsigned long long)handle);
    if (!handle) {
        set_last_error("easir_set_state: null handle");
        return -1;
    }
    try {
        auto* r = handle_to_ptr(handle);
        std::string json_str = (state_json && *state_json) ? state_json : "{}";
        EASIR_TRACE("easir_set_state: parsing state JSON (%zu bytes)", json_str.size());
        auto state = easir::state_from_json_string(json_str);
        EASIR_TRACE("easir_set_state: state parsed OK, applying...");
        r->set_state(state);
        EASIR_TRACE("easir_set_state: done");
        return 0;
    } catch (const std::exception& ex) {
        EASIR_TRACE("easir_set_state: EXCEPTION: %s", ex.what());
        set_last_error(ex.what());
        return -1;
    } catch (...) {
        EASIR_TRACE("easir_set_state: UNKNOWN EXCEPTION");
        set_last_error("easir_set_state: unknown exception");
        return -1;
    }
}

// ---------------------------------------------------------------------------
// Rendering
// ---------------------------------------------------------------------------

extern "C" EASIR_API int easir_render(EasirHandle handle) {
    if (!handle) {
        set_last_error("easir_render: null handle");
        return -1;
    }
    try {
        auto* r = handle_to_ptr(handle);
        bool ok = r->render();
        return ok ? 0 : 1;  // 1 = viewer requested shutdown (not an error)
    } catch (const std::exception& ex) {
        set_last_error(ex.what());
        return -1;
    } catch (...) {
        set_last_error("easir_render: unknown exception");
        return -1;
    }
}

// ---------------------------------------------------------------------------
// Image output
// ---------------------------------------------------------------------------

extern "C" EASIR_API int easir_get_image_info(EasirHandle handle,
                                             int* width, int* height, int* channels) {
    if (!handle) {
        set_last_error("easir_get_image_info: null handle");
        return -1;
    }
    if (!width || !height || !channels) {
        set_last_error("easir_get_image_info: null output pointer");
        return -1;
    }
    auto* r = handle_to_ptr(handle);
    const uint8_t* buf = nullptr;
    bool ok = r->get_image(&buf, width, height, channels);
    if (!ok) {
        set_last_error("easir_get_image_info: no rendered image available yet");
        return -1;
    }
    return 0;
}

extern "C" EASIR_API int easir_get_image(EasirHandle handle,
                                        unsigned char* buffer,
                                        int            buf_size) {
    if (!handle) {
        set_last_error("easir_get_image: null handle");
        return -1;
    }
    if (!buffer) {
        set_last_error("easir_get_image: null buffer");
        return -1;
    }
    auto* r = handle_to_ptr(handle);
    const uint8_t* data = nullptr;
    int w = 0, h = 0, ch = 0;
    bool ok = r->get_image(&data, &w, &h, &ch);
    if (!ok) {
        set_last_error("easir_get_image: no rendered image available yet");
        return -1;
    }
    int required = w * h * ch;
    if (buf_size < required) {
        set_last_error("easir_get_image: buffer too small");
        return -1;
    }
    std::memcpy(buffer, data, static_cast<size_t>(required));
    return 0;
}

// ---------------------------------------------------------------------------
// Introspection
// ---------------------------------------------------------------------------

extern "C" EASIR_API const char* easir_get_config(EasirHandle handle) {
    if (!handle) {
        set_last_error("easir_get_config: null handle");
        return nullptr;
    }
    try {
        auto* r = handle_to_ptr(handle);
        return return_string(easir::config_to_json_string(r->config()));
    } catch (const std::exception& ex) {
        set_last_error(ex.what());
        return nullptr;
    }
}

extern "C" EASIR_API const char* easir_get_state(EasirHandle handle) {
    if (!handle) {
        set_last_error("easir_get_state: null handle");
        return nullptr;
    }
    try {
        auto* r = handle_to_ptr(handle);
        return return_string(easir::state_to_json_string(r->state()));
    } catch (const std::exception& ex) {
        set_last_error(ex.what());
        return nullptr;
    }
}

extern "C" EASIR_API const char* easir_get_default_config(void) {
    try {
        return return_string(easir::default_config_json());
    } catch (const std::exception& ex) {
        set_last_error(ex.what());
        return nullptr;
    }
}

extern "C" EASIR_API const char* easir_get_default_state(void) {
    try {
        return return_string(easir::default_state_json());
    } catch (const std::exception& ex) {
        set_last_error(ex.what());
        return nullptr;
    }
}

extern "C" EASIR_API void easir_free_string(const char* /*str*/) {
    // No-op: strings are now managed by thread-local storage.
}

// ---------------------------------------------------------------------------
// Error reporting
// ---------------------------------------------------------------------------

extern "C" EASIR_API const char* easir_get_last_error(void) {
    return g_last_error.c_str();
}
