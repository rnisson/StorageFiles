%% easir_define.m
% Generate and build the MATLAB clib() interface for the EASIR DLL.
%
% Run this script ONCE (or whenever the C API changes) to create the
% interface package that lets you call clib.easir.easir_create(...) etc.
%
% Prerequisites:
%   - MATLAB R2022b or later
%   - Vulkan SDK installed
%   - easir.dll built:  cmake --build build_vs --config Release --target easir
%
% After running this script, use easir_example.m to exercise the renderer.

%% --- Paths ---
repo_root   = fullfile(fileparts(mfilename('fullpath')), '..');
dll_path    = fullfile(repo_root, 'build_vs', 'bin', 'Release', 'easir.dll');
header_path = fullfile(repo_root, 'include', 'easir', 'easir_api.h');
import_lib  = fullfile(repo_root, 'build_vs', 'lib', 'Release', 'easir.lib');

if ~isfile(dll_path)
    error('easir:notFound', ...
        ['DLL not found at:\n  %s\n' ...
         'Build it first:\n' ...
         '  cmake --build build_vs --config Release --target easir'], ...
        dll_path);
end

%% --- Generate the clib interface ---
% This parses easir_api.h and creates a MATLAB interface package named
% 'easir'.  The EASIR_API macro resolves to empty when neither
% easir_EXPORTS nor any build macro is defined, so clibgen sees plain C
% function declarations.

% Delete any previous definition files so we get a clean regeneration.
if isfile('defineeasir.mlx'), delete('defineeasir.mlx'); end
if isfile('defineeasir.m'),   delete('defineeasir.m');   end
if isfile('easirData.xml'),   delete('easirData.xml');   end

clibgen.generateLibraryDefinition(header_path, ...
    'Libraries',   import_lib, ...
    'PackageName', 'easir', ...
    'Verbose',     true);

%% --- Build the interface ---
fprintf('\n=== Building clib interface ===\n');
build(defineeasir);

fprintf('\n=== Interface ready ===\n');
fprintf('Use:  clib.easir.easir_create(...)\n');
fprintf('See easir_example.m for a full demo.\n');
