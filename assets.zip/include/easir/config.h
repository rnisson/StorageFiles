#pragma once

/**
 * @file config.h
 * @brief EasirConfig — static renderer configuration, set once at initialization.
 *
 * EasirConfig describes everything that is known before the first frame:
 *   - Camera geometry (count, type, resolution, FOV, clip planes)
 *   - Scene object declarations (spacecraft models, celestial bodies)
 *   - Universe parameters (star density, ambient light, sun)
 *   - Render pipeline settings (which passes are active, AA, tone mapping)
 *
 * Serialisation is handled by nlohmann::json via to_json / from_json.
 * Missing JSON fields fall back to in-struct defaults, so adding a new field
 * to a future version of the struct does NOT break existing JSON files.
 *
 * Nesting is intentionally kept to at most two levels (e.g. config.camera.fov)
 * so that the struct maps cleanly to a MATLAB struct via jsondecode().
 */

#include <array>
#include <string>
#include <vector>

#include <nlohmann/json.hpp>

namespace easir {

// ---------------------------------------------------------------------------
// Camera
// ---------------------------------------------------------------------------

struct CameraConfig {
    int    count      = 1;
    std::string type  = "pinhole"; ///< "pinhole" | "orthographic"
    int    width      = 1920;
    int    height     = 1080;
    float  fov_deg    = 60.0f;     ///< vertical field of view in degrees (pinhole only)
    float  near_plane = 0.1f;      ///< metres
    float  far_plane  = 1.0e6f;    ///< metres
    std::string render_mode = "";  ///< "" (default PBR) | "semantic" | "edge" | …
};

inline void to_json(nlohmann::json& j, const CameraConfig& c) {
    j = nlohmann::json{
        {"count",      c.count},
        {"type",       c.type},
        {"width",      c.width},
        {"height",     c.height},
        {"fov_deg",      c.fov_deg},
        {"near_plane",   c.near_plane},
        {"far_plane",    c.far_plane},
        {"render_mode",  c.render_mode},
    };
}

inline void from_json(const nlohmann::json& j, CameraConfig& c) {
    if (j.contains("count"))       j.at("count").get_to(c.count);
    if (j.contains("type"))        j.at("type").get_to(c.type);
    if (j.contains("width"))       j.at("width").get_to(c.width);
    if (j.contains("height"))      j.at("height").get_to(c.height);
    if (j.contains("fov_deg"))     j.at("fov_deg").get_to(c.fov_deg);
    if (j.contains("near_plane"))  j.at("near_plane").get_to(c.near_plane);
    if (j.contains("far_plane"))   j.at("far_plane").get_to(c.far_plane);
    if (j.contains("render_mode")) j.at("render_mode").get_to(c.render_mode);
}

// ---------------------------------------------------------------------------
// Scene objects
// ---------------------------------------------------------------------------

struct SceneObjectConfig {
    std::string id;           ///< unique identifier referenced by EasirState
    std::string type;         ///< "spacecraft" | "celestial_body"
    std::string asset_path;   ///< path to .glb/.gltf relative to the working directory
};

inline void to_json(nlohmann::json& j, const SceneObjectConfig& o) {
    j = nlohmann::json{
        {"id",         o.id},
        {"type",       o.type},
        {"asset_path", o.asset_path},
    };
}

inline void from_json(const nlohmann::json& j, SceneObjectConfig& o) {
    if (j.contains("id"))         j.at("id").get_to(o.id);
    if (j.contains("type"))       j.at("type").get_to(o.type);
    if (j.contains("asset_path")) j.at("asset_path").get_to(o.asset_path);
}

// ---------------------------------------------------------------------------
// Universe parameters
// ---------------------------------------------------------------------------

struct UniverseConfig {
    float star_density      = 1.0f;                     ///< multiplier on default star count
    float ambient_intensity = 0.01f;                    ///< dimensionless, [0, 1]
    std::array<float, 3> sun_color     = {1.0f, 0.95f, 0.90f}; ///< linear RGB
    float sun_intensity     = 1.0f;                     ///< multiplier
};

inline void to_json(nlohmann::json& j, const UniverseConfig& u) {
    j = nlohmann::json{
        {"star_density",      u.star_density},
        {"ambient_intensity", u.ambient_intensity},
        {"sun_color",         u.sun_color},
        {"sun_intensity",     u.sun_intensity},
    };
}

inline void from_json(const nlohmann::json& j, UniverseConfig& u) {
    if (j.contains("star_density"))      j.at("star_density").get_to(u.star_density);
    if (j.contains("ambient_intensity")) j.at("ambient_intensity").get_to(u.ambient_intensity);
    if (j.contains("sun_color"))         j.at("sun_color").get_to(u.sun_color);
    if (j.contains("sun_intensity"))     j.at("sun_intensity").get_to(u.sun_intensity);
}

// ---------------------------------------------------------------------------
// Render pipeline settings
// ---------------------------------------------------------------------------

struct PipelineConfig {
    bool forward_pass  = true;
    bool shadow_pass   = false;
    bool bloom_pass    = false;
    std::string aa_mode      = "none";  ///< "none" | "fxaa" | "msaa4x" | "msaa8x"
    std::string tone_mapping = "aces";  ///< "none" | "reinhard" | "aces"
};

inline void to_json(nlohmann::json& j, const PipelineConfig& p) {
    j = nlohmann::json{
        {"forward_pass",  p.forward_pass},
        {"shadow_pass",   p.shadow_pass},
        {"bloom_pass",    p.bloom_pass},
        {"aa_mode",       p.aa_mode},
        {"tone_mapping",  p.tone_mapping},
    };
}

inline void from_json(const nlohmann::json& j, PipelineConfig& p) {
    if (j.contains("forward_pass"))  j.at("forward_pass").get_to(p.forward_pass);
    if (j.contains("shadow_pass"))   j.at("shadow_pass").get_to(p.shadow_pass);
    if (j.contains("bloom_pass"))    j.at("bloom_pass").get_to(p.bloom_pass);
    if (j.contains("aa_mode"))       j.at("aa_mode").get_to(p.aa_mode);
    if (j.contains("tone_mapping"))  j.at("tone_mapping").get_to(p.tone_mapping);
}

// ---------------------------------------------------------------------------
// Top-level config
// ---------------------------------------------------------------------------

/**
 * @brief Static configuration for an EASIR renderer instance.
 *
 * Pass the JSON representation of this struct to easir_create().
 * All fields have sensible defaults; a minimal JSON can be an empty object {}.
 */
struct EasirConfig {
    CameraConfig                    camera;
    std::vector<SceneObjectConfig>  scene_objects;
    UniverseConfig                  universe;
    PipelineConfig                  pipeline;
    std::string                     data_root;  ///< root directory for resolving relative asset paths (default: "")
};

inline void to_json(nlohmann::json& j, const EasirConfig& cfg) {
    j = nlohmann::json{
        {"camera",        cfg.camera},
        {"scene_objects", cfg.scene_objects},
        {"universe",      cfg.universe},
        {"pipeline",      cfg.pipeline},
    };
    if (!cfg.data_root.empty()) {
        j["data_root"] = cfg.data_root;
    }
}

inline void from_json(const nlohmann::json& j, EasirConfig& cfg) {
    if (j.contains("camera"))        j.at("camera").get_to(cfg.camera);
    if (j.contains("scene_objects")) j.at("scene_objects").get_to(cfg.scene_objects);
    if (j.contains("universe"))      j.at("universe").get_to(cfg.universe);
    if (j.contains("pipeline"))      j.at("pipeline").get_to(cfg.pipeline);
    if (j.contains("data_root"))     j.at("data_root").get_to(cfg.data_root);
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/// Returns a default-constructed EasirConfig as a pretty-printed JSON string.
std::string config_to_json_string(const EasirConfig& cfg);

/// Parses a JSON string into an EasirConfig. Throws std::runtime_error on
/// malformed JSON; missing fields receive their in-struct defaults.
EasirConfig config_from_json_string(const std::string& json_str);

/// Returns the default EasirConfig as a pretty-printed JSON string.
std::string default_config_json();

} // namespace easir
