#pragma once

/**
 * @file renderer.h
 * @brief EasirRenderer — the central C++ renderer class.
 *
 * EasirRenderer is initialised with an EasirConfig and exposes:
 *   - set_state()   — update the dynamic per-frame EasirState
 *   - render()      — execute one frame through the pipeline
 *   - get_image()   — retrieve the rendered pixels (headless / DLL mode)
 *
 * Both the EXE and DLL entry points delegate to this class.  The difference
 * lies only in how rendering is triggered and output is consumed:
 *
 *   EXE  — creates a VSG window and calls render() inside a viewer loop.
 *   DLL  — renders offscreen; image data is accessible via get_image().
 */

#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include <vsg/all.h>
#include <vsgXchange/all.h>

#include "config.h"
#include "state.h"
#include "render_pipeline.h"

namespace easir {

/**
 * @brief Operating mode for the renderer.
 *
 * Windowed   — renders to a visible window (EXE / interactive mode).
 * Headless   — renders offscreen into an internal buffer (DLL / MATLAB mode).
 */
enum class RenderMode {
    Windowed,
    Headless,
};

/**
 * @brief Core renderer class.
 *
 * Thread safety: not thread-safe.  Create one instance per thread if needed.
 */
class EasirRenderer {
public:
    /**
     * @brief Construct a renderer with the given configuration.
     *
     * @param config   Parsed EasirConfig describing the static scene setup.
     * @param mode     Windowed (EXE) or Headless (DLL).
     * @throws std::runtime_error if Vulkan initialisation fails.
     */
    explicit EasirRenderer(const EasirConfig& config, RenderMode mode = RenderMode::Headless);
    ~EasirRenderer();

    EasirRenderer(const EasirRenderer&)            = delete;
    EasirRenderer& operator=(const EasirRenderer&) = delete;

    // -----------------------------------------------------------------------
    // Per-frame API
    // -----------------------------------------------------------------------

    /**
     * @brief Replace the current dynamic state.
     *
     * Safe to call every frame; only changes visible to the next render().
     */
    void set_state(const EasirState& state);

    /**
     * @brief Execute one render frame through the pipeline.
     *
     * In Headless mode the result is written to the internal image buffer and
     * accessible via get_image().  In Windowed mode the frame is presented to
     * the window surface.
     *
     * @return true on success, false if the viewer requested shutdown (windowed).
     */
    bool render();

    // -----------------------------------------------------------------------
    // Image output (Headless / DLL mode)
    // -----------------------------------------------------------------------

    /**
     * @brief Return a pointer to the rendered pixel buffer.
     *
     * The buffer is owned by the renderer and remains valid until the next
     * call to render() or until the renderer is destroyed.
     *
     * @param data      [out] pointer to the RGBA8 pixel data
     * @param width     [out] image width in pixels
     * @param height    [out] image height in pixels
     * @param channels  [out] number of channels (always 4 for RGBA)
     * @return true if a rendered image is available, false otherwise.
     */
    bool get_image(const uint8_t** data, int* width, int* height, int* channels) const;

    // -----------------------------------------------------------------------
    // Introspection
    // -----------------------------------------------------------------------

    [[nodiscard]] const EasirConfig& config() const noexcept { return m_config; }
    [[nodiscard]] const EasirState&  state()  const noexcept { return m_state;  }

    /// Returns the VSG viewer (nullptr in headless mode before first render).
    [[nodiscard]] vsg::ref_ptr<vsg::Viewer> viewer() const noexcept { return m_viewer; }

private:
    void init_headless();
    void init_windowed();
    void update_scene_from_state();
    void readback_pixels();

    EasirConfig  m_config;
    EasirState   m_state;
    RenderMode  m_mode;

    // VSG objects
    vsg::ref_ptr<vsg::Viewer>       m_viewer;
    vsg::ref_ptr<vsg::Group>        m_scene_root;
    vsg::ref_ptr<vsg::Camera>       m_camera;

    // Headless offscreen resources (only used in Headless mode)
    vsg::ref_ptr<vsg::Device>       m_device;
    vsg::ref_ptr<vsg::Image>        m_color_image;
    vsg::ref_ptr<vsg::Image>        m_depth_image;
    int                             m_queue_family = -1;

    // Pre-allocated readback resources (created once in init_headless)
    VkCommandPool                   m_readback_pool   = VK_NULL_HANDLE;
    VkCommandBuffer                 m_readback_cmd    = VK_NULL_HANDLE;
    VkBuffer                        m_staging_buf     = VK_NULL_HANDLE;
    VkDeviceMemory                  m_staging_mem     = VK_NULL_HANDLE;
    VkFence                         m_readback_fence  = VK_NULL_HANDLE;
    void*                           m_staging_mapped  = nullptr;

    // Image dimensions and readiness flag (pixel data lives in m_staging_mapped)
    int                             m_image_width    = 0;
    int                             m_image_height   = 0;
    bool                            m_image_ready    = false;

    // Render pipeline
    std::unique_ptr<RenderPipeline> m_pipeline;

    // vsgXchange options reuse
    vsg::ref_ptr<vsg::Options>      m_vsg_options;
};

} // namespace easir
