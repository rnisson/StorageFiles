#pragma once

/**
 * @file semantic_group_manager.h
 * @brief SemanticGroupManager — manages semantic groups and node assignments.
 *
 * Used by editor mode to interactively build semantic maps:
 *   - Groups have a name, color, and list of assigned nodes
 *   - "Unassigned" is a permanent group (cannot be deleted/renamed)
 *   - Nodes can be moved between groups
 *   - Save/load to/from <model_stem>_semantic_map.json
 */

#include <algorithm>
#include <array>
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <string>
#include <vector>

#include <nlohmann/json.hpp>
#include <vsg/maths/vec4.h>

namespace easir {

struct SemanticGroup {
    int         id;
    std::string name;
    std::array<float, 3> color;  // RGB [0..1]
    std::vector<std::string> nodes;  // short node names
    bool        permanent = false;   // true for "Unassigned"
};

class SemanticGroupManager {
public:
    /// Initialize with the list of all node short names discovered in the scene.
    /// All nodes start in the "Unassigned" group.
    void init(const std::vector<std::string>& all_node_names,
              const std::filesystem::path& asset_path) {
        m_asset_path = asset_path;
        m_groups.clear();
        m_next_id = 1;

        // Create the permanent "Unassigned" group.
        SemanticGroup unassigned;
        unassigned.id = 0;
        unassigned.name = "Unassigned";
        unassigned.color = {0.5f, 0.5f, 0.5f};
        unassigned.nodes = all_node_names;
        unassigned.permanent = true;
        m_groups.push_back(std::move(unassigned));

        m_all_nodes = all_node_names;
    }

    /// Try to load an existing semantic map JSON. Returns true if loaded.
    bool load() {
        auto json_path = derive_json_path();
        if (!std::filesystem::exists(json_path)) return false;

        std::ifstream ifs(json_path);
        if (!ifs) return false;

        nlohmann::json root;
        try { ifs >> root; } catch (...) { return false; }

        if (!root.contains("classes") || !root["classes"].is_object()) return false;

        // Clear existing groups except Unassigned.
        m_groups.erase(
            std::remove_if(m_groups.begin(), m_groups.end(),
                           [](const SemanticGroup& g) { return !g.permanent; }),
            m_groups.end());

        // Put all nodes back in Unassigned.
        m_groups[0].nodes = m_all_nodes;

        // Load each class.
        for (auto& [class_name, class_def] : root["classes"].items()) {
            std::array<float, 3> color = {1.0f, 0.0f, 1.0f};
            if (class_def.contains("color") && class_def["color"].is_array() &&
                class_def["color"].size() >= 3) {
                color = {
                    class_def["color"][0].get<float>() / 255.0f,
                    class_def["color"][1].get<float>() / 255.0f,
                    class_def["color"][2].get<float>() / 255.0f,
                };
            }

            std::vector<std::string> nodes;
            if (class_def.contains("nodes") && class_def["nodes"].is_array()) {
                for (auto& n : class_def["nodes"]) {
                    nodes.push_back(n.get<std::string>());
                }
            }

            SemanticGroup group;
            group.id = m_next_id++;
            group.name = class_name;
            group.color = color;
            group.nodes = nodes;
            group.permanent = false;
            m_groups.push_back(std::move(group));

            // Remove these nodes from Unassigned.
            for (const auto& n : nodes) {
                auto& un = m_groups[0].nodes;
                un.erase(std::remove(un.begin(), un.end(), n), un.end());
            }
        }

        std::printf("[EASIR] Loaded semantic map: %s (%zu classes)\n",
                    json_path.filename().string().c_str(), m_groups.size() - 1);
        return true;
    }

    /// Check if the save file already exists on disk.
    bool save_file_exists() const { return std::filesystem::exists(derive_json_path()); }

    /// Get the save file path.
    std::filesystem::path save_path() const { return derive_json_path(); }

    /// Save the current groups to JSON.
    bool save() const {
        auto json_path = derive_json_path();

        nlohmann::json root;
        root["model"] = m_asset_path.filename().string();

        nlohmann::json classes = nlohmann::json::object();
        for (const auto& g : m_groups) {
            if (g.permanent) continue;  // Don't save Unassigned.
            if (g.nodes.empty()) continue;  // Skip empty groups.

            nlohmann::json cls;
            cls["color"] = {
                static_cast<int>(g.color[0] * 255.0f),
                static_cast<int>(g.color[1] * 255.0f),
                static_cast<int>(g.color[2] * 255.0f),
            };
            cls["nodes"] = g.nodes;
            classes[g.name] = cls;
        }
        root["classes"] = classes;

        std::ofstream ofs(json_path);
        if (!ofs) {
            std::printf("[EASIR] Error: could not write %s\n", json_path.string().c_str());
            return false;
        }
        ofs << root.dump(2);
        std::printf("[EASIR] Saved semantic map: %s\n", json_path.filename().string().c_str());
        return true;
    }

    // ----- Group management -----

    int add_group(const std::string& name, std::array<float, 3> color) {
        SemanticGroup g;
        g.id = m_next_id++;
        g.name = name;
        g.color = color;
        g.permanent = false;
        m_groups.push_back(std::move(g));
        return g.id;
    }

    void delete_group(int id) {
        auto it = std::find_if(m_groups.begin(), m_groups.end(),
                               [id](const SemanticGroup& g) { return g.id == id; });
        if (it == m_groups.end() || it->permanent) return;

        // Move nodes back to Unassigned.
        auto& unassigned = m_groups[0].nodes;
        for (auto& n : it->nodes) {
            unassigned.push_back(n);
        }
        m_groups.erase(it);
    }

    /// Assign a node (by short name) to a group. Removes it from its current group.
    void assign_node(const std::string& short_name, int target_group_id) {
        // Remove from current group.
        for (auto& g : m_groups) {
            auto& nodes = g.nodes;
            auto it = std::find(nodes.begin(), nodes.end(), short_name);
            if (it != nodes.end()) {
                nodes.erase(it);
                break;
            }
        }
        // Add to target group.
        for (auto& g : m_groups) {
            if (g.id == target_group_id) {
                g.nodes.push_back(short_name);
                return;
            }
        }
    }

    /// Find which group a node belongs to. Returns group id, or -1.
    int find_node_group(const std::string& short_name) const {
        for (const auto& g : m_groups) {
            for (const auto& n : g.nodes) {
                if (n == short_name) return g.id;
            }
        }
        return -1;
    }

    /// Get group by id (or nullptr).
    SemanticGroup* group_by_id(int id) {
        for (auto& g : m_groups) {
            if (g.id == id) return &g;
        }
        return nullptr;
    }

    const SemanticGroup* group_by_id(int id) const {
        for (const auto& g : m_groups) {
            if (g.id == id) return &g;
        }
        return nullptr;
    }

    /// Get the color for a node (based on its group). Returns auto-color for Unassigned.
    vsg::vec4 color_for_node(const std::string& short_name) const {
        for (const auto& g : m_groups) {
            for (const auto& n : g.nodes) {
                if (n == short_name) {
                    if (g.permanent) {
                        // Unassigned: use auto-color.
                        return auto_color(short_name);
                    }
                    return vsg::vec4{g.color[0], g.color[1], g.color[2], 1.0f};
                }
            }
        }
        return vsg::vec4{1.0f, 0.0f, 1.0f, 1.0f};  // magenta fallback
    }

    std::vector<SemanticGroup>& groups() { return m_groups; }
    const std::vector<SemanticGroup>& groups() const { return m_groups; }

    const std::vector<std::string>& all_nodes() const { return m_all_nodes; }

    /// Extract short name from full vsgXchange node name.
    static std::string extract_short_name(const std::string& full_name) {
        auto last_open = full_name.rfind('[');
        if (last_open == std::string::npos) return full_name;
        auto close = full_name.find(']', last_open + 1);
        if (close == std::string::npos || close <= last_open) return full_name;
        return full_name.substr(last_open + 1, close - last_open - 1);
    }

private:
    std::vector<SemanticGroup> m_groups;
    std::vector<std::string> m_all_nodes;  // all short names
    std::filesystem::path m_asset_path;
    int m_next_id = 1;

    std::filesystem::path derive_json_path() const {
        return m_asset_path.parent_path() /
               (m_asset_path.stem().string() + "_semantic_map.json");
    }

    /// Sequential index + golden-ratio auto-color (matches SemanticColorMap::auto_color).
    static vsg::vec4 auto_color(const std::string& name) {
        static std::unordered_map<std::string, int> name_to_index;
        static int next_index = 0;

        auto it = name_to_index.find(name);
        if (it == name_to_index.end()) {
            name_to_index[name] = next_index++;
            it = name_to_index.find(name);
        }

        constexpr float golden_ratio_conjugate = 0.618033988749895f;
        float h = std::fmod(it->second * golden_ratio_conjugate, 1.0f);
        // HSV to RGB (s=0.85, v=0.95)
        float c = 0.95f * 0.85f;
        float x = c * (1.0f - std::fabs(std::fmod(h * 6.0f, 2.0f) - 1.0f));
        float m = 0.95f - c;
        float r, g, b;
        int sector = static_cast<int>(h * 6.0f) % 6;
        switch (sector) {
            case 0: r = c; g = x; b = 0; break;
            case 1: r = x; g = c; b = 0; break;
            case 2: r = 0; g = c; b = x; break;
            case 3: r = 0; g = x; b = c; break;
            case 4: r = x; g = 0; b = c; break;
            default: r = c; g = 0; b = x; break;
        }
        return vsg::vec4{r + m, g + m, b + m, 1.0f};
    }
};

} // namespace easir
