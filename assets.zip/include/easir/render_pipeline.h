#pragma once

/**
 * @file render_pipeline.h
 * @brief RenderPipeline and RenderPass abstractions.
 *
 * The pipeline owns an ordered list of RenderPass objects and executes them
 * in sequence each frame.  Each pass operates on the same VSG scene graph and
 * command graph, adding Vulkan commands or scene nodes as required.
 *
 * Extending the pipeline with a new effect (bloom, shadow mapping, atmosphere,
 * etc.) means deriving a new class from RenderPass and registering it in
 * RenderPipeline::build().
 */

#include <memory>
#include <string>
#include <unordered_map>
#include <vector>

#include <vsg/all.h>
#include <vsgXchange/all.h>

#include "config.h"
#include "semantic_map.h"
#include "semantic_visitor.h"
#include "state.h"

namespace easir {

// ---------------------------------------------------------------------------
// RenderContext — data shared across all passes in a single render call
// ---------------------------------------------------------------------------

struct RenderContext {
    vsg::ref_ptr<vsg::Viewer>   viewer;
    vsg::ref_ptr<vsg::Group>    scene_root;
    const EasirConfig*           config  = nullptr;
    const EasirState*            state   = nullptr;
    uint64_t                    frame   = 0;
};

// ---------------------------------------------------------------------------
// RenderPass base class
// ---------------------------------------------------------------------------

/**
 * @brief Abstract base class for a single rendering pass.
 *
 * Subclass this to implement shadow mapping, star field generation, bloom,
 * atmospheric scattering, etc.  For the initial scaffold only ForwardPass
 * is provided.
 */
class RenderPass {
public:
    explicit RenderPass(std::string name) : m_name(std::move(name)) {}
    virtual ~RenderPass() = default;

    RenderPass(const RenderPass&)            = delete;
    RenderPass& operator=(const RenderPass&) = delete;

    /// Called once after the pass is created; set up VSG objects here.
    virtual void setup(RenderContext& ctx) = 0;

    /// Called each frame to record pass-specific commands / updates.
    virtual void execute(RenderContext& ctx) = 0;

    /// Called when the renderer is shutting down.
    virtual void teardown([[maybe_unused]] RenderContext& ctx) {}

    [[nodiscard]] const std::string& name() const noexcept { return m_name; }

protected:
    std::string m_name;
};

// ---------------------------------------------------------------------------
// ForwardPass — basic forward-shading pass (initial scaffold)
// ---------------------------------------------------------------------------

/**
 * @brief Forward-shading pass.
 *
 * Loads the scene objects declared in EasirConfig, applies a single directional
 * light (the sun), and renders them.  This is the starting point; additional
 * lighting models and material complexity will be layered in later.
 */
class ForwardPass final : public RenderPass {
public:
    ForwardPass() : RenderPass("ForwardPass") {}

    void setup(RenderContext& ctx) override;
    void execute(RenderContext& ctx) override;

    /// Get the resolved asset path for the first scene object (for editor mode).
    std::filesystem::path first_asset_path() const {
        if (m_asset_paths.empty()) return {};
        return m_asset_paths.begin()->second;
    }

    /// Material map from semantic visitor (for live recoloring in editor).
    using MaterialMap = std::unordered_map<std::string, vsg::ref_ptr<vsg::PhongMaterialValue>>;
    const MaterialMap& material_map() const { return m_materialMap; }

    /// Sun light reference (for editor light direction reset).
    vsg::ref_ptr<vsg::DirectionalLight> sun_light() const { return m_sun_light; }

private:
    MaterialMap m_materialMap;
    vsg::ref_ptr<vsg::DirectionalLight> m_sun_light;
    vsg::ref_ptr<vsg::Group>            m_scene_objects_group;

    /// Per-object transform nodes, keyed by SceneObjectConfig::id.
    std::unordered_map<std::string, vsg::ref_ptr<vsg::MatrixTransform>> m_object_transforms;

    /// Resolved asset paths per object id (for semantic map lookup).
    std::unordered_map<std::string, std::filesystem::path> m_asset_paths;
};

// ---------------------------------------------------------------------------
// RenderPipeline
// ---------------------------------------------------------------------------

/**
 * @brief Owns and executes the ordered sequence of render passes.
 *
 * Build the pipeline once with build(config), then call execute(ctx) each frame.
 * The set of passes created is determined by EasirConfig::pipeline.
 */
class RenderPipeline {
public:
    RenderPipeline() = default;
    ~RenderPipeline() = default;

    RenderPipeline(const RenderPipeline&)            = delete;
    RenderPipeline& operator=(const RenderPipeline&) = delete;

    /// Creates all passes enabled in the config and calls setup() on each.
    void build(const EasirConfig& config, RenderContext& ctx);

    /// Executes all passes in order for the current frame.
    void execute(RenderContext& ctx);

    /// Shuts down all passes.
    void teardown(RenderContext& ctx);

    /// Returns the number of passes in the pipeline.
    [[nodiscard]] std::size_t pass_count() const noexcept { return m_passes.size(); }

    /// Access a pass by index (for inspection / testing).
    [[nodiscard]] RenderPass& pass(std::size_t i) { return *m_passes.at(i); }

    /// Get the forward pass (first pass), or nullptr.
    ForwardPass* forward_pass() {
        if (m_passes.empty()) return nullptr;
        return dynamic_cast<ForwardPass*>(m_passes[0].get());
    }

private:
    std::vector<std::unique_ptr<RenderPass>> m_passes;
};

} // namespace easir
