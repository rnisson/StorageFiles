#pragma once

/**
 * @file state.h
 * @brief EasirState — dynamic per-frame renderer state.
 *
 * EasirState carries everything that can change between render calls:
 *   - Per-object pose (position, orientation quaternion, velocity) for each
 *     scene object declared in EasirConfig
 *   - Camera pose (or follow-spacecraft mode)
 *   - Simulation time (Julian Date)
 *   - Sun direction
 *   - Runtime debug flags
 *
 * Time convention: Julian Date (JD).  J2000.0 = JD 2 451 545.0.
 * Positions are in metres, orientations as unit quaternions [x, y, z, w],
 * velocity in metres per second.  All values are in the inertial frame
 * unless noted otherwise.
 *
 * All position and orientation fields use double precision to preserve
 * sub-metre accuracy at orbital scales (e.g. GEO ~ 42 164 km).
 *
 * Adding a new field to this struct is backward-compatible: existing JSON
 * files simply omit the new field and the in-struct default applies.
 */

#include <array>
#include <string>
#include <vector>

#include <nlohmann/json.hpp>

namespace easir {

// ---------------------------------------------------------------------------
// Per-object dynamic state
// ---------------------------------------------------------------------------

/**
 * @brief Dynamic state for a single scene object.
 *
 * Each entry's `id` must match a SceneObjectConfig::id declared in EasirConfig.
 */
struct SceneObjectState {
    /// Identifier matching the corresponding SceneObjectConfig::id.
    std::string id;

    /// Position in the inertial frame (metres).  Double precision for orbital scales.
    std::array<double, 3> position    = {0.0, 0.0, 0.0};

    /// Orientation quaternion [x, y, z, w] (unit quaternion).
    std::array<double, 4> orientation = {0.0, 0.0, 0.0, 1.0};

    /// Velocity vector in the inertial frame (m/s).
    std::array<double, 3> velocity    = {0.0, 0.0, 0.0};
};

inline void to_json(nlohmann::json& j, const SceneObjectState& o) {
    j = nlohmann::json{
        {"id",          o.id},
        {"position",    o.position},
        {"orientation", o.orientation},
        {"velocity",    o.velocity},
    };
}

inline void from_json(const nlohmann::json& j, SceneObjectState& o) {
    if (j.contains("id"))          j.at("id").get_to(o.id);
    if (j.contains("position"))    j.at("position").get_to(o.position);
    if (j.contains("orientation")) j.at("orientation").get_to(o.orientation);
    if (j.contains("velocity"))    j.at("velocity").get_to(o.velocity);
}

// ---------------------------------------------------------------------------
// Top-level state
// ---------------------------------------------------------------------------

/**
 * @brief Dynamic per-frame state for an EASIR renderer instance.
 *
 * Pass the JSON representation to easir_set_state() before each easir_render().
 */
struct EasirState {

    // -----------------------------------------------------------------------
    // Scene object poses
    // -----------------------------------------------------------------------

    /// Per-object dynamic state.  Each entry's `id` must match a
    /// SceneObjectConfig::id in the EasirConfig used to create the renderer.
    std::vector<SceneObjectState> scene_objects;

    // -----------------------------------------------------------------------
    // Camera pose
    // -----------------------------------------------------------------------

    /// Camera position (metres).  Double precision for orbital scales.
    /// Ignored when camera_follow_spacecraft = true.
    std::array<double, 3> camera_position    = {0.0, 0.0, 10.0};

    /// Camera orientation quaternion [x, y, z, w].  Double precision.
    /// Ignored when camera_follow_spacecraft = true.
    std::array<double, 4> camera_orientation = {0.0, 0.0, 0.0, 1.0};

    /// When true the camera is parented to the first scene object's body frame.
    bool camera_follow_spacecraft = false;

    // -----------------------------------------------------------------------
    // Time
    // -----------------------------------------------------------------------

    /// Julian Date of the current simulation epoch.  J2000.0 = 2 451 545.0.
    double julian_date = 2451545.0;

    // -----------------------------------------------------------------------
    // Lighting
    // -----------------------------------------------------------------------

    /// Unit vector pointing FROM the scene TOWARD the sun (inertial frame).
    std::array<double, 3> sun_direction = {1.0, 0.0, 0.0};

    // -----------------------------------------------------------------------
    // Debug / runtime flags
    // -----------------------------------------------------------------------

    /// Overlay all geometry as wireframe.
    bool wireframe_overlay      = false;

    /// Enable debug visualisation (normals, bounding boxes, etc.).
    bool debug_visualization    = false;
};

// ---------------------------------------------------------------------------
// JSON serialisation
// ---------------------------------------------------------------------------

inline void to_json(nlohmann::json& j, const EasirState& s) {
    j = nlohmann::json{
        {"scene_objects",           s.scene_objects},
        {"camera_position",        s.camera_position},
        {"camera_orientation",     s.camera_orientation},
        {"camera_follow_spacecraft", s.camera_follow_spacecraft},
        {"julian_date",            s.julian_date},
        {"sun_direction",          s.sun_direction},
        {"wireframe_overlay",      s.wireframe_overlay},
        {"debug_visualization",    s.debug_visualization},
    };
}

inline void from_json(const nlohmann::json& j, EasirState& s) {
    if (j.contains("scene_objects"))        j.at("scene_objects").get_to(s.scene_objects);
    if (j.contains("camera_position"))      j.at("camera_position").get_to(s.camera_position);
    if (j.contains("camera_orientation"))   j.at("camera_orientation").get_to(s.camera_orientation);
    if (j.contains("camera_follow_spacecraft")) j.at("camera_follow_spacecraft").get_to(s.camera_follow_spacecraft);
    if (j.contains("julian_date"))          j.at("julian_date").get_to(s.julian_date);
    if (j.contains("sun_direction"))        j.at("sun_direction").get_to(s.sun_direction);
    if (j.contains("wireframe_overlay"))    j.at("wireframe_overlay").get_to(s.wireframe_overlay);
    if (j.contains("debug_visualization")) j.at("debug_visualization").get_to(s.debug_visualization);

    // Backward compatibility: if the legacy flat fields are present and
    // scene_objects is empty, migrate them into a single scene object entry.
    if (s.scene_objects.empty() && (j.contains("spacecraft_position") ||
                                    j.contains("spacecraft_orientation") ||
                                    j.contains("spacecraft_velocity"))) {
        SceneObjectState legacy;
        legacy.id = "spacecraft_01";
        if (j.contains("spacecraft_position"))    j.at("spacecraft_position").get_to(legacy.position);
        if (j.contains("spacecraft_orientation")) j.at("spacecraft_orientation").get_to(legacy.orientation);
        if (j.contains("spacecraft_velocity"))    j.at("spacecraft_velocity").get_to(legacy.velocity);
        s.scene_objects.push_back(std::move(legacy));
    }
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/// Serialises an EasirState to a pretty-printed JSON string.
std::string state_to_json_string(const EasirState& state);

/// Parses a JSON string into an EasirState. Throws std::runtime_error on
/// malformed JSON; missing fields receive their in-struct defaults.
EasirState state_from_json_string(const std::string& json_str);

/// Returns the default EasirState as a pretty-printed JSON string.
std::string default_state_json();

} // namespace easir
