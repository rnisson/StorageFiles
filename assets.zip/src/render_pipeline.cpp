#include "easir/render_pipeline.h"
#include "easir/trace.h"

#include <cstdio>
#include <filesystem>
#include <format>
#include <stdexcept>

namespace easir {

// ---------------------------------------------------------------------------
// ForwardPass
// ---------------------------------------------------------------------------

void ForwardPass::setup(RenderContext& ctx) {
    if (!ctx.scene_root || !ctx.config) {
        return;
    }

    // Create a group that will hold all scene geometry loaded from .glb files.
    m_scene_objects_group = vsg::Group::create();

    // vsgXchange options for loading glTF/glb assets.
    auto options = vsg::Options::create();
    options->add(vsgXchange::all::create());

    // Load each declared scene object (editor mode: first only).
    namespace fs = std::filesystem;
    const bool editor = ctx.config->global.editor_mode;
    for (const auto& obj : ctx.config->scene_objects) {
        if (obj.asset_path.empty()) {
            continue;
        }
        // Resolve relative asset paths against data_root.
        fs::path asset_path(obj.asset_path);
        if (asset_path.is_relative() && !ctx.config->data_root.empty()) {
            asset_path = fs::path(ctx.config->data_root) / asset_path;
        }
        auto node = vsg::read_cast<vsg::Node>(asset_path.string(), options);
        if (node) {
            // Wrap in a MatrixTransform so we can set position/orientation per frame.
            auto transform = vsg::MatrixTransform::create();
            transform->addChild(node);
            m_object_transforms[obj.id] = transform;
            m_asset_paths[obj.id] = asset_path;
            m_scene_objects_group->addChild(transform);
        }
        // If the asset is missing we silently skip it — useful during development
        // when assets aren't yet available.

        // Editor mode: only load the first scene object.
        if (editor && !m_object_transforms.empty()) break;
    }

    // Apply semantic rendering mode if requested.
    if (ctx.config->camera.render_mode == "semantic" || ctx.config->camera.render_mode == "edge") {
        std::printf("[EASIR] Render mode: semantic\n");
        EASIR_TRACE("ForwardPass::setup: semantic mode active");

        for (const auto& [id, transform] : m_object_transforms) {
            auto path_it = m_asset_paths.find(id);
            if (path_it == m_asset_paths.end()) continue;

            auto colorMap = SemanticColorMap::load(path_it->second);
            SemanticMaterialVisitor visitor(colorMap);
            transform->accept(visitor);

            // Store material references for live recoloring in editor mode.
            for (auto& [name, mat] : visitor.material_map()) {
                m_materialMap[name] = mat;
            }

            std::printf("[EASIR] Applied semantic colors to %d nodes for object '%s'\n",
                        visitor.replaced_count(), id.c_str());
            EASIR_TRACE("ForwardPass: replaced %d StateGroups for '%s'",
                        visitor.replaced_count(), id.c_str());
        }
    }

    // Directional light representing the sun.
    m_sun_light = vsg::DirectionalLight::create();
    m_sun_light->name      = "sun";
    m_sun_light->color     = vsg::vec3{
        ctx.config->universe.sun_color[0],
        ctx.config->universe.sun_color[1],
        ctx.config->universe.sun_color[2],
    };
    m_sun_light->intensity = ctx.config->universe.sun_intensity;

    // Default direction — will be overridden each frame in execute().
    m_sun_light->direction = vsg::vec3{1.0f, 0.0f, 0.0f};

    // Ambient light.
    auto ambient = vsg::AmbientLight::create();
    ambient->name      = "ambient";
    ambient->color     = vsg::vec3{1.0f, 1.0f, 1.0f};
    ambient->intensity = ctx.config->universe.ambient_intensity;

    ctx.scene_root->addChild(m_sun_light);
    ctx.scene_root->addChild(ambient);
    ctx.scene_root->addChild(m_scene_objects_group);
}

/// Build a 4x4 model matrix from position (metres) and orientation quaternion [x,y,z,w].
static vsg::dmat4 pose_to_matrix(const std::array<double, 3>& pos,
                                  const std::array<double, 4>& q) {
    const double x = q[0], y = q[1], z = q[2], w = q[3];

    // Rotation matrix from unit quaternion.
    vsg::dmat4 m(
        1.0 - 2.0*(y*y + z*z),  2.0*(x*y + w*z),        2.0*(x*z - w*y),        0.0,
        2.0*(x*y - w*z),         1.0 - 2.0*(x*x + z*z),  2.0*(y*z + w*x),        0.0,
        2.0*(x*z + w*y),         2.0*(y*z - w*x),         1.0 - 2.0*(x*x + y*y), 0.0,
        pos[0],                  pos[1],                  pos[2],                  1.0
    );
    return m;
}

void ForwardPass::execute(RenderContext& ctx) {
    if (!m_sun_light || !ctx.state) {
        return;
    }

    // In editor mode, skip sun direction update — the editor's [L] button
    // sets the direction manually and we don't want to overwrite it.
    if (!ctx.config->global.editor_mode) {
        m_sun_light->direction = vsg::vec3{
            static_cast<float>(ctx.state->sun_direction[0]),
            static_cast<float>(ctx.state->sun_direction[1]),
            static_cast<float>(ctx.state->sun_direction[2]),
        };
    }

    // Update per-object transforms from state.
    for (const auto& obj_state : ctx.state->scene_objects) {
        auto it = m_object_transforms.find(obj_state.id);
        if (it != m_object_transforms.end()) {
            it->second->matrix = pose_to_matrix(obj_state.position, obj_state.orientation);
        }
    }
}

// ---------------------------------------------------------------------------
// RenderPipeline
// ---------------------------------------------------------------------------

void RenderPipeline::build(const EasirConfig& config, RenderContext& ctx) {
    m_passes.clear();

    if (config.pipeline.forward_pass) {
        auto pass = std::make_unique<ForwardPass>();
        pass->setup(ctx);
        m_passes.push_back(std::move(pass));
    }

    // Future passes (shadow, bloom, star field, atmosphere …) can be added
    // here with their own config flags, e.g.:
    //
    //   if (config.pipeline.shadow_pass) {
    //       auto pass = std::make_unique<ShadowPass>();
    //       pass->setup(ctx);
    //       m_passes.push_back(std::move(pass));
    //   }
}

void RenderPipeline::execute(RenderContext& ctx) {
    for (auto& pass : m_passes) {
        pass->execute(ctx);
    }
}

void RenderPipeline::teardown(RenderContext& ctx) {
    for (auto& pass : m_passes) {
        pass->teardown(ctx);
    }
    m_passes.clear();
}

} // namespace easir
