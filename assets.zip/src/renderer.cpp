#include "easir/renderer.h"
#include "easir/trace.h"
#include "easir/edge_pass.h"
#include "easir/frame_logger.h"

#include <vsg/app/Trackball.h>

#include "easir/editor_handler.h"

#include <vsgImGui/RenderImGui.h>
#include <vsgImGui/SendEventsToImGui.h>

#include <vsg/vk/Instance.h>
#include <vsg/vk/PhysicalDevice.h>
#include <vsg/vk/Device.h>
#include <vsg/vk/DeviceMemory.h>
#include <vsg/vk/CommandPool.h>
#include <vsg/vk/Framebuffer.h>
#include <vsg/vk/RenderPass.h>
#include <vsg/state/Image.h>
#include <vsg/state/ImageView.h>
#include <vsg/commands/CopyImageToBuffer.h>
#include <vsg/commands/PipelineBarrier.h>

#include <stdexcept>
#include <format>
#include <cstring>
#include <cmath>
#include <algorithm>

namespace easir {

// ---------------------------------------------------------------------------
// Construction / destruction
// ---------------------------------------------------------------------------

EasirRenderer::EasirRenderer(const EasirConfig& config, RenderMode mode)
    : m_config(config)
    , m_mode(mode)
    , m_pipeline(std::make_unique<RenderPipeline>())
{
    EASIR_TRACE("EasirRenderer::ctor: enter, mode=%s",
                mode == RenderMode::Headless ? "Headless" : "Windowed");

    // Create the vsgXchange-aware options object once.
    EASIR_TRACE("EasirRenderer::ctor: creating vsg::Options");
    m_vsg_options = vsg::Options::create();
    EASIR_TRACE("EasirRenderer::ctor: vsg::Options OK, creating vsgXchange::all");
    auto xchange = vsgXchange::all::create();
    EASIR_TRACE("EasirRenderer::ctor: vsgXchange::all created, adding to options");
    m_vsg_options->add(xchange);
    EASIR_TRACE("EasirRenderer::ctor: vsgXchange added OK");

    // Build the top-level scene root.
    EASIR_TRACE("EasirRenderer::ctor: creating scene root");
    m_scene_root = vsg::Group::create();

    if (m_mode == RenderMode::Headless) {
        init_headless();
    } else {
        init_windowed();
    }

    // Build the render pipeline now that the viewer exists.
    EASIR_TRACE("EasirRenderer::ctor: building render pipeline");
    RenderContext ctx{
        .viewer     = m_viewer,
        .scene_root = m_scene_root,
        .config     = &m_config,
        .state      = &m_state,
        .frame      = 0,
    };
    m_pipeline->build(m_config, ctx);

    // In editor mode, initialize the semantic group manager now that the
    // scene is loaded and we can discover node names.
    if (m_config.global.editor_mode && m_editor_handler) {
        auto* eh = static_cast<EditorHandler*>(m_editor_handler.get());

        // Discover all named nodes in the scene graph.
        eh->discover_nodes();

        // Collect short names from the scene for the group manager.
        // Walk the scene graph with a simple visitor.
        struct NodeNameCollector : public vsg::Visitor {
            std::vector<std::string> names;
            void apply(vsg::Node& node) override { node.traverse(*this); }
            void apply(vsg::Group& group) override {
                check_name(group);
                group.traverse(*this);
            }
            void apply(vsg::MatrixTransform& mt) override {
                check_name(mt);
                mt.traverse(*this);
            }
            void check_name(vsg::Object& obj) {
                std::string name;
                if (obj.getValue("name", name) && !name.empty()) {
                    // Filter out container/root nodes (no brackets = not a leaf layer).
                    if (name.find('[') == std::string::npos) return;
                    auto shortName = SemanticGroupManager::extract_short_name(name);
                    // Avoid duplicates.
                    if (std::find(names.begin(), names.end(), shortName) == names.end()) {
                        names.push_back(shortName);
                    }
                }
            }
        };

        NodeNameCollector collector;
        m_scene_root->accept(collector);

        // Get the asset path for JSON save/load.
        std::filesystem::path assetPath;
        if (auto* fp = m_pipeline->forward_pass()) {
            assetPath = fp->first_asset_path();
        }

        m_group_manager = std::make_unique<SemanticGroupManager>();
        m_group_manager->init(collector.names, assetPath);
        m_group_manager->load();  // Load existing map if present.

        eh->set_group_manager(m_group_manager.get());

        // Pass edge preview switch if available (editor mode with offscreen FBO).
        if (m_edgePreviewSwitch) {
            eh->set_edge_preview_switch(m_edgePreviewSwitch);
        }

        // Pass sun light for reset-light feature.
        if (auto* fp = m_pipeline->forward_pass()) {
            if (fp->sun_light()) {
                eh->set_sun_light(fp->sun_light());
            }
        }

        // Pass material references from semantic visitor for live recoloring.
        if (auto* fp = m_pipeline->forward_pass()) {
            eh->set_material_map(fp->material_map());
            std::printf("[EASIR] Editor: %zu material refs available for live recoloring\n",
                        fp->material_map().size());
        }

        std::printf("[EASIR] Editor: %zu nodes available for semantic grouping\n",
                    collector.names.size());
    }

    // Compile after all scene nodes have been added to the scene graph.
    // This creates the Vulkan descriptor sets, pipelines, and buffers for
    // every node in the graph.
    EASIR_TRACE("EasirRenderer::ctor: compiling viewer");
    m_viewer->compile();

    // Edge mode / editor preview: add edge detection quad.
    // Done AFTER compile so the offscreen images are compiled.
    if (m_edgeSceneView) {
        auto colorImage = m_edgeSceneView->image;
        uint32_t ew = colorImage->extent.width;
        uint32_t eh = colorImage->extent.height;

        std::printf("[EASIR] Edge: creating edge quad (%ux%u)\n", ew, eh);

        auto edgeNode = createEdgeDetectionPass(
            m_edgeSceneView,
            m_config.render_modes,
            ew, eh);
        if (edgeNode) {
            auto vp = vsg::ViewportState::create(0, 0, ew, eh);
            auto edgeView = vsg::View::create();
            edgeView->camera = vsg::Camera::create(
                vsg::Orthographic::create(-1, 1, -1, 1, -1, 1),
                vsg::LookAt::create(),
                vp);
            edgeView->addChild(edgeNode);

            if (m_edgePreviewEdgeGroup) {
                // Editor mode: add to the Switch's edge preview group.
                m_edgePreviewEdgeGroup->addChild(edgeView);
            } else if (m_edgeRenderGraph) {
                // Edge render mode: add directly to window RenderGraph.
                m_edgeRenderGraph->addChild(edgeView);
            }

            m_viewer->compile();
            std::printf("[EASIR] Edge: post-process pass added successfully\n");
        }
    }

    EASIR_TRACE("EasirRenderer::ctor: done");
}

EasirRenderer::~EasirRenderer() {
    if (m_device) {
        VkDevice vkDev = *m_device;
        vkDeviceWaitIdle(vkDev);

        if (m_staging_mapped) {
            vkUnmapMemory(vkDev, m_staging_mem);
            m_staging_mapped = nullptr;
        }
        if (m_readback_fence != VK_NULL_HANDLE) {
            vkDestroyFence(vkDev, m_readback_fence, nullptr);
        }
        if (m_readback_cmd != VK_NULL_HANDLE) {
            vkFreeCommandBuffers(vkDev, m_readback_pool, 1, &m_readback_cmd);
        }
        if (m_readback_pool != VK_NULL_HANDLE) {
            vkDestroyCommandPool(vkDev, m_readback_pool, nullptr);
        }
        if (m_staging_buf != VK_NULL_HANDLE) {
            vkDestroyBuffer(vkDev, m_staging_buf, nullptr);
        }
        if (m_staging_mem != VK_NULL_HANDLE) {
            vkFreeMemory(vkDev, m_staging_mem, nullptr);
        }
    }

    if (m_viewer) {
        m_viewer->close();
    }
}

// ---------------------------------------------------------------------------
// Private initialisation helpers
// ---------------------------------------------------------------------------

void EasirRenderer::init_headless() {
    const uint32_t w = static_cast<uint32_t>(m_config.camera.width);
    const uint32_t h = static_cast<uint32_t>(m_config.camera.height);

    m_image_width  = static_cast<int>(w);
    m_image_height = static_cast<int>(h);
    EASIR_TRACE("init_headless: %ux%u", w, h);

    // --- Create Vulkan instance (no surface extensions needed) -------------
    EASIR_TRACE("init_headless: creating Vulkan instance");
    vsg::Names instanceExtensions;
    vsg::Names deviceExtensions;

    vsg::Names layers;
    auto instance = vsg::Instance::create(instanceExtensions, layers);
    EASIR_TRACE("init_headless: enumerating physical devices");
    auto [physicalDevice, queueFamily] =
        instance->getPhysicalDeviceAndQueueFamily(VK_QUEUE_GRAPHICS_BIT);
    if (!physicalDevice || queueFamily < 0) {
        throw std::runtime_error("EASIR: No Vulkan device with graphics support");
    }
    EASIR_TRACE("init_headless: found device, queueFamily=%d", queueFamily);

    EASIR_TRACE("init_headless: creating logical device");
    vsg::QueueSettings queueSettings{vsg::QueueSetting{queueFamily, {1.0f}}};
    m_device = vsg::Device::create(physicalDevice, queueSettings, layers, deviceExtensions);
    m_queue_family = queueFamily;
    EASIR_TRACE("init_headless: logical device created OK");

    // --- Create offscreen color image (RGBA8, TRANSFER_SRC for readback) --
    VkFormat colorFormat = VK_FORMAT_R8G8B8A8_SRGB;
    VkFormat depthFormat = VK_FORMAT_D32_SFLOAT;

    EASIR_TRACE("init_headless: creating color image");
    auto colorImage = vsg::Image::create();
    colorImage->imageType   = VK_IMAGE_TYPE_2D;
    colorImage->format      = colorFormat;
    colorImage->extent      = VkExtent3D{w, h, 1};
    colorImage->mipLevels   = 1;
    colorImage->arrayLayers = 1;
    colorImage->samples     = VK_SAMPLE_COUNT_1_BIT;
    colorImage->tiling      = VK_IMAGE_TILING_OPTIMAL;
    colorImage->usage       = VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT | VK_IMAGE_USAGE_TRANSFER_SRC_BIT;
    colorImage->compile(m_device);
    auto colorMem = vsg::DeviceMemory::create(m_device, colorImage->getMemoryRequirements(m_device->deviceID),
                                               VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    colorImage->bind(colorMem, 0);
    m_color_image = colorImage;

    auto colorView = vsg::ImageView::create(colorImage, VK_IMAGE_ASPECT_COLOR_BIT);
    colorView->compile(m_device);
    EASIR_TRACE("init_headless: color image + view OK");

    // --- Create offscreen depth image -------------------------------------
    EASIR_TRACE("init_headless: creating depth image");
    auto depthImage = vsg::Image::create();
    depthImage->imageType   = VK_IMAGE_TYPE_2D;
    depthImage->format      = depthFormat;
    depthImage->extent      = VkExtent3D{w, h, 1};
    depthImage->mipLevels   = 1;
    depthImage->arrayLayers = 1;
    depthImage->samples     = VK_SAMPLE_COUNT_1_BIT;
    depthImage->tiling      = VK_IMAGE_TILING_OPTIMAL;
    depthImage->usage       = VK_IMAGE_USAGE_DEPTH_STENCIL_ATTACHMENT_BIT;
    depthImage->compile(m_device);
    auto depthMem = vsg::DeviceMemory::create(m_device, depthImage->getMemoryRequirements(m_device->deviceID),
                                               VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    depthImage->bind(depthMem, 0);
    m_depth_image = depthImage;

    auto depthView = vsg::ImageView::create(depthImage, VK_IMAGE_ASPECT_DEPTH_BIT);
    depthView->compile(m_device);
    EASIR_TRACE("init_headless: depth image + view OK");

    // --- Create RenderPass using VSG helper types --------------------------
    EASIR_TRACE("init_headless: creating render pass");
    auto colorAtt = vsg::defaultColorAttachment(colorFormat);
    colorAtt.finalLayout = VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL;

    auto depthAtt = vsg::defaultDepthAttachment(depthFormat);

    vsg::SubpassDescription subpass;
    subpass.pipelineBindPoint = VK_PIPELINE_BIND_POINT_GRAPHICS;
    subpass.colorAttachments  = {{0, VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL}};
    subpass.depthStencilAttachments = {{1, VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL}};

    vsg::SubpassDependency dependency;
    dependency.srcSubpass    = VK_SUBPASS_EXTERNAL;
    dependency.dstSubpass    = 0;
    dependency.srcStageMask  = VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT;
    dependency.dstStageMask  = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT | VK_PIPELINE_STAGE_EARLY_FRAGMENT_TESTS_BIT;
    dependency.srcAccessMask = VK_ACCESS_MEMORY_READ_BIT;
    dependency.dstAccessMask = VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT | VK_ACCESS_DEPTH_STENCIL_ATTACHMENT_WRITE_BIT;

    vsg::RenderPass::Attachments rpAttachments{colorAtt, depthAtt};
    vsg::RenderPass::Subpasses rpSubpasses{subpass};
    vsg::RenderPass::Dependencies rpDependencies{dependency};
    auto renderPassObj = vsg::RenderPass::create(m_device, rpAttachments, rpSubpasses, rpDependencies);
    EASIR_TRACE("init_headless: render pass OK");

    // --- Create Framebuffer -----------------------------------------------
    EASIR_TRACE("init_headless: creating framebuffer");
    vsg::ImageViews fbAttachments{colorView, depthView};
    auto framebuffer = vsg::Framebuffer::create(renderPassObj, fbAttachments, w, h, 1);
    EASIR_TRACE("init_headless: framebuffer OK");

    // --- Camera -----------------------------------------------------------
    EASIR_TRACE("init_headless: creating camera");
    auto perspective = vsg::Perspective::create(
        static_cast<double>(m_config.camera.fov_deg),
        static_cast<double>(w) / static_cast<double>(h),
        static_cast<double>(m_config.camera.near_plane),
        static_cast<double>(m_config.camera.far_plane));

    auto lookAt = vsg::LookAt::create(
        vsg::dvec3{0.0, 0.0, 10.0},
        vsg::dvec3{0.0, 0.0,  0.0},
        vsg::dvec3{0.0, 1.0,  0.0});

    auto viewportState = vsg::ViewportState::create(0, 0, w, h);
    m_camera = vsg::Camera::create(perspective, lookAt, viewportState);
    EASIR_TRACE("init_headless: camera OK");

    // --- Build RenderGraph using framebuffer (no window) ------------------
    EASIR_TRACE("init_headless: creating render graph + command graph");
    auto renderGraph = vsg::RenderGraph::create();
    renderGraph->framebuffer = framebuffer;
    renderGraph->renderArea  = VkRect2D{{0, 0}, {w, h}};
    renderGraph->setClearValues({{0.0f, 0.0f, 0.0f, 1.0f}}, {0.0f, 0});
    renderGraph->addChild(vsg::View::create(m_camera, m_scene_root));

    // CommandGraph using device + queue family (no window).
    auto commandGraph = vsg::CommandGraph::create(m_device, m_queue_family);
    commandGraph->addChild(renderGraph);

    m_viewer = vsg::Viewer::create();
    m_viewer->assignRecordAndSubmitTaskAndPresentation({commandGraph});
    EASIR_TRACE("init_headless: viewer + command graph OK");

    // --- Pre-allocate readback resources (reused every frame) ----------------
    EASIR_TRACE("init_headless: allocating readback resources");
    VkDevice vkDev = *m_device;

    VkCommandPoolCreateInfo poolInfo{VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO};
    poolInfo.queueFamilyIndex = static_cast<uint32_t>(m_queue_family);
    poolInfo.flags = VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT;
    vkCreateCommandPool(vkDev, &poolInfo, nullptr, &m_readback_pool);

    VkCommandBufferAllocateInfo allocCmdInfo{VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO};
    allocCmdInfo.commandPool = m_readback_pool;
    allocCmdInfo.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY;
    allocCmdInfo.commandBufferCount = 1;
    vkAllocateCommandBuffers(vkDev, &allocCmdInfo, &m_readback_cmd);

    const VkDeviceSize bufSize = static_cast<VkDeviceSize>(w) * h * 4;

    VkBufferCreateInfo bufCreateInfo{VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO};
    bufCreateInfo.size  = bufSize;
    bufCreateInfo.usage = VK_BUFFER_USAGE_TRANSFER_DST_BIT;
    vkCreateBuffer(vkDev, &bufCreateInfo, nullptr, &m_staging_buf);

    VkMemoryRequirements memReqs;
    vkGetBufferMemoryRequirements(vkDev, m_staging_buf, &memReqs);

    auto physDev = m_device->getPhysicalDevice();
    VkPhysicalDeviceMemoryProperties memProps;
    vkGetPhysicalDeviceMemoryProperties(*physDev, &memProps);

    uint32_t memType = UINT32_MAX;
    for (uint32_t i = 0; i < memProps.memoryTypeCount; ++i) {
        if ((memReqs.memoryTypeBits & (1u << i)) &&
            (memProps.memoryTypes[i].propertyFlags &
             (VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT)) ==
             (VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT)) {
            memType = i;
            break;
        }
    }
    EASIR_TRACE("init_headless: staging memType=%u", memType);

    VkMemoryAllocateInfo memAlloc{VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO};
    memAlloc.allocationSize  = memReqs.size;
    memAlloc.memoryTypeIndex = memType;
    vkAllocateMemory(vkDev, &memAlloc, nullptr, &m_staging_mem);
    vkBindBufferMemory(vkDev, m_staging_buf, m_staging_mem, 0);

    // Persistently map — stays valid until vkFreeMemory.
    vkMapMemory(vkDev, m_staging_mem, 0, bufSize, 0, &m_staging_mapped);

    VkFenceCreateInfo fenceInfo{VK_STRUCTURE_TYPE_FENCE_CREATE_INFO};
    vkCreateFence(vkDev, &fenceInfo, nullptr, &m_readback_fence);
    EASIR_TRACE("init_headless: readback resources OK — init complete");
}

void EasirRenderer::init_windowed() {
    const int w = m_config.camera.width;
    const int h = m_config.camera.height;
    const bool editor = m_config.global.editor_mode;

    auto windowTraits = vsg::WindowTraits::create();
    windowTraits->windowTitle = editor ? "EASIR - Editor Mode" : "EASIR";
    windowTraits->width  = static_cast<uint32_t>(w);
    windowTraits->height = static_cast<uint32_t>(h);
    // windowTraits->debugLayer = true;  // Enable for Vulkan validation debugging

    m_viewer = vsg::Viewer::create();

    auto window = vsg::Window::create(windowTraits);
    if (!window) {
        throw std::runtime_error("EASIR: Failed to create Vulkan window");
    }
    m_viewer->addWindow(window);

    // Camera setup.
    auto perspective = vsg::Perspective::create(
        static_cast<double>(m_config.camera.fov_deg),
        static_cast<double>(w) / static_cast<double>(h),
        static_cast<double>(m_config.camera.near_plane),
        static_cast<double>(m_config.camera.far_plane));

    // In editor mode, place camera 25 m back looking at origin.
    auto lookAt = editor
        ? vsg::LookAt::create(
              vsg::dvec3{0.0, 0.0, 100.0},
              vsg::dvec3{0.0, 0.0,  0.0},
              vsg::dvec3{0.0, 1.0,  0.0})
        : vsg::LookAt::create(
              vsg::dvec3{0.0, 0.0, 500.0},
              vsg::dvec3{0.0, 0.0,  0.0},
              vsg::dvec3{0.0, 1.0,  0.0});

    auto viewportState = vsg::ViewportState::create(0, 0,
        static_cast<uint32_t>(w), static_cast<uint32_t>(h));

    m_camera = vsg::Camera::create(perspective, lookAt, viewportState);

    const bool edgeMode = (m_config.camera.render_mode == "edge");
    vsg::ref_ptr<vsgImGui::RenderImGui> renderImGui;

    if (edgeMode && !editor) {
        // =================================================================
        // Edge mode: TWO CommandGraphs (VSG render-to-texture pattern)
        //   CG1 (submitOrder=-1): scene → offscreen FBO (captures depth)
        //   CG2 (submitOrder= 0): edge quad → window (samples depth)
        // =================================================================
        EASIR_TRACE("init_windowed: setting up two-pass edge rendering");

        auto device = window->getOrCreateDevice();
        auto swapchain = window->getOrCreateSwapchain();
        VkFormat colorFormat = swapchain->getImageFormat();  // MUST match swapchain
        VkFormat depthFormat = window->depthFormat();
        auto extent = window->extent2D();  // Actual window size (may differ from config)
        uint32_t uw = extent.width, uh = extent.height;

        // --- Determine MSAA sample count ---
        VkSampleCountFlagBits msaaSamples = VK_SAMPLE_COUNT_1_BIT;
        const auto& aaMode = m_config.render_modes.edge_aa_mode;
        if (aaMode == "msaa4x")      msaaSamples = VK_SAMPLE_COUNT_4_BIT;
        else if (aaMode == "msaa8x") msaaSamples = VK_SAMPLE_COUNT_8_BIT;
        const bool useMSAA = (msaaSamples != VK_SAMPLE_COUNT_1_BIT);

        std::printf("[EASIR] Edge: swapchain format=%d, depth format=%d, extent=%ux%u, AA=%s\n",
                    colorFormat, depthFormat, uw, uh, aaMode.c_str());

        // --- Offscreen color image ---
        // With MSAA: this is the multisample render target (not samplable).
        // Without MSAA: this is both render target and sampled by edge shader.
        auto offColor = vsg::Image::create();
        offColor->imageType   = VK_IMAGE_TYPE_2D;
        offColor->format      = colorFormat;
        offColor->extent      = VkExtent3D{uw, uh, 1};
        offColor->mipLevels   = 1;
        offColor->arrayLayers = 1;
        offColor->samples     = msaaSamples;
        offColor->tiling      = VK_IMAGE_TILING_OPTIMAL;
        offColor->usage       = VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT |
                                (useMSAA ? VkImageUsageFlags(0) : (VK_IMAGE_USAGE_SAMPLED_BIT | VK_IMAGE_USAGE_TRANSFER_SRC_BIT));
        offColor->compile(device);
        offColor->allocateAndBindMemory(device);
        auto offColorView = vsg::ImageView::create(offColor, VK_IMAGE_ASPECT_COLOR_BIT);
        offColorView->compile(device);

        // --- MSAA resolve target (single-sample, samplable) ---
        vsg::ref_ptr<vsg::Image> offResolve;
        vsg::ref_ptr<vsg::ImageView> offResolveView;
        if (useMSAA) {
            offResolve = vsg::Image::create();
            offResolve->imageType   = VK_IMAGE_TYPE_2D;
            offResolve->format      = colorFormat;
            offResolve->extent      = VkExtent3D{uw, uh, 1};
            offResolve->mipLevels   = 1;
            offResolve->arrayLayers = 1;
            offResolve->samples     = VK_SAMPLE_COUNT_1_BIT;
            offResolve->tiling      = VK_IMAGE_TILING_OPTIMAL;
            offResolve->usage       = VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT | VK_IMAGE_USAGE_SAMPLED_BIT | VK_IMAGE_USAGE_TRANSFER_SRC_BIT;
            offResolve->compile(device);
            offResolve->allocateAndBindMemory(device);
            offResolveView = vsg::ImageView::create(offResolve, VK_IMAGE_ASPECT_COLOR_BIT);
            offResolveView->compile(device);
        }

        // --- Offscreen depth image ---
        auto offDepth = vsg::Image::create();
        offDepth->imageType   = VK_IMAGE_TYPE_2D;
        offDepth->format      = depthFormat;
        offDepth->extent      = VkExtent3D{uw, uh, 1};
        offDepth->mipLevels   = 1;
        offDepth->arrayLayers = 1;
        offDepth->samples     = msaaSamples;  // Must match color sample count
        offDepth->tiling      = VK_IMAGE_TILING_OPTIMAL;
        offDepth->usage       = VK_IMAGE_USAGE_DEPTH_STENCIL_ATTACHMENT_BIT;
        offDepth->compile(device);
        offDepth->allocateAndBindMemory(device);
        auto offDepthView = vsg::ImageView::create(offDepth, VK_IMAGE_ASPECT_DEPTH_BIT);
        offDepthView->compile(device);

        std::printf("[EASIR] Edge: offscreen images created (%ux%u, MSAA=%s)\n",
                    uw, uh, useMSAA ? "yes" : "no");

        // --- Offscreen render pass ---
        vsg::RenderPass::Attachments attachments;
        vsg::SubpassDescription subpass;
        subpass.pipelineBindPoint = VK_PIPELINE_BIND_POINT_GRAPHICS;

        if (useMSAA) {
            // Attachment 0: MSAA color (render target)
            auto msaaColorAtt = vsg::defaultColorAttachment(colorFormat);
            msaaColorAtt.samples = msaaSamples;
            msaaColorAtt.storeOp = VK_ATTACHMENT_STORE_OP_DONT_CARE;  // Resolved, don't need to store
            msaaColorAtt.finalLayout = VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL;

            // Attachment 1: depth (MSAA)
            auto depthAtt = vsg::defaultDepthAttachment(depthFormat);
            depthAtt.samples = msaaSamples;

            // Attachment 2: resolve target (single-sample, samplable)
            auto resolveAtt = vsg::defaultColorAttachment(colorFormat);
            resolveAtt.samples = VK_SAMPLE_COUNT_1_BIT;
            resolveAtt.loadOp = VK_ATTACHMENT_LOAD_OP_DONT_CARE;
            resolveAtt.storeOp = VK_ATTACHMENT_STORE_OP_STORE;
            resolveAtt.finalLayout = VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL;

            attachments = {msaaColorAtt, depthAtt, resolveAtt};

            subpass.colorAttachments = {{0, VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL}};
            subpass.depthStencilAttachments = {{1, VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL}};
            subpass.resolveAttachments = {{2, VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL}};
        } else {
            // No MSAA: 2 attachments (color + depth)
            auto colorAtt = vsg::defaultColorAttachment(colorFormat);
            colorAtt.storeOp = VK_ATTACHMENT_STORE_OP_STORE;
            colorAtt.finalLayout = VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL;

            auto depthAtt = vsg::defaultDepthAttachment(depthFormat);

            attachments = {colorAtt, depthAtt};

            subpass.colorAttachments = {{0, VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL}};
            subpass.depthStencilAttachments = {{1, VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL}};
        }

        // Subpass dependencies matching vsgrendertotexture pattern (bidirectional).
        vsg::SubpassDependency dep0;
        dep0.srcSubpass    = VK_SUBPASS_EXTERNAL;
        dep0.dstSubpass    = 0;
        dep0.srcStageMask  = VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT;
        dep0.dstStageMask  = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT;
        dep0.srcAccessMask = VK_ACCESS_SHADER_READ_BIT;
        dep0.dstAccessMask = VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT;
        dep0.dependencyFlags = VK_DEPENDENCY_BY_REGION_BIT;

        vsg::SubpassDependency dep1;
        dep1.srcSubpass    = 0;
        dep1.dstSubpass    = VK_SUBPASS_EXTERNAL;
        dep1.srcStageMask  = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT;
        dep1.dstStageMask  = VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT;
        dep1.srcAccessMask = VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT;
        dep1.dstAccessMask = VK_ACCESS_SHADER_READ_BIT;
        dep1.dependencyFlags = VK_DEPENDENCY_BY_REGION_BIT;

        auto offRenderPass = vsg::RenderPass::create(device,
            attachments,
            vsg::RenderPass::Subpasses{subpass},
            vsg::RenderPass::Dependencies{dep0, dep1});

        // Framebuffer: 2 attachments (no MSAA) or 3 (MSAA color + depth + resolve)
        vsg::ImageViews fbViews = useMSAA
            ? vsg::ImageViews{offColorView, offDepthView, offResolveView}
            : vsg::ImageViews{offColorView, offDepthView};
        auto offFramebuffer = vsg::Framebuffer::create(offRenderPass, fbViews, uw, uh, 1);

        // --- Offscreen RenderGraph + CommandGraph (submitOrder = -1) ---
        // Create a camera specifically for the offscreen render (matching FBO size).
        auto offVP = vsg::ViewportState::create(0, 0, uw, uh);
        auto offCamera = vsg::Camera::create(
            vsg::Perspective::create(
                static_cast<double>(m_config.camera.fov_deg),
                static_cast<double>(uw) / static_cast<double>(uh),
                static_cast<double>(m_config.camera.near_plane),
                static_cast<double>(m_config.camera.far_plane)),
            lookAt,
            offVP);
        m_camera = offCamera;  // Use this camera for both passes

        auto offRenderGraph = vsg::RenderGraph::create();
        offRenderGraph->framebuffer = offFramebuffer;
        offRenderGraph->renderArea  = VkRect2D{{0, 0}, {uw, uh}};
        offRenderGraph->previous_extent = VkExtent2D{uw, uh};
        offRenderGraph->viewportState->set(0, 0, uw, uh);
        // CRITICAL: Set clear values manually
        offRenderGraph->clearValues.resize(2);
        offRenderGraph->clearValues[0].color = {{0.0f, 0.0f, 0.0f, 1.0f}};  // Black background (edge shader detects non-black as geometry)
        offRenderGraph->clearValues[1].depthStencil = {0.0f, 0};  // VSG uses reverse-Z: 0=far, 1=near

        auto offView = vsg::View::create(offCamera, m_scene_root);
        offRenderGraph->addChild(offView);

        std::printf("[EASIR] Edge: offscreen View children=%zu, scene_root children=%zu\n",
                    offView->children.size(), m_scene_root->children.size());


        // Find the graphics queue family.
        int queueFamily = 0;
        {
            auto physDev = device->getPhysicalDevice();
            auto qfProps = physDev->getQueueFamilyProperties();
            for (uint32_t i = 0; i < qfProps.size(); ++i) {
                if (qfProps[i].queueFlags & VK_QUEUE_GRAPHICS_BIT) {
                    queueFamily = static_cast<int>(i);
                    break;
                }
            }
        }

        // --- Single CommandGraph with TWO RenderGraphs ---
        // Both in the same CG ensures pipelines compile in one context.
        // Child order: offscreen RG first, window RG second.
        auto windowRG = vsg::RenderGraph::create(window);
        windowRG->setClearValues({{0.0f, 0.0f, 0.0f, 1.0f}}, {1.0f, 0});
        m_edgeRenderGraph = windowRG;
        // Edge shader samples the resolved (single-sample) image, or the
        // direct color image when MSAA is off.
        m_edgeSceneView = useMSAA ? offResolveView : offColorView;

        // Single window-based CommandGraph with both RenderGraphs.
        // Offscreen RG runs first (child order), window RG second.
        auto commandGraph = vsg::CommandGraph::create(window);
        commandGraph->addChild(offRenderGraph);
        commandGraph->addChild(windowRG);

        m_viewer->assignRecordAndSubmitTaskAndPresentation({commandGraph});

        std::printf("[EASIR] Edge: single window CG with offscreen + window RGs\n");

    } else if (editor) {
        // =================================================================
        // Editor mode with edge preview toggle
        // =================================================================
        // Same offscreen FBO setup as edge mode for the preview.
        auto device = window->getOrCreateDevice();
        auto swapchain = window->getOrCreateSwapchain();
        VkFormat colorFormat = swapchain->getImageFormat();
        VkFormat depthFormat = window->depthFormat();
        auto extent = window->extent2D();
        uint32_t uw = extent.width, uh = extent.height;

        // Offscreen color image (for edge preview, no MSAA in editor).
        auto offColor = vsg::Image::create();
        offColor->imageType   = VK_IMAGE_TYPE_2D;
        offColor->format      = colorFormat;
        offColor->extent      = VkExtent3D{uw, uh, 1};
        offColor->mipLevels   = 1;
        offColor->arrayLayers = 1;
        offColor->samples     = VK_SAMPLE_COUNT_1_BIT;
        offColor->tiling      = VK_IMAGE_TILING_OPTIMAL;
        offColor->usage       = VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT | VK_IMAGE_USAGE_SAMPLED_BIT | VK_IMAGE_USAGE_TRANSFER_SRC_BIT;
        offColor->compile(device);
        offColor->allocateAndBindMemory(device);
        auto offColorView = vsg::ImageView::create(offColor, VK_IMAGE_ASPECT_COLOR_BIT);
        offColorView->compile(device);

        auto offDepth = vsg::Image::create();
        offDepth->imageType   = VK_IMAGE_TYPE_2D;
        offDepth->format      = depthFormat;
        offDepth->extent      = VkExtent3D{uw, uh, 1};
        offDepth->mipLevels   = 1;
        offDepth->arrayLayers = 1;
        offDepth->samples     = VK_SAMPLE_COUNT_1_BIT;
        offDepth->tiling      = VK_IMAGE_TILING_OPTIMAL;
        offDepth->usage       = VK_IMAGE_USAGE_DEPTH_STENCIL_ATTACHMENT_BIT;
        offDepth->compile(device);
        offDepth->allocateAndBindMemory(device);
        auto offDepthView = vsg::ImageView::create(offDepth, VK_IMAGE_ASPECT_DEPTH_BIT);
        offDepthView->compile(device);

        // Offscreen render pass (same as edge mode).
        auto colorAtt = vsg::defaultColorAttachment(colorFormat);
        colorAtt.storeOp = VK_ATTACHMENT_STORE_OP_STORE;
        colorAtt.finalLayout = VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL;
        auto depthAtt = vsg::defaultDepthAttachment(depthFormat);

        vsg::SubpassDescription subpass;
        subpass.pipelineBindPoint = VK_PIPELINE_BIND_POINT_GRAPHICS;
        subpass.colorAttachments = {{0, VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL}};
        subpass.depthStencilAttachments = {{1, VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL}};

        vsg::SubpassDependency dep0;
        dep0.srcSubpass = VK_SUBPASS_EXTERNAL; dep0.dstSubpass = 0;
        dep0.srcStageMask = VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT;
        dep0.dstStageMask = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT;
        dep0.srcAccessMask = VK_ACCESS_SHADER_READ_BIT;
        dep0.dstAccessMask = VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT;
        dep0.dependencyFlags = VK_DEPENDENCY_BY_REGION_BIT;

        vsg::SubpassDependency dep1;
        dep1.srcSubpass = 0; dep1.dstSubpass = VK_SUBPASS_EXTERNAL;
        dep1.srcStageMask = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT;
        dep1.dstStageMask = VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT;
        dep1.srcAccessMask = VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT;
        dep1.dstAccessMask = VK_ACCESS_SHADER_READ_BIT;
        dep1.dependencyFlags = VK_DEPENDENCY_BY_REGION_BIT;

        auto offRenderPass = vsg::RenderPass::create(device,
            vsg::RenderPass::Attachments{colorAtt, depthAtt},
            vsg::RenderPass::Subpasses{subpass},
            vsg::RenderPass::Dependencies{dep0, dep1});

        auto offFramebuffer = vsg::Framebuffer::create(offRenderPass,
            vsg::ImageViews{offColorView, offDepthView}, uw, uh, 1);

        // Offscreen RenderGraph — scene renders here for edge preview.
        auto offRenderGraph = vsg::RenderGraph::create();
        offRenderGraph->framebuffer = offFramebuffer;
        offRenderGraph->renderArea  = VkRect2D{{0, 0}, {uw, uh}};
        offRenderGraph->previous_extent = VkExtent2D{uw, uh};
        offRenderGraph->viewportState->set(0, 0, uw, uh);
        offRenderGraph->clearValues.resize(2);
        offRenderGraph->clearValues[0].color = {{0.0f, 0.0f, 0.0f, 1.0f}};
        offRenderGraph->clearValues[1].depthStencil = {0.0f, 0};
        offRenderGraph->addChild(vsg::View::create(m_camera, m_scene_root));

        // Window RenderGraph with a Switch for toggling views.
        auto windowRG = vsg::RenderGraph::create(window);
        windowRG->setClearValues({{0.0f, 0.0f, 0.0f, 1.0f}}, {0.0f, 0});

        // Switch child 0: normal editor view (semantic + ImGui)
        // Switch child 1: edge preview (edge quad + ImGui)
        m_edgePreviewSwitch = vsg::Switch::create();

        // Child 0: normal scene view
        auto normalView = vsg::View::create(m_camera, m_scene_root);
        m_edgePreviewSwitch->addChild(true, normalView);  // ON by default

        // Child 1: edge quad (placeholder — added after compile)
        auto edgeGroup = vsg::Group::create();
        m_edgePreviewSwitch->addChild(false, edgeGroup);  // OFF by default
        m_edgePreviewEdgeGroup = edgeGroup;

        windowRG->addChild(m_edgePreviewSwitch);

        // ImGui overlay (always visible, on top of either view).
        renderImGui = vsgImGui::RenderImGui::create(window);
        windowRG->addChild(renderImGui);

        m_edgeSceneView = offColorView;
        m_edgeRenderGraph = windowRG;

        auto commandGraph = vsg::CommandGraph::create(window);
        commandGraph->addChild(offRenderGraph);  // Always render offscreen
        commandGraph->addChild(windowRG);         // Window shows switch + ImGui
        m_viewer->assignRecordAndSubmitTaskAndPresentation({commandGraph});

        std::printf("[EASIR] Editor: edge preview infrastructure created\n");

    } else {
        // =================================================================
        // Normal rendering (PBR, semantic) — single CommandGraph
        // =================================================================
        auto renderGraph = vsg::RenderGraph::create(window);
        renderGraph->setClearValues({{0.0f, 0.0f, 0.0f, 1.0f}}, {0.0f, 0});
        renderGraph->addChild(vsg::View::create(m_camera, m_scene_root));

        auto commandGraph = vsg::CommandGraph::create(window);
        commandGraph->addChild(renderGraph);
        m_viewer->assignRecordAndSubmitTaskAndPresentation({commandGraph});
    }

    // Bind close-window event so the render loop can exit cleanly.
    m_viewer->addEventHandler(vsg::CloseHandler::create(m_viewer));

    // In editor mode, add trackball camera controls.
    if (editor) {
        // ImGui event handler must be first so it consumes mouse clicks on the GUI panel
        // before the trackball/editor handlers process them.
        m_viewer->addEventHandler(vsgImGui::SendEventsToImGui::create());
        auto trackball = vsg::Trackball::create(m_camera);
        trackball->addWindow(window);

        // Right-drag = orbit, middle-drag = pan, scroll = zoom
        // Left-click reserved for selection (future).
        trackball->rotateButtonMask = vsg::BUTTON_MASK_3;
        trackball->panButtonMask    = vsg::BUTTON_MASK_2;
        trackball->zoomButtonMask   = vsg::BUTTON_MASK_OFF;
        trackball->supportsThrow    = false;

        // Disable Trackball's built-in keyboard controls (WASD etc.)
        // so they don't conflict with future editor keybindings.
        trackball->turnLeftKey    = {};
        trackball->turnRightKey   = {};
        trackball->pitchUpKey     = {};
        trackball->pitchDownKey   = {};
        trackball->rollLeftKey    = {};
        trackball->rollRightKey   = {};
        trackball->moveForwardKey = {};
        trackball->moveBackwardKey= {};
        trackball->moveLeftKey    = {};
        trackball->moveRightKey   = {};
        trackball->moveUpKey      = {};
        trackball->moveDownKey    = {};

        // Editor handler: selection, highlight, zoom-toward-cursor.
        // Added BEFORE trackball so it intercepts scroll events first.
        auto editorHandler = EditorHandler::create(m_camera, m_scene_root, trackball, m_viewer);
        m_editor_handler = editorHandler;
        m_viewer->addEventHandler(editorHandler);

        m_viewer->addEventHandler(trackball);

        // Register ImGui draw callback — the editor handler draws the GUI panel.
        renderImGui->add([editorHandler]() { return editorHandler->draw_gui(); });
    }
}

// ---------------------------------------------------------------------------
// Per-frame API
// ---------------------------------------------------------------------------

void EasirRenderer::set_state(const EasirState& state) {
    m_state = state;
}

bool EasirRenderer::render() {
    if (!m_viewer) {
        return false;
    }

    if (!m_viewer->advanceToNextFrame()) {
        return false; // viewer requested shutdown (windowed mode)
    }

    // Apply dynamic state to the scene.
    update_scene_from_state();

    // Execute render passes.
    RenderContext ctx{
        .viewer     = m_viewer,
        .scene_root = m_scene_root,
        .config     = &m_config,
        .state      = &m_state,
        .frame      = m_viewer->getFrameStamp()->frameCount,
    };
    m_pipeline->execute(ctx);

    m_viewer->handleEvents();
    m_viewer->update();
    m_viewer->recordAndSubmit();

    // Edge mode: offscreen color diagnostics (disabled — enable for debugging).
    if (false && m_edgeSceneView && FrameLogger::active()) {
        auto device = m_viewer->windows().front()->getOrCreateDevice();
        auto colorImage = m_edgeSceneView->image;
        if (device && colorImage) {
            uint32_t cw = colorImage->extent.width;
            uint32_t ch = colorImage->extent.height;
            VkDeviceSize bufSize = static_cast<VkDeviceSize>(cw) * ch * 4;
            VkDevice vkDev = *device;

            // Staging buffer
            VkBufferCreateInfo bufInfo{VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO};
            bufInfo.size = bufSize;
            bufInfo.usage = VK_BUFFER_USAGE_TRANSFER_DST_BIT;
            VkBuffer stagingBuf;
            vkCreateBuffer(vkDev, &bufInfo, nullptr, &stagingBuf);
            VkMemoryRequirements memReqs;
            vkGetBufferMemoryRequirements(vkDev, stagingBuf, &memReqs);

            auto physDev = device->getPhysicalDevice();
            VkPhysicalDeviceMemoryProperties memProps;
            vkGetPhysicalDeviceMemoryProperties(*physDev, &memProps);
            uint32_t memType = 0;
            for (uint32_t i = 0; i < memProps.memoryTypeCount; ++i) {
                if ((memReqs.memoryTypeBits & (1u << i)) &&
                    (memProps.memoryTypes[i].propertyFlags &
                     (VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT)) ==
                     (VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT)) {
                    memType = i; break;
                }
            }
            VkDeviceMemory stagingMem;
            VkMemoryAllocateInfo memAlloc{VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO};
            memAlloc.allocationSize = memReqs.size;
            memAlloc.memoryTypeIndex = memType;
            vkAllocateMemory(vkDev, &memAlloc, nullptr, &stagingMem);
            vkBindBufferMemory(vkDev, stagingBuf, stagingMem, 0);

            // Command buffer
            int qf = 0;
            auto qfProps = physDev->getQueueFamilyProperties();
            for (uint32_t i = 0; i < qfProps.size(); ++i) {
                if (qfProps[i].queueFlags & VK_QUEUE_GRAPHICS_BIT) { qf = (int)i; break; }
            }
            VkCommandPool cmdPool;
            VkCommandPoolCreateInfo poolInfo{VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO};
            poolInfo.queueFamilyIndex = (uint32_t)qf;
            poolInfo.flags = VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT;
            vkCreateCommandPool(vkDev, &poolInfo, nullptr, &cmdPool);
            VkCommandBuffer cmd;
            VkCommandBufferAllocateInfo allocCmd{VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO};
            allocCmd.commandPool = cmdPool;
            allocCmd.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY;
            allocCmd.commandBufferCount = 1;
            vkAllocateCommandBuffers(vkDev, &allocCmd, &cmd);
            VkFence fence;
            VkFenceCreateInfo fenceInfo{VK_STRUCTURE_TYPE_FENCE_CREATE_INFO};
            vkCreateFence(vkDev, &fenceInfo, nullptr, &fence);

            VkCommandBufferBeginInfo beginInfo{VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO};
            beginInfo.flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;
            vkBeginCommandBuffer(cmd, &beginInfo);

            VkImage srcImage = colorImage->vk(device->deviceID);

            // Transition from whatever layout to TRANSFER_SRC
            VkImageMemoryBarrier toTransfer{VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER};
            toTransfer.oldLayout = VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL;
            toTransfer.newLayout = VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL;
            toTransfer.srcAccessMask = VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT;
            toTransfer.dstAccessMask = VK_ACCESS_TRANSFER_READ_BIT;
            toTransfer.image = srcImage;
            toTransfer.subresourceRange = {VK_IMAGE_ASPECT_COLOR_BIT, 0, 1, 0, 1};
            vkCmdPipelineBarrier(cmd, VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT,
                VK_PIPELINE_STAGE_TRANSFER_BIT, 0, 0, nullptr, 0, nullptr, 1, &toTransfer);

            VkBufferImageCopy region{};
            region.imageSubresource = {VK_IMAGE_ASPECT_COLOR_BIT, 0, 0, 1};
            region.imageExtent = {cw, ch, 1};
            vkCmdCopyImageToBuffer(cmd, srcImage, VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL,
                                   stagingBuf, 1, &region);

            // Transition back
            VkImageMemoryBarrier toOrig{VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER};
            toOrig.oldLayout = VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL;
            toOrig.newLayout = VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL;
            toOrig.srcAccessMask = VK_ACCESS_TRANSFER_READ_BIT;
            toOrig.dstAccessMask = VK_ACCESS_SHADER_READ_BIT;
            toOrig.image = srcImage;
            toOrig.subresourceRange = {VK_IMAGE_ASPECT_COLOR_BIT, 0, 1, 0, 1};
            vkCmdPipelineBarrier(cmd, VK_PIPELINE_STAGE_TRANSFER_BIT,
                VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT, 0, 0, nullptr, 0, nullptr, 1, &toOrig);

            vkEndCommandBuffer(cmd);

            auto queue = device->getQueue((uint32_t)qf);
            VkSubmitInfo submitInfo{VK_STRUCTURE_TYPE_SUBMIT_INFO};
            submitInfo.commandBufferCount = 1;
            submitInfo.pCommandBuffers = &cmd;
            vkQueueSubmit(*queue, 1, &submitInfo, fence);
            vkWaitForFences(vkDev, 1, &fence, VK_TRUE, UINT64_MAX);

            // Read pixels and analyze
            void* mapped = nullptr;
            vkMapMemory(vkDev, stagingMem, 0, bufSize, 0, &mapped);
            const uint8_t* pixels = static_cast<const uint8_t*>(mapped);

            // Count pixels that differ from the clear color (BGRA format)
            // Clear = magenta = BGRA(255, 0, 255, 255)
            uint32_t total = cw * ch;
            uint32_t geomPixels = 0;
            uint32_t uniqueColors = 0;
            uint8_t lastB = 255, lastG = 0, lastR = 255;
            for (uint32_t i = 0; i < total; ++i) {
                uint8_t b = pixels[i * 4 + 0];
                uint8_t g = pixels[i * 4 + 1];
                uint8_t r = pixels[i * 4 + 2];
                // Check if NOT magenta clear color
                if (b != 255 || g != 0 || r != 255) {
                    geomPixels++;
                    if (b != lastB || g != lastG || r != lastR) {
                        uniqueColors++;
                        lastB = b; lastG = g; lastR = r;
                    }
                }
            }

            // Sample several positions
            auto sampleAt = [&](uint32_t x, uint32_t y) {
                uint32_t idx = (y * cw + x) * 4;
                std::printf("  (%u,%u)=BGRA(%u,%u,%u,%u)", x, y,
                    pixels[idx], pixels[idx+1], pixels[idx+2], pixels[idx+3]);
            };
            std::printf("[EASIR] Offscreen: %ux%u, geometry=%u (%.1f%%), uniqueColors=%u\n",
                cw, ch, geomPixels, 100.0f * geomPixels / total, uniqueColors);
            std::printf("[EASIR] Samples:");
            sampleAt(cw/2, ch/2);     // center
            sampleAt(0, 0);           // top-left
            sampleAt(cw-1, 0);        // top-right
            sampleAt(cw/2, 0);        // top-center
            sampleAt(cw/2, ch-1);     // bottom-center
            std::printf("\n");
            std::fflush(stdout);

            vkUnmapMemory(vkDev, stagingMem);
            vkDestroyFence(vkDev, fence, nullptr);
            vkFreeCommandBuffers(vkDev, cmdPool, 1, &cmd);
            vkDestroyCommandPool(vkDev, cmdPool, nullptr);
            vkDestroyBuffer(vkDev, stagingBuf, nullptr);
            vkFreeMemory(vkDev, stagingMem, nullptr);

            FrameLogger::decrement();
        }
    }

    if (m_mode == RenderMode::Windowed) {
        m_viewer->present();
    } else {
        // Headless: no swapchain to present — read pixels from offscreen image.
        readback_pixels();
    }

    return true;
}

// ---------------------------------------------------------------------------
// Quaternion-to-LookAt helper
// ---------------------------------------------------------------------------

/// Convert a unit quaternion [x, y, z, w] to forward and up vectors.
/// Convention: forward = -Z in body frame, up = +Y in body frame.
static void quat_to_forward_up(const std::array<double, 4>& q,
                                vsg::dvec3& forward,
                                vsg::dvec3& up) {
    const double x = q[0], y = q[1], z = q[2], w = q[3];

    // Rotate body -Z axis to get forward direction.
    forward = vsg::dvec3{
        -(2.0 * (x * z + w * y)),
        -(2.0 * (y * z - w * x)),
        -(1.0 - 2.0 * (x * x + y * y)),
    };

    // Rotate body +Y axis to get up direction.
    up = vsg::dvec3{
        2.0 * (x * y - w * z),
        1.0 - 2.0 * (x * x + z * z),
        2.0 * (y * z + w * x),
    };
}

void EasirRenderer::update_scene_from_state() {
    // Update camera transform from state.
    // In editor mode, skip camera updates — Trackball controls the camera.
    if (m_camera && !m_config.global.editor_mode) {
        auto* lookAt = dynamic_cast<vsg::LookAt*>(m_camera->viewMatrix.get());
        if (lookAt) {
            if (m_state.camera_follow_spacecraft && !m_state.scene_objects.empty()) {
                // Parent camera to the first scene object: offset 10 m along
                // the object's local +Z axis.
                const auto& obj = m_state.scene_objects.front();
                vsg::dvec3 obj_pos{obj.position[0], obj.position[1], obj.position[2]};

                vsg::dvec3 fwd, up_vec;
                quat_to_forward_up(obj.orientation, fwd, up_vec);

                lookAt->eye    = obj_pos - fwd * 10.0; // 10 m behind
                lookAt->center = obj_pos;
                lookAt->up     = up_vec;
            } else {
                // Use explicit camera position + orientation quaternion.
                vsg::dvec3 eye{
                    m_state.camera_position[0],
                    m_state.camera_position[1],
                    m_state.camera_position[2],
                };

                vsg::dvec3 fwd, up_vec;
                quat_to_forward_up(m_state.camera_orientation, fwd, up_vec);

                lookAt->eye    = eye;
                lookAt->center = eye + fwd;
                lookAt->up     = up_vec;
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Headless pixel readback (GPU → CPU)
// ---------------------------------------------------------------------------

void EasirRenderer::readback_pixels() {
    if (!m_device || !m_color_image) return;

    const uint32_t w = static_cast<uint32_t>(m_image_width);
    const uint32_t h = static_cast<uint32_t>(m_image_height);
    const VkDeviceSize bufSize = static_cast<VkDeviceSize>(w) * h * 4;
    VkDevice vkDev = *m_device;

    VkImage srcImage = m_color_image->vk(m_device->deviceID);
    auto queue = m_device->getQueue(static_cast<uint32_t>(m_queue_family));
    VkQueue vkQueue = *queue;

    // Reset the reusable command buffer and re-record.
    vkResetCommandBuffer(m_readback_cmd, 0);

    VkCommandBufferBeginInfo beginInfo{VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO};
    beginInfo.flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;
    vkBeginCommandBuffer(m_readback_cmd, &beginInfo);

    // Transition color image: COLOR_ATTACHMENT_OPTIMAL → TRANSFER_SRC
    VkImageMemoryBarrier toTransfer{VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER};
    toTransfer.oldLayout = VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL;
    toTransfer.newLayout = VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL;
    toTransfer.srcAccessMask = VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT;
    toTransfer.dstAccessMask = VK_ACCESS_TRANSFER_READ_BIT;
    toTransfer.image = srcImage;
    toTransfer.subresourceRange = {VK_IMAGE_ASPECT_COLOR_BIT, 0, 1, 0, 1};
    vkCmdPipelineBarrier(m_readback_cmd,
        VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT, VK_PIPELINE_STAGE_TRANSFER_BIT,
        0, 0, nullptr, 0, nullptr, 1, &toTransfer);

    VkBufferImageCopy region{};
    region.imageSubresource = {VK_IMAGE_ASPECT_COLOR_BIT, 0, 0, 1};
    region.imageExtent = {w, h, 1};
    vkCmdCopyImageToBuffer(m_readback_cmd, srcImage, VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL,
                           m_staging_buf, 1, &region);

    // Transition back to COLOR_ATTACHMENT_OPTIMAL for the next frame.
    VkImageMemoryBarrier toColor{VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER};
    toColor.oldLayout = VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL;
    toColor.newLayout = VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL;
    toColor.srcAccessMask = VK_ACCESS_TRANSFER_READ_BIT;
    toColor.dstAccessMask = VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT;
    toColor.image = srcImage;
    toColor.subresourceRange = {VK_IMAGE_ASPECT_COLOR_BIT, 0, 1, 0, 1};
    vkCmdPipelineBarrier(m_readback_cmd,
        VK_PIPELINE_STAGE_TRANSFER_BIT, VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT,
        0, 0, nullptr, 0, nullptr, 1, &toColor);

    vkEndCommandBuffer(m_readback_cmd);

    // Submit with fence for precise synchronisation.
    vkResetFences(vkDev, 1, &m_readback_fence);
    VkSubmitInfo submitInfo{VK_STRUCTURE_TYPE_SUBMIT_INFO};
    submitInfo.commandBufferCount = 1;
    submitInfo.pCommandBuffers = &m_readback_cmd;
    vkQueueSubmit(vkQueue, 1, &submitInfo, m_readback_fence);
    vkWaitForFences(vkDev, 1, &m_readback_fence, VK_TRUE, UINT64_MAX);

    // Pixels now reside in the persistently-mapped staging buffer.
    // get_image() returns m_staging_mapped directly — zero CPU copy.
    m_image_ready = true;
}

// ---------------------------------------------------------------------------
// Image output
// ---------------------------------------------------------------------------

bool EasirRenderer::get_image(const uint8_t** data,
                              int* width, int* height, int* channels) const {
    if (!m_image_ready || !m_staging_mapped) {
        return false;
    }
    *data     = static_cast<const uint8_t*>(m_staging_mapped);
    *width    = m_image_width;
    *height   = m_image_height;
    *channels = 4;
    return true;
}

} // namespace easir
