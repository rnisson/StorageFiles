#include "easir/renderer.h"
#include "easir/trace.h"

#include <vsg/vk/Instance.h>
#include <vsg/vk/PhysicalDevice.h>
#include <vsg/vk/Device.h>
#include <vsg/vk/DeviceMemory.h>
#include <vsg/vk/CommandPool.h>
#include <vsg/vk/Framebuffer.h>
#include <vsg/vk/RenderPass.h>
#include <vsg/state/Image.h>
#include <vsg/state/ImageView.h>
#include <vsg/commands/CopyImageToBuffer.h>
#include <vsg/commands/PipelineBarrier.h>

#include <stdexcept>
#include <format>
#include <cstring>
#include <cmath>
#include <algorithm>

namespace easir {

// ---------------------------------------------------------------------------
// Construction / destruction
// ---------------------------------------------------------------------------

EasirRenderer::EasirRenderer(const EasirConfig& config, RenderMode mode)
    : m_config(config)
    , m_mode(mode)
    , m_pipeline(std::make_unique<RenderPipeline>())
{
    EASIR_TRACE("EasirRenderer::ctor: enter, mode=%s",
                mode == RenderMode::Headless ? "Headless" : "Windowed");

    // Create the vsgXchange-aware options object once.
    EASIR_TRACE("EasirRenderer::ctor: creating vsg::Options");
    m_vsg_options = vsg::Options::create();
    EASIR_TRACE("EasirRenderer::ctor: vsg::Options OK, creating vsgXchange::all");
    auto xchange = vsgXchange::all::create();
    EASIR_TRACE("EasirRenderer::ctor: vsgXchange::all created, adding to options");
    m_vsg_options->add(xchange);
    EASIR_TRACE("EasirRenderer::ctor: vsgXchange added OK");

    // Build the top-level scene root.
    EASIR_TRACE("EasirRenderer::ctor: creating scene root");
    m_scene_root = vsg::Group::create();

    if (m_mode == RenderMode::Headless) {
        init_headless();
    } else {
        init_windowed();
    }

    // Build the render pipeline now that the viewer exists.
    EASIR_TRACE("EasirRenderer::ctor: building render pipeline");
    RenderContext ctx{
        .viewer     = m_viewer,
        .scene_root = m_scene_root,
        .config     = &m_config,
        .state      = &m_state,
        .frame      = 0,
    };
    m_pipeline->build(m_config, ctx);

    // Compile after all scene nodes have been added to the scene graph.
    // This creates the Vulkan descriptor sets, pipelines, and buffers for
    // every node in the graph.
    EASIR_TRACE("EasirRenderer::ctor: compiling viewer");
    m_viewer->compile();
    EASIR_TRACE("EasirRenderer::ctor: done");
}

EasirRenderer::~EasirRenderer() {
    if (m_device) {
        VkDevice vkDev = *m_device;
        vkDeviceWaitIdle(vkDev);

        if (m_staging_mapped) {
            vkUnmapMemory(vkDev, m_staging_mem);
            m_staging_mapped = nullptr;
        }
        if (m_readback_fence != VK_NULL_HANDLE) {
            vkDestroyFence(vkDev, m_readback_fence, nullptr);
        }
        if (m_readback_cmd != VK_NULL_HANDLE) {
            vkFreeCommandBuffers(vkDev, m_readback_pool, 1, &m_readback_cmd);
        }
        if (m_readback_pool != VK_NULL_HANDLE) {
            vkDestroyCommandPool(vkDev, m_readback_pool, nullptr);
        }
        if (m_staging_buf != VK_NULL_HANDLE) {
            vkDestroyBuffer(vkDev, m_staging_buf, nullptr);
        }
        if (m_staging_mem != VK_NULL_HANDLE) {
            vkFreeMemory(vkDev, m_staging_mem, nullptr);
        }
    }

    if (m_viewer) {
        m_viewer->close();
    }
}

// ---------------------------------------------------------------------------
// Private initialisation helpers
// ---------------------------------------------------------------------------

void EasirRenderer::init_headless() {
    const uint32_t w = static_cast<uint32_t>(m_config.camera.width);
    const uint32_t h = static_cast<uint32_t>(m_config.camera.height);

    m_image_width  = static_cast<int>(w);
    m_image_height = static_cast<int>(h);
    EASIR_TRACE("init_headless: %ux%u", w, h);

    // --- Create Vulkan instance (no surface extensions needed) -------------
    EASIR_TRACE("init_headless: creating Vulkan instance");
    vsg::Names instanceExtensions;
    vsg::Names deviceExtensions;

    vsg::Names layers;
    auto instance = vsg::Instance::create(instanceExtensions, layers);
    EASIR_TRACE("init_headless: enumerating physical devices");
    auto [physicalDevice, queueFamily] =
        instance->getPhysicalDeviceAndQueueFamily(VK_QUEUE_GRAPHICS_BIT);
    if (!physicalDevice || queueFamily < 0) {
        throw std::runtime_error("EASIR: No Vulkan device with graphics support");
    }
    EASIR_TRACE("init_headless: found device, queueFamily=%d", queueFamily);

    EASIR_TRACE("init_headless: creating logical device");
    vsg::QueueSettings queueSettings{vsg::QueueSetting{queueFamily, {1.0f}}};
    m_device = vsg::Device::create(physicalDevice, queueSettings, layers, deviceExtensions);
    m_queue_family = queueFamily;
    EASIR_TRACE("init_headless: logical device created OK");

    // --- Create offscreen color image (RGBA8, TRANSFER_SRC for readback) --
    VkFormat colorFormat = VK_FORMAT_R8G8B8A8_SRGB;
    VkFormat depthFormat = VK_FORMAT_D32_SFLOAT;

    EASIR_TRACE("init_headless: creating color image");
    auto colorImage = vsg::Image::create();
    colorImage->imageType   = VK_IMAGE_TYPE_2D;
    colorImage->format      = colorFormat;
    colorImage->extent      = VkExtent3D{w, h, 1};
    colorImage->mipLevels   = 1;
    colorImage->arrayLayers = 1;
    colorImage->samples     = VK_SAMPLE_COUNT_1_BIT;
    colorImage->tiling      = VK_IMAGE_TILING_OPTIMAL;
    colorImage->usage       = VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT | VK_IMAGE_USAGE_TRANSFER_SRC_BIT;
    colorImage->compile(m_device);
    auto colorMem = vsg::DeviceMemory::create(m_device, colorImage->getMemoryRequirements(m_device->deviceID),
                                               VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    colorImage->bind(colorMem, 0);
    m_color_image = colorImage;

    auto colorView = vsg::ImageView::create(colorImage, VK_IMAGE_ASPECT_COLOR_BIT);
    colorView->compile(m_device);
    EASIR_TRACE("init_headless: color image + view OK");

    // --- Create offscreen depth image -------------------------------------
    EASIR_TRACE("init_headless: creating depth image");
    auto depthImage = vsg::Image::create();
    depthImage->imageType   = VK_IMAGE_TYPE_2D;
    depthImage->format      = depthFormat;
    depthImage->extent      = VkExtent3D{w, h, 1};
    depthImage->mipLevels   = 1;
    depthImage->arrayLayers = 1;
    depthImage->samples     = VK_SAMPLE_COUNT_1_BIT;
    depthImage->tiling      = VK_IMAGE_TILING_OPTIMAL;
    depthImage->usage       = VK_IMAGE_USAGE_DEPTH_STENCIL_ATTACHMENT_BIT;
    depthImage->compile(m_device);
    auto depthMem = vsg::DeviceMemory::create(m_device, depthImage->getMemoryRequirements(m_device->deviceID),
                                               VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    depthImage->bind(depthMem, 0);
    m_depth_image = depthImage;

    auto depthView = vsg::ImageView::create(depthImage, VK_IMAGE_ASPECT_DEPTH_BIT);
    depthView->compile(m_device);
    EASIR_TRACE("init_headless: depth image + view OK");

    // --- Create RenderPass using VSG helper types --------------------------
    EASIR_TRACE("init_headless: creating render pass");
    auto colorAtt = vsg::defaultColorAttachment(colorFormat);
    colorAtt.finalLayout = VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL;

    auto depthAtt = vsg::defaultDepthAttachment(depthFormat);

    vsg::SubpassDescription subpass;
    subpass.pipelineBindPoint = VK_PIPELINE_BIND_POINT_GRAPHICS;
    subpass.colorAttachments  = {{0, VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL}};
    subpass.depthStencilAttachments = {{1, VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL}};

    vsg::SubpassDependency dependency;
    dependency.srcSubpass    = VK_SUBPASS_EXTERNAL;
    dependency.dstSubpass    = 0;
    dependency.srcStageMask  = VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT;
    dependency.dstStageMask  = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT | VK_PIPELINE_STAGE_EARLY_FRAGMENT_TESTS_BIT;
    dependency.srcAccessMask = VK_ACCESS_MEMORY_READ_BIT;
    dependency.dstAccessMask = VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT | VK_ACCESS_DEPTH_STENCIL_ATTACHMENT_WRITE_BIT;

    vsg::RenderPass::Attachments rpAttachments{colorAtt, depthAtt};
    vsg::RenderPass::Subpasses rpSubpasses{subpass};
    vsg::RenderPass::Dependencies rpDependencies{dependency};
    auto renderPassObj = vsg::RenderPass::create(m_device, rpAttachments, rpSubpasses, rpDependencies);
    EASIR_TRACE("init_headless: render pass OK");

    // --- Create Framebuffer -----------------------------------------------
    EASIR_TRACE("init_headless: creating framebuffer");
    vsg::ImageViews fbAttachments{colorView, depthView};
    auto framebuffer = vsg::Framebuffer::create(renderPassObj, fbAttachments, w, h, 1);
    EASIR_TRACE("init_headless: framebuffer OK");

    // --- Camera -----------------------------------------------------------
    EASIR_TRACE("init_headless: creating camera");
    auto perspective = vsg::Perspective::create(
        static_cast<double>(m_config.camera.fov_deg),
        static_cast<double>(w) / static_cast<double>(h),
        static_cast<double>(m_config.camera.near_plane),
        static_cast<double>(m_config.camera.far_plane));

    auto lookAt = vsg::LookAt::create(
        vsg::dvec3{0.0, 0.0, 10.0},
        vsg::dvec3{0.0, 0.0,  0.0},
        vsg::dvec3{0.0, 1.0,  0.0});

    auto viewportState = vsg::ViewportState::create(0, 0, w, h);
    m_camera = vsg::Camera::create(perspective, lookAt, viewportState);
    EASIR_TRACE("init_headless: camera OK");

    // --- Build RenderGraph using framebuffer (no window) ------------------
    EASIR_TRACE("init_headless: creating render graph + command graph");
    auto renderGraph = vsg::RenderGraph::create();
    renderGraph->framebuffer = framebuffer;
    renderGraph->renderArea  = VkRect2D{{0, 0}, {w, h}};
    renderGraph->setClearValues({{0.2f, 0.2f, 0.4f, 1.0f}}, {0.0f, 0});
    renderGraph->addChild(vsg::View::create(m_camera, m_scene_root));

    // CommandGraph using device + queue family (no window).
    auto commandGraph = vsg::CommandGraph::create(m_device, m_queue_family);
    commandGraph->addChild(renderGraph);

    m_viewer = vsg::Viewer::create();
    m_viewer->assignRecordAndSubmitTaskAndPresentation({commandGraph});
    EASIR_TRACE("init_headless: viewer + command graph OK");

    // --- Pre-allocate readback resources (reused every frame) ----------------
    EASIR_TRACE("init_headless: allocating readback resources");
    VkDevice vkDev = *m_device;

    VkCommandPoolCreateInfo poolInfo{VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO};
    poolInfo.queueFamilyIndex = static_cast<uint32_t>(m_queue_family);
    poolInfo.flags = VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT;
    vkCreateCommandPool(vkDev, &poolInfo, nullptr, &m_readback_pool);

    VkCommandBufferAllocateInfo allocCmdInfo{VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO};
    allocCmdInfo.commandPool = m_readback_pool;
    allocCmdInfo.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY;
    allocCmdInfo.commandBufferCount = 1;
    vkAllocateCommandBuffers(vkDev, &allocCmdInfo, &m_readback_cmd);

    const VkDeviceSize bufSize = static_cast<VkDeviceSize>(w) * h * 4;

    VkBufferCreateInfo bufCreateInfo{VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO};
    bufCreateInfo.size  = bufSize;
    bufCreateInfo.usage = VK_BUFFER_USAGE_TRANSFER_DST_BIT;
    vkCreateBuffer(vkDev, &bufCreateInfo, nullptr, &m_staging_buf);

    VkMemoryRequirements memReqs;
    vkGetBufferMemoryRequirements(vkDev, m_staging_buf, &memReqs);

    auto physDev = m_device->getPhysicalDevice();
    VkPhysicalDeviceMemoryProperties memProps;
    vkGetPhysicalDeviceMemoryProperties(*physDev, &memProps);

    uint32_t memType = UINT32_MAX;
    for (uint32_t i = 0; i < memProps.memoryTypeCount; ++i) {
        if ((memReqs.memoryTypeBits & (1u << i)) &&
            (memProps.memoryTypes[i].propertyFlags &
             (VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT)) ==
             (VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT)) {
            memType = i;
            break;
        }
    }
    EASIR_TRACE("init_headless: staging memType=%u", memType);

    VkMemoryAllocateInfo memAlloc{VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO};
    memAlloc.allocationSize  = memReqs.size;
    memAlloc.memoryTypeIndex = memType;
    vkAllocateMemory(vkDev, &memAlloc, nullptr, &m_staging_mem);
    vkBindBufferMemory(vkDev, m_staging_buf, m_staging_mem, 0);

    // Persistently map — stays valid until vkFreeMemory.
    vkMapMemory(vkDev, m_staging_mem, 0, bufSize, 0, &m_staging_mapped);

    VkFenceCreateInfo fenceInfo{VK_STRUCTURE_TYPE_FENCE_CREATE_INFO};
    vkCreateFence(vkDev, &fenceInfo, nullptr, &m_readback_fence);
    EASIR_TRACE("init_headless: readback resources OK — init complete");
}

void EasirRenderer::init_windowed() {
    const int w = m_config.camera.width;
    const int h = m_config.camera.height;

    auto windowTraits = vsg::WindowTraits::create();
    windowTraits->windowTitle = "EASIR";
    windowTraits->width  = static_cast<uint32_t>(w);
    windowTraits->height = static_cast<uint32_t>(h);

    m_viewer = vsg::Viewer::create();

    auto window = vsg::Window::create(windowTraits);
    if (!window) {
        throw std::runtime_error("EASIR: Failed to create Vulkan window");
    }
    m_viewer->addWindow(window);

    // Camera setup.
    auto perspective = vsg::Perspective::create(
        static_cast<double>(m_config.camera.fov_deg),
        static_cast<double>(w) / static_cast<double>(h),
        static_cast<double>(m_config.camera.near_plane),
        static_cast<double>(m_config.camera.far_plane));

    auto lookAt = vsg::LookAt::create(
        vsg::dvec3{0.0, 0.0, 10.0},
        vsg::dvec3{0.0, 0.0,  0.0},
        vsg::dvec3{0.0, 1.0,  0.0});

    auto viewportState = vsg::ViewportState::create(0, 0,
        static_cast<uint32_t>(w), static_cast<uint32_t>(h));

    m_camera = vsg::Camera::create(perspective, lookAt, viewportState);

    auto renderGraph = vsg::RenderGraph::create(window);
    renderGraph->addChild(vsg::View::create(m_camera, m_scene_root));

    auto commandGraph = vsg::CommandGraph::create(window);
    commandGraph->addChild(renderGraph);
    m_viewer->assignRecordAndSubmitTaskAndPresentation({commandGraph});

    // Bind close-window event so the render loop can exit cleanly.
    m_viewer->addEventHandler(vsg::CloseHandler::create(m_viewer));
}

// ---------------------------------------------------------------------------
// Per-frame API
// ---------------------------------------------------------------------------

void EasirRenderer::set_state(const EasirState& state) {
    m_state = state;
}

bool EasirRenderer::render() {
    if (!m_viewer) {
        return false;
    }

    if (!m_viewer->advanceToNextFrame()) {
        return false; // viewer requested shutdown (windowed mode)
    }

    // Apply dynamic state to the scene.
    update_scene_from_state();

    // Execute render passes.
    RenderContext ctx{
        .viewer     = m_viewer,
        .scene_root = m_scene_root,
        .config     = &m_config,
        .state      = &m_state,
        .frame      = m_viewer->getFrameStamp()->frameCount,
    };
    m_pipeline->execute(ctx);

    m_viewer->handleEvents();
    m_viewer->update();
    m_viewer->recordAndSubmit();

    if (m_mode == RenderMode::Windowed) {
        m_viewer->present();
    } else {
        // Headless: no swapchain to present — read pixels from offscreen image.
        readback_pixels();
    }

    return true;
}

// ---------------------------------------------------------------------------
// Quaternion-to-LookAt helper
// ---------------------------------------------------------------------------

/// Convert a unit quaternion [x, y, z, w] to forward and up vectors.
/// Convention: forward = -Z in body frame, up = +Y in body frame.
static void quat_to_forward_up(const std::array<double, 4>& q,
                                vsg::dvec3& forward,
                                vsg::dvec3& up) {
    const double x = q[0], y = q[1], z = q[2], w = q[3];

    // Rotate body -Z axis to get forward direction.
    forward = vsg::dvec3{
        -(2.0 * (x * z + w * y)),
        -(2.0 * (y * z - w * x)),
        -(1.0 - 2.0 * (x * x + y * y)),
    };

    // Rotate body +Y axis to get up direction.
    up = vsg::dvec3{
        2.0 * (x * y - w * z),
        1.0 - 2.0 * (x * x + z * z),
        2.0 * (y * z + w * x),
    };
}

void EasirRenderer::update_scene_from_state() {
    // Update camera transform from state.
    if (m_camera) {
        auto* lookAt = dynamic_cast<vsg::LookAt*>(m_camera->viewMatrix.get());
        if (lookAt) {
            if (m_state.camera_follow_spacecraft && !m_state.scene_objects.empty()) {
                // Parent camera to the first scene object: offset 10 m along
                // the object's local +Z axis.
                const auto& obj = m_state.scene_objects.front();
                vsg::dvec3 obj_pos{obj.position[0], obj.position[1], obj.position[2]};

                vsg::dvec3 fwd, up_vec;
                quat_to_forward_up(obj.orientation, fwd, up_vec);

                lookAt->eye    = obj_pos - fwd * 10.0; // 10 m behind
                lookAt->center = obj_pos;
                lookAt->up     = up_vec;
            } else {
                // Use explicit camera position + orientation quaternion.
                vsg::dvec3 eye{
                    m_state.camera_position[0],
                    m_state.camera_position[1],
                    m_state.camera_position[2],
                };

                vsg::dvec3 fwd, up_vec;
                quat_to_forward_up(m_state.camera_orientation, fwd, up_vec);

                lookAt->eye    = eye;
                lookAt->center = eye + fwd;
                lookAt->up     = up_vec;
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Headless pixel readback (GPU → CPU)
// ---------------------------------------------------------------------------

void EasirRenderer::readback_pixels() {
    if (!m_device || !m_color_image) return;

    const uint32_t w = static_cast<uint32_t>(m_image_width);
    const uint32_t h = static_cast<uint32_t>(m_image_height);
    const VkDeviceSize bufSize = static_cast<VkDeviceSize>(w) * h * 4;
    VkDevice vkDev = *m_device;

    VkImage srcImage = m_color_image->vk(m_device->deviceID);
    auto queue = m_device->getQueue(static_cast<uint32_t>(m_queue_family));
    VkQueue vkQueue = *queue;

    // Reset the reusable command buffer and re-record.
    vkResetCommandBuffer(m_readback_cmd, 0);

    VkCommandBufferBeginInfo beginInfo{VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO};
    beginInfo.flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;
    vkBeginCommandBuffer(m_readback_cmd, &beginInfo);

    // Transition color image: COLOR_ATTACHMENT_OPTIMAL → TRANSFER_SRC
    VkImageMemoryBarrier toTransfer{VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER};
    toTransfer.oldLayout = VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL;
    toTransfer.newLayout = VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL;
    toTransfer.srcAccessMask = VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT;
    toTransfer.dstAccessMask = VK_ACCESS_TRANSFER_READ_BIT;
    toTransfer.image = srcImage;
    toTransfer.subresourceRange = {VK_IMAGE_ASPECT_COLOR_BIT, 0, 1, 0, 1};
    vkCmdPipelineBarrier(m_readback_cmd,
        VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT, VK_PIPELINE_STAGE_TRANSFER_BIT,
        0, 0, nullptr, 0, nullptr, 1, &toTransfer);

    VkBufferImageCopy region{};
    region.imageSubresource = {VK_IMAGE_ASPECT_COLOR_BIT, 0, 0, 1};
    region.imageExtent = {w, h, 1};
    vkCmdCopyImageToBuffer(m_readback_cmd, srcImage, VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL,
                           m_staging_buf, 1, &region);

    // Transition back to COLOR_ATTACHMENT_OPTIMAL for the next frame.
    VkImageMemoryBarrier toColor{VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER};
    toColor.oldLayout = VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL;
    toColor.newLayout = VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL;
    toColor.srcAccessMask = VK_ACCESS_TRANSFER_READ_BIT;
    toColor.dstAccessMask = VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT;
    toColor.image = srcImage;
    toColor.subresourceRange = {VK_IMAGE_ASPECT_COLOR_BIT, 0, 1, 0, 1};
    vkCmdPipelineBarrier(m_readback_cmd,
        VK_PIPELINE_STAGE_TRANSFER_BIT, VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT,
        0, 0, nullptr, 0, nullptr, 1, &toColor);

    vkEndCommandBuffer(m_readback_cmd);

    // Submit with fence for precise synchronisation.
    vkResetFences(vkDev, 1, &m_readback_fence);
    VkSubmitInfo submitInfo{VK_STRUCTURE_TYPE_SUBMIT_INFO};
    submitInfo.commandBufferCount = 1;
    submitInfo.pCommandBuffers = &m_readback_cmd;
    vkQueueSubmit(vkQueue, 1, &submitInfo, m_readback_fence);
    vkWaitForFences(vkDev, 1, &m_readback_fence, VK_TRUE, UINT64_MAX);

    // Pixels now reside in the persistently-mapped staging buffer.
    // get_image() returns m_staging_mapped directly — zero CPU copy.
    m_image_ready = true;
}

// ---------------------------------------------------------------------------
// Image output
// ---------------------------------------------------------------------------

bool EasirRenderer::get_image(const uint8_t** data,
                              int* width, int* height, int* channels) const {
    if (!m_image_ready || !m_staging_mapped) {
        return false;
    }
    *data     = static_cast<const uint8_t*>(m_staging_mapped);
    *width    = m_image_width;
    *height   = m_image_height;
    *channels = 4;
    return true;
}

} // namespace easir
