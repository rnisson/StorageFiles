include(CMakeFindDependencyMacro)

find_dependency(vsg 1.1.13 REQUIRED)
find_dependency(draco)
find_dependency(assimp)

include("${CMAKE_CURRENT_LIST_DIR}/vsgXchangeTargets.cmake")
