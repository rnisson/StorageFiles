function libDef = defineeasir()
%DEFINEEASIR  Define the MATLAB clib interface for the EASIR library.
%
%   This file is hand-written (not auto-generated) so that all 12 C API
%   functions have correct type annotations.  It reads the header parse
%   data from easirData.xml (produced by clibgen.generateLibraryDefinition).
%
%   Usage:
%     build(defineeasir)          % compile the interface
%     clib.easir.easir_create()   % use it

this_dir  = fileparts(mfilename('fullpath'));
repo_root = fullfile(this_dir, '..');

libDef = clibgen.LibraryDefinition(fullfile(this_dir, "easirData.xml"));
libDef.OutputFolder = this_dir;
libDef.Libraries    = fullfile(repo_root, 'build_vs', 'lib', 'Release', 'easir.lib');

%% -----------------------------------------------------------------------
%  easir_create
%  EasirHandle easir_create(const char* config_json)
%  -----------------------------------------------------------------------
easir_createDefinition = addFunction(libDef, ...
    "EasirHandle easir_create(char const * config_json)", ...
    "MATLABName", "clib.easir.easir_create", ...
    "Description", "Create a renderer instance.");
defineArgument(easir_createDefinition, "config_json", "string", "input", "nullTerminated");
defineOutput(easir_createDefinition, "RetVal", "uint64");
validate(easir_createDefinition);

%% -----------------------------------------------------------------------
%  easir_destroy
%  void easir_destroy(EasirHandle handle)
%  -----------------------------------------------------------------------
easir_destroyDefinition = addFunction(libDef, ...
    "void easir_destroy(EasirHandle handle)", ...
    "MATLABName", "clib.easir.easir_destroy", ...
    "Description", "Destroy a renderer instance.");
defineArgument(easir_destroyDefinition, "handle", "uint64");
validate(easir_destroyDefinition);

%% -----------------------------------------------------------------------
%  easir_set_state
%  int easir_set_state(EasirHandle handle, const char* state_json)
%  -----------------------------------------------------------------------
easir_set_stateDefinition = addFunction(libDef, ...
    "int easir_set_state(EasirHandle handle,char const * state_json)", ...
    "MATLABName", "clib.easir.easir_set_state", ...
    "Description", "Update the dynamic state for the next render call.");
defineArgument(easir_set_stateDefinition, "handle", "uint64");
defineArgument(easir_set_stateDefinition, "state_json", "string", "input", "nullTerminated");
defineOutput(easir_set_stateDefinition, "RetVal", "int32");
validate(easir_set_stateDefinition);

%% -----------------------------------------------------------------------
%  easir_render
%  int easir_render(EasirHandle handle)
%  -----------------------------------------------------------------------
easir_renderDefinition = addFunction(libDef, ...
    "int easir_render(EasirHandle handle)", ...
    "MATLABName", "clib.easir.easir_render", ...
    "Description", "Execute one render frame.");
defineArgument(easir_renderDefinition, "handle", "uint64");
defineOutput(easir_renderDefinition, "RetVal", "int32");
validate(easir_renderDefinition);

%% -----------------------------------------------------------------------
%  easir_get_image_info
%  int easir_get_image_info(EasirHandle handle, int* width, int* height, int* channels)
%  -----------------------------------------------------------------------
easir_get_image_infoDefinition = addFunction(libDef, ...
    "int easir_get_image_info(EasirHandle handle,int * width,int * height,int * channels)", ...
    "MATLABName", "clib.easir.easir_get_image_info", ...
    "Description", "Query the dimensions of the last rendered image.");
defineArgument(easir_get_image_infoDefinition, "handle", "uint64");
defineArgument(easir_get_image_infoDefinition, "width",    "int32", "output", 1);
defineArgument(easir_get_image_infoDefinition, "height",   "int32", "output", 1);
defineArgument(easir_get_image_infoDefinition, "channels", "int32", "output", 1);
defineOutput(easir_get_image_infoDefinition, "RetVal", "int32");
validate(easir_get_image_infoDefinition);

%% -----------------------------------------------------------------------
%  easir_get_image
%  int easir_get_image(EasirHandle handle, unsigned char* buffer, int buf_size)
%  -----------------------------------------------------------------------
easir_get_imageDefinition = addFunction(libDef, ...
    "int easir_get_image(EasirHandle handle,unsigned char * buffer,int buf_size)", ...
    "MATLABName", "clib.easir.easir_get_image", ...
    "Description", "Copy rendered pixels (RGBA8) into a caller-owned buffer.");
defineArgument(easir_get_imageDefinition, "handle", "uint64");
defineArgument(easir_get_imageDefinition, "buffer", "uint8", "output", "buf_size");
defineArgument(easir_get_imageDefinition, "buf_size", "int32");
defineOutput(easir_get_imageDefinition, "RetVal", "int32");
validate(easir_get_imageDefinition);

%% -----------------------------------------------------------------------
%  easir_get_config
%  const char* easir_get_config(EasirHandle handle)
%  -----------------------------------------------------------------------
easir_get_configDefinition = addFunction(libDef, ...
    "char const * easir_get_config(EasirHandle handle)", ...
    "MATLABName", "clib.easir.easir_get_config", ...
    "Description", "Return the current config as a JSON string.");
defineArgument(easir_get_configDefinition, "handle", "uint64");
defineOutput(easir_get_configDefinition, "RetVal", "string", "nullTerminated");
validate(easir_get_configDefinition);

%% -----------------------------------------------------------------------
%  easir_get_state
%  const char* easir_get_state(EasirHandle handle)
%  -----------------------------------------------------------------------
easir_get_stateDefinition = addFunction(libDef, ...
    "char const * easir_get_state(EasirHandle handle)", ...
    "MATLABName", "clib.easir.easir_get_state", ...
    "Description", "Return the current state as a JSON string.");
defineArgument(easir_get_stateDefinition, "handle", "uint64");
defineOutput(easir_get_stateDefinition, "RetVal", "string", "nullTerminated");
validate(easir_get_stateDefinition);

%% -----------------------------------------------------------------------
%  easir_get_default_config
%  const char* easir_get_default_config(void)
%  -----------------------------------------------------------------------
easir_get_default_configDefinition = addFunction(libDef, ...
    "char const * easir_get_default_config()", ...
    "MATLABName", "clib.easir.easir_get_default_config", ...
    "Description", "Return the default EasirConfig as a JSON string.");
defineOutput(easir_get_default_configDefinition, "RetVal", "string", "nullTerminated");
validate(easir_get_default_configDefinition);

%% -----------------------------------------------------------------------
%  easir_get_default_state
%  const char* easir_get_default_state(void)
%  -----------------------------------------------------------------------
easir_get_default_stateDefinition = addFunction(libDef, ...
    "char const * easir_get_default_state()", ...
    "MATLABName", "clib.easir.easir_get_default_state", ...
    "Description", "Return the default EasirState as a JSON string.");
defineOutput(easir_get_default_stateDefinition, "RetVal", "string", "nullTerminated");
validate(easir_get_default_stateDefinition);

%% -----------------------------------------------------------------------
%  easir_free_string
%  void easir_free_string(const char* str)
%  -----------------------------------------------------------------------
easir_free_stringDefinition = addFunction(libDef, ...
    "void easir_free_string(char const * str)", ...
    "MATLABName", "clib.easir.easir_free_string", ...
    "Description", "No-op, retained for backward compatibility.");
defineArgument(easir_free_stringDefinition, "str", "string", "input", "nullTerminated");
validate(easir_free_stringDefinition);

%% -----------------------------------------------------------------------
%  easir_get_last_error
%  const char* easir_get_last_error(void)
%  -----------------------------------------------------------------------
easir_get_last_errorDefinition = addFunction(libDef, ...
    "char const * easir_get_last_error()", ...
    "MATLABName", "clib.easir.easir_get_last_error", ...
    "Description", "Return a description of the last error.");
defineOutput(easir_get_last_errorDefinition, "RetVal", "string", "nullTerminated");
validate(easir_get_last_errorDefinition);

end
