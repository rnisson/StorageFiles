%% easir_define.m
% Generate and build the MATLAB clib() interface for the EASIR DLL.
%
% Run this script ONCE (or whenever the C API changes) to create the
% interface package that lets you call clib.easir.easir_create(...) etc.
%
% Prerequisites:
%   - MATLAB R2022b or later
%   - Vulkan SDK installed
%   - easir.dll built:  cmake --build build_vs --config Release --target easir
%
% After running this script, use easir_example.m to exercise the renderer.

%% --- Paths ---
repo_root   = fullfile(fileparts(mfilename('fullpath')), '..');
dll_path    = fullfile(repo_root, 'build_vs', 'bin', 'Release', 'easir.dll');
header_path = fullfile(repo_root, 'include', 'easir', 'easir_api.h');
import_lib  = fullfile(repo_root, 'build_vs', 'lib', 'Release', 'easir.lib');

if ~isfile(dll_path)
    error('easir:notFound', ...
        ['DLL not found at:\n  %s\n' ...
         'Build it first:\n' ...
         '  cmake --build build_vs --config Release --target easir'], ...
        dll_path);
end

%% --- Generate easirData.xml (header parse data) ---
% clibgen parses the C header and writes type info to easirData.xml.
% It also generates defineeasir.mlx with placeholder types — we delete
% that and use our hand-written defineeasir.m instead, which has all
% type annotations pre-filled.

% Clean previous artifacts.
if isfile('defineeasir.mlx'), delete('defineeasir.mlx'); end
if isfile('easirData.xml'),   delete('easirData.xml');   end

% Remove any previously built interface so it can be regenerated.
if exist('easir', 'dir')
    rmdir('easir', 's');
end

clibgen.generateLibraryDefinition(header_path, ...
    'Libraries',   import_lib, ...
    'PackageName', 'easir', ...
    'Verbose',     true);

% Delete the auto-generated .mlx — our defineeasir.m has correct types.
if isfile('defineeasir.mlx')
    delete('defineeasir.mlx');
    fprintf('Replaced auto-generated defineeasir.mlx with defineeasir.m\n');
end

%% --- Build the interface ---
fprintf('\n=== Building clib interface ===\n');
build(defineeasir);

fprintf('\n=== Interface ready ===\n');
fprintf('Use:  clib.easir.easir_create(...)\n');
fprintf('See easir_example.m for a full demo.\n');
