#pragma once

/**
 * @file editor_handler.h
 * @brief EditorHandler — input handler and ImGui panel for editor mode.
 *
 * Handles:
 *   - Left-click:  select node via ray intersection, highlight with wireframe
 *   - Scroll:      zoom toward cursor (zoom + subtle recentering toward mouse)
 *   - ImGui panel: semantic group management (create/delete/assign/rename/recolor)
 *   - Hover:       highlight all nodes in a group when hovering in the panel
 */

#include "trace.h"
#include "semantic_group_manager.h"

#include <vsg/all.h>
#include <vsg/utils/LineSegmentIntersector.h>
#include <vsg/utils/GraphicsPipelineConfigurator.h>

#include <vsgImGui/RenderImGui.h>
#include <vsgImGui/imgui.h>

#include <cstdio>
#include <string>
#include <vector>

namespace easir {

class EditorHandler : public vsg::Inherit<vsg::Visitor, EditorHandler> {
public:
    EditorHandler(vsg::ref_ptr<vsg::Camera> camera,
                  vsg::ref_ptr<vsg::Group> sceneRoot,
                  vsg::ref_ptr<vsg::Trackball> trackball,
                  vsg::ref_ptr<vsg::Viewer> viewer)
        : m_camera(camera)
        , m_sceneRoot(sceneRoot)
        , m_trackball(trackball)
        , m_viewer(viewer)
    {
    }

    /// Set the group manager (must be called before draw_gui).
    void set_group_manager(SemanticGroupManager* mgr) { m_groupMgr = mgr; }

    /// Set material references from the semantic visitor (for live recoloring).
    using MaterialMap = std::unordered_map<std::string, vsg::ref_ptr<vsg::PhongMaterialValue>>;
    void set_material_map(const MaterialMap& map) { m_materialMap = map; }

    /// Set the edge preview Switch node for toggling between scene and edge view.
    void set_edge_preview_switch(vsg::ref_ptr<vsg::Switch> sw) { m_edgePreviewSwitch = sw; }

    /// Set the sun light reference (for reset light direction feature).
    void set_sun_light(vsg::ref_ptr<vsg::DirectionalLight> light) { m_sunLight = light; }

    /// Build a map of short_name -> nodePath for all named nodes in the scene.
    /// Call after the scene graph is loaded and before rendering starts.
    void discover_nodes() {
        if (!m_sceneRoot) return;
        m_nodePathMap.clear();

        // Use a proper VSG visitor to traverse the scene graph — this ensures
        // correct dispatch through all node types (Group, MatrixTransform,
        // StateGroup, Switch, etc.) unlike dynamic_cast which can miss types.
        struct NodeDiscoveryVisitor : public vsg::Visitor {
            std::unordered_map<std::string, NodeInfo>& nodeMap;
            std::vector<vsg::dmat4> matrixStack;

            NodeDiscoveryVisitor(std::unordered_map<std::string, NodeInfo>& m)
                : nodeMap(m) { matrixStack.push_back(vsg::dmat4(1.0)); }

            void apply(vsg::Node& node) override { node.traverse(*this); }

            void apply(vsg::Group& group) override {
                check_and_store(group);
                group.traverse(*this);
            }

            void apply(vsg::MatrixTransform& mt) override {
                matrixStack.push_back(matrixStack.back() * mt.matrix);
                check_and_store(mt);
                mt.traverse(*this);
                matrixStack.pop_back();
            }

            void check_and_store(vsg::Node& node) {
                std::string name;
                if (!node.getValue("name", name) || name.empty()) return;

                std::string shortName = SemanticGroupManager::extract_short_name(name);

                // Filter out container/root nodes (no brackets = not a leaf layer).
                if (name.find('[') == std::string::npos) return;

                if (nodeMap.find(shortName) != nodeMap.end()) return;

                NodeInfo info;
                info.fullName = name;
                info.worldMatrix = matrixStack.back();

                // Collect the raw geometry nodes (VertexIndexDraw etc.) by digging
                // through StateGroups. This ensures the wireframe highlight's pipeline
                // isn't overridden by the child StateGroup's own pipeline.
                auto* grp = dynamic_cast<vsg::Group*>(&node);
                if (grp) {
                    collect_geometry(grp, info.geomChildren);
                }
                nodeMap[shortName] = std::move(info);
            }

            // Recursively find geometry leaf nodes (VertexIndexDraw, BindVertexBuffers etc.)
            // by digging through StateGroups and other containers.
            static void collect_geometry(vsg::Group* group,
                                         std::vector<vsg::ref_ptr<vsg::Node>>& out) {
                for (auto& child : group->children) {
                    // If it's a StateGroup, dig into its children for geometry.
                    auto* sg = dynamic_cast<vsg::StateGroup*>(child.get());
                    if (sg) {
                        for (auto& sgChild : sg->children) {
                            out.push_back(sgChild);
                        }
                        continue;
                    }
                    // If it's another Group, recurse.
                    auto* grp = dynamic_cast<vsg::Group*>(child.get());
                    if (grp) {
                        collect_geometry(grp, out);
                        continue;
                    }
                    // Otherwise it's a leaf geometry node.
                    out.push_back(child);
                }
            }
        };

        NodeDiscoveryVisitor visitor(m_nodePathMap);
        m_sceneRoot->accept(visitor);

        std::printf("[EASIR] Discovered %zu named nodes for editor:\n", m_nodePathMap.size());
        for (auto& [name, info] : m_nodePathMap) {
            std::printf("[EASIR]   '%s' — %zu children\n", name.c_str(), info.geomChildren.size());
        }
    }

    // ---------------------------------------------------------------
    //  Track mouse position (for zoom-toward-cursor)
    // ---------------------------------------------------------------

    void apply(vsg::MoveEvent& move) override {
        m_lastMouseX = move.x;
        m_lastMouseY = move.y;
    }

    // ---------------------------------------------------------------
    //  Mouse button events — detect click vs drag
    // ---------------------------------------------------------------

    void apply(vsg::ButtonPressEvent& press) override {
        if (imgui_wants_mouse()) return;
        if (press.button == 1) {
            m_leftPressX = press.x;
            m_leftPressY = press.y;
            m_leftPressed = true;
        }
    }

    void apply(vsg::ButtonReleaseEvent& release) override {
        if (imgui_wants_mouse()) { m_leftPressed = false; return; }
        if (m_edgePreviewActive) { m_leftPressed = false; return; }  // No selection in edge preview
        if (release.button == 1 && m_leftPressed) {
            m_leftPressed = false;

            int dx = release.x - m_leftPressX;
            int dy = release.y - m_leftPressY;
            if (dx * dx + dy * dy < 25) {
                on_click(release.x, release.y);
            }
        }
    }

    // ---------------------------------------------------------------
    //  Scroll — zoom toward cursor (recentering only when zooming in)
    // ---------------------------------------------------------------

    void apply(vsg::ScrollWheelEvent& scroll) override {
        if (imgui_wants_mouse()) return;
        if (!m_camera || scroll.handled) return;
        scroll.handled = true;

        auto* lookAt = dynamic_cast<vsg::LookAt*>(m_camera->viewMatrix.get());
        if (!lookAt) return;

        bool zoomingIn = scroll.delta.y > 0;
        double zoomFactor = zoomingIn ? 0.9 : 1.1;

        vsg::dvec3 eye_to_center = lookAt->center - lookAt->eye;
        double distance = vsg::length(eye_to_center);
        if (distance < 1e-6) return;

        double newDistance = distance * zoomFactor;
        vsg::dvec3 dir = eye_to_center / distance;
        lookAt->eye = lookAt->center - dir * newDistance;

        if (zoomingIn) {
            auto intersector = vsg::LineSegmentIntersector::create(
                *m_camera, m_lastMouseX, m_lastMouseY);
            m_sceneRoot->accept(*intersector);

            if (!intersector->intersections.empty()) {
                auto& isects = intersector->intersections;
                auto closest = std::min_element(isects.begin(), isects.end(),
                    [](const auto& a, const auto& b) { return a->ratio < b->ratio; });
                vsg::dvec3 targetPoint = (*closest)->worldIntersection;

                double recenterRatio = 0.1;
                vsg::dvec3 shift = (targetPoint - lookAt->center) * recenterRatio;
                lookAt->center = lookAt->center + shift;
                lookAt->eye = lookAt->eye + shift;
            }
        }
    }

    std::string selected_node_name() const { return m_selectedNodeName; }
    bool has_selection() const { return m_hasSelection; }

    /// Returns true if ImGui wants the mouse.
    static bool imgui_wants_mouse() {
        return ImGui::GetCurrentContext() && ImGui::GetIO().WantCaptureMouse;
    }

    // ---------------------------------------------------------------
    //  ImGui panel — full semantic group editor
    // ---------------------------------------------------------------

    bool draw_gui() {
        ImGui::SetNextWindowPos(ImVec2(10, 10), ImGuiCond_FirstUseEver);
        ImGui::SetNextWindowSize(ImVec2(340, 500), ImGuiCond_FirstUseEver);

        ImGui::Begin("EASIR Editor");

        // View mode toggles (mutually exclusive).
        if (m_edgePreviewSwitch) {
            if (ImGui::Checkbox("Edge Preview", &m_edgePreviewActive)) {
                if (m_edgePreviewActive) {
                    if (m_semanticShadingActive) {
                        m_semanticShadingActive = false;
                        apply_semantic_shading(false);  // Revert materials to flat
                    }
                    m_edgePreviewSwitch->setSingleChildOn(1);
                } else {
                    m_edgePreviewSwitch->setSingleChildOn(0);
                }
            }
        }
        if (ImGui::Checkbox("Semantic Shading", &m_semanticShadingActive)) {
            if (m_semanticShadingActive) {
                m_edgePreviewActive = false;  // Mutually exclusive
                if (m_edgePreviewSwitch) m_edgePreviewSwitch->setSingleChildOn(0);
            }
            apply_semantic_shading(m_semanticShadingActive);
        }
        if (m_semanticShadingActive && m_sunLight && m_camera) {
            ImGui::SameLine();
            if (ImGui::SmallButton("[L]")) {
                // Reset light direction to camera forward (into screen).
                auto* lookAt = dynamic_cast<vsg::LookAt*>(m_camera->viewMatrix.get());
                if (lookAt) {
                    auto fwd = vsg::normalize(lookAt->center - lookAt->eye);
                    m_sunLight->direction = vsg::vec3{
                        static_cast<float>(fwd.x),
                        static_cast<float>(fwd.y),
                        static_cast<float>(fwd.z)};
                }
            }
            if (ImGui::IsItemHovered()) ImGui::SetTooltip("Reset light to camera direction");
        }
        ImGui::Separator();

        // Disable editing controls while edge preview is active.
        if (m_edgePreviewActive) ImGui::BeginDisabled();

        draw_save_load_buttons();
        ImGui::Separator();
        draw_selection_info();
        ImGui::Separator();
        draw_group_list();
        ImGui::Separator();
        draw_controls_help();

        if (m_edgePreviewActive) ImGui::EndDisabled();

        ImGui::End();

        // Handle hover highlight — check if it changed this frame.
        update_hover_highlight();

        // Live recolor when assignments change.
        if (m_needsSceneColorUpdate) {
            recolor_scene();
            m_needsSceneColorUpdate = false;
        }

        return true;
    }

private:
    vsg::ref_ptr<vsg::Camera> m_camera;
    vsg::ref_ptr<vsg::Group> m_sceneRoot;
    vsg::ref_ptr<vsg::Trackball> m_trackball;
    vsg::ref_ptr<vsg::Viewer> m_viewer;
    SemanticGroupManager* m_groupMgr = nullptr;
    vsg::ref_ptr<vsg::Switch> m_edgePreviewSwitch;
    bool m_edgePreviewActive = false;
    bool m_semanticShadingActive = false;
    bool m_hasUnsavedChanges = false;
    vsg::ref_ptr<vsg::DirectionalLight> m_sunLight;

    int32_t m_lastMouseX = 0;
    int32_t m_lastMouseY = 0;

    int m_leftPressX = 0;
    int m_leftPressY = 0;
    bool m_leftPressed = false;

    std::string m_selectedNodeName;   // full vsgXchange name
    std::string m_selectedShortName;  // extracted short name
    vsg::dvec3 m_selectionPoint{0.0, 0.0, 0.0};
    bool m_hasSelection = false;
    vsg::ref_ptr<vsg::Group> m_highlightGroup;

    // Hover state
    int m_hoveredGroupId = -1;
    int m_prevHoveredGroupId = -1;
    std::string m_hoveredNodeName;       // when hovering a specific node in the list
    std::string m_prevHoveredNodeName;
    vsg::ref_ptr<vsg::Group> m_hoverHighlightGroup;

    // Per-group edit state (for inline rename / color picker)
    int m_editingGroupId = -1;
    char m_editNameBuf[128] = {};

    // Map of short_name -> stored node info (for hover highlight + panel selection)
    struct NodeInfo {
        std::vector<vsg::ref_ptr<vsg::Node>> geomChildren;
        vsg::dmat4 worldMatrix;
        std::string fullName;  // full vsgXchange name
    };
    std::unordered_map<std::string, NodeInfo> m_nodePathMap;

    // Material map from semantic visitor (for live recoloring).
    MaterialMap m_materialMap;

    // ---------------------------------------------------------------
    //  Select node by short name (from GUI panel click)
    // ---------------------------------------------------------------

    void select_node_by_name(const std::string& shortName) {
        auto it = m_nodePathMap.find(shortName);
        if (it == m_nodePathMap.end()) return;

        remove_highlight();

        m_selectedShortName = shortName;
        m_selectedNodeName = it->second.fullName;
        m_hasSelection = true;
        // Selection point = center of the node's bounding box (approximate).
        // Just use the transform origin for now.
        m_selectionPoint = vsg::dvec3(
            it->second.worldMatrix[3][0],
            it->second.worldMatrix[3][1],
            it->second.worldMatrix[3][2]);

        std::printf("[EASIR] Selected (from panel): '%s' — %zu children, matrix[3]=(%f,%f,%f)\n",
                    shortName.c_str(), it->second.geomChildren.size(),
                    it->second.worldMatrix[3][0], it->second.worldMatrix[3][1], it->second.worldMatrix[3][2]);

        // Build highlight using stored node info.
        if (it->second.geomChildren.empty()) {
            std::printf("[EASIR] WARNING: No geomChildren for '%s', cannot highlight\n", shortName.c_str());
            return;
        }

        m_highlightGroup = vsg::Group::create();
        auto transform = vsg::MatrixTransform::create();
        transform->matrix = it->second.worldMatrix;

        auto shaderSet = vsg::createFlatShadedShaderSet();
        auto config = vsg::GraphicsPipelineConfigurator::create(shaderSet);

        auto rasterState = vsg::RasterizationState::create();
        rasterState->polygonMode = VK_POLYGON_MODE_LINE;
        rasterState->lineWidth = 2.0f;
        rasterState->cullMode = VK_CULL_MODE_NONE;

        auto colorBlend = vsg::ColorBlendState::create();
        VkPipelineColorBlendAttachmentState blendAttachment{};
        blendAttachment.blendEnable = VK_TRUE;
        blendAttachment.srcColorBlendFactor = VK_BLEND_FACTOR_SRC_ALPHA;
        blendAttachment.dstColorBlendFactor = VK_BLEND_FACTOR_ONE_MINUS_SRC_ALPHA;
        blendAttachment.colorBlendOp = VK_BLEND_OP_ADD;
        blendAttachment.srcAlphaBlendFactor = VK_BLEND_FACTOR_ONE;
        blendAttachment.dstAlphaBlendFactor = VK_BLEND_FACTOR_ZERO;
        blendAttachment.alphaBlendOp = VK_BLEND_OP_ADD;
        blendAttachment.colorWriteMask = VK_COLOR_COMPONENT_R_BIT | VK_COLOR_COMPONENT_G_BIT |
                                         VK_COLOR_COMPONENT_B_BIT | VK_COLOR_COMPONENT_A_BIT;
        colorBlend->attachments = {blendAttachment};

        auto depthState = vsg::DepthStencilState::create();
        depthState->depthTestEnable = VK_FALSE;
        depthState->depthWriteEnable = VK_FALSE;

        for (auto& ps : config->pipelineStates) {
            if (ps.cast<vsg::RasterizationState>()) ps = rasterState;
            else if (ps.cast<vsg::ColorBlendState>()) ps = colorBlend;
            else if (ps.cast<vsg::DepthStencilState>()) ps = depthState;
        }

        auto mat = vsg::PhongMaterialValue::create();
        mat->value().ambient  = vsg::vec4{1.0f, 0.0f, 0.0f, 0.3f};
        mat->value().diffuse  = vsg::vec4{1.0f, 0.0f, 0.0f, 0.3f};
        mat->value().specular = vsg::vec4{0.0f, 0.0f, 0.0f, 0.0f};
        mat->value().emissive = vsg::vec4{1.0f, 0.0f, 0.0f, 0.3f};
        mat->value().shininess = 0.0f;
        config->assignDescriptor("material", mat);
        config->init();

        auto stateGroup = vsg::StateGroup::create();
        config->copyTo(stateGroup->stateCommands);
        for (auto& child : it->second.geomChildren) stateGroup->addChild(child);
        transform->addChild(stateGroup);
        m_highlightGroup->addChild(transform);

        m_sceneRoot->addChild(m_highlightGroup);

        if (m_viewer && m_viewer->compileManager) {
            auto result = m_viewer->compileManager->compile(m_highlightGroup);
            // Always update tasks — even if requiresViewerUpdate is false, the new
            // StateGroup/pipeline was compiled and needs to be part of the render.
            vsg::updateTasks(m_viewer->recordAndSubmitTasks, m_viewer->compileManager, result);
        }
    }

    // ---------------------------------------------------------------
    //  Live recoloring — update materials from group manager
    // ---------------------------------------------------------------

    void recolor_scene() {
        if (!m_groupMgr) return;
        for (auto& [shortName, mat] : m_materialMap) {
            if (!mat) continue;
            vsg::vec4 color = m_groupMgr->color_for_node(shortName);
            apply_material_color(mat, color, m_semanticShadingActive);
        }
    }

    /// Apply a semantic color to a material, respecting the shading toggle.
    static void apply_material_color(vsg::ref_ptr<vsg::PhongMaterialValue>& mat,
                                      const vsg::vec4& color, bool shading) {
        if (shading) {
            // N·L shading: emissive provides base brightness, diffuse adds lighting.
            mat->value().ambient  = vsg::vec4{0.0f, 0.0f, 0.0f, 1.0f};
            mat->value().diffuse  = vsg::vec4{color.x * 0.7f, color.y * 0.7f, color.z * 0.7f, 1.0f};
            mat->value().emissive = vsg::vec4{color.x * 0.3f, color.y * 0.3f, color.z * 0.3f, 1.0f};
        } else {
            // Flat: emissive only, output = color exactly.
            mat->value().ambient  = vsg::vec4{0.0f, 0.0f, 0.0f, 1.0f};
            mat->value().diffuse  = vsg::vec4{0.0f, 0.0f, 0.0f, 1.0f};
            mat->value().emissive = color;
        }
        mat->value().specular = vsg::vec4{0.0f, 0.0f, 0.0f, 1.0f};
        mat->value().shininess = 0.0f;
        mat->dirty();
    }

    /// Toggle semantic shading on/off for all materials.
    void apply_semantic_shading(bool enabled) {
        if (!m_groupMgr) return;
        for (auto& [shortName, mat] : m_materialMap) {
            if (!mat) continue;
            vsg::vec4 color = m_groupMgr->color_for_node(shortName);
            apply_material_color(mat, color, enabled);
        }
    }

    // ---------------------------------------------------------------
    //  GUI: Save / Load buttons
    // ---------------------------------------------------------------

    void draw_save_load_buttons() {
        if (!m_groupMgr) return;

        // Save button — with unsaved indicator.
        std::string saveLabel = m_hasUnsavedChanges ? "Save *" : "Save";
        if (ImGui::Button(saveLabel.c_str())) {
            if (m_groupMgr->save_file_exists()) {
                ImGui::OpenPopup("Confirm Save");
            } else {
                m_groupMgr->save();
                m_hasUnsavedChanges = false;
            }
        }
        ImGui::SameLine();
        if (ImGui::Button("Load")) {
            if (m_groupMgr->load()) {
                m_needsSceneColorUpdate = true;
                m_hasUnsavedChanges = false;
            }
        }

        // Confirmation modal.
        if (ImGui::BeginPopupModal("Confirm Save", nullptr, ImGuiWindowFlags_AlwaysAutoResize)) {
            auto path = m_groupMgr->save_path();
            ImGui::Text("Overwrite %s?", path.filename().string().c_str());
            ImGui::Separator();
            if (ImGui::Button("Yes", ImVec2(80, 0))) {
                m_groupMgr->save();
                m_hasUnsavedChanges = false;
                ImGui::CloseCurrentPopup();
            }
            ImGui::SameLine();
            if (ImGui::Button("No", ImVec2(80, 0))) {
                ImGui::CloseCurrentPopup();
            }
            ImGui::EndPopup();
        }
    }

    // ---------------------------------------------------------------
    //  GUI: Selection info
    // ---------------------------------------------------------------

    void draw_selection_info() {
        if (m_hasSelection) {
            ImGui::TextColored(ImVec4(1.0f, 0.4f, 0.4f, 1.0f), "Selected:");
            ImGui::TextWrapped("%s", m_selectedShortName.c_str());

            if (m_groupMgr) {
                int gid = m_groupMgr->find_node_group(m_selectedShortName);
                auto* grp = m_groupMgr->group_by_id(gid);
                if (grp) {
                    ImGui::Text("Group: %s", grp->name.c_str());
                }
            }

            if (ImGui::Button("Deselect")) {
                remove_highlight();
                m_selectedNodeName.clear();
                m_selectedShortName.clear();
                m_hasSelection = false;
            }
        } else {
            ImGui::TextColored(ImVec4(0.5f, 0.5f, 0.5f, 1.0f), "No selection");
            ImGui::Text("Left-click a node in the viewport.");
        }
    }

    // ---------------------------------------------------------------
    //  GUI: Group list
    // ---------------------------------------------------------------

    void draw_group_list() {
        if (!m_groupMgr) {
            ImGui::Text("No group manager.");
            return;
        }

        // Add Group button.
        if (ImGui::Button("+ Add Group")) {
            // Generate a unique default name.
            int idx = static_cast<int>(m_groupMgr->groups().size());
            std::string name = "Group " + std::to_string(idx);

            // Random-ish color based on group count.
            float hue = std::fmod(idx * 0.618033988749895f, 1.0f);
            float r, g, b;
            ImGui::ColorConvertHSVtoRGB(hue, 0.7f, 0.9f, r, g, b);
            m_groupMgr->add_group(name, {r, g, b});
        }

        ImGui::Spacing();

        m_hoveredGroupId = -1;  // Reset; will be set if mouse hovers a group row.
        m_hoveredNodeName.clear();  // Reset; set if mouse hovers a specific node.

        for (auto& group : m_groupMgr->groups()) {
            ImGui::PushID(group.id);

            // Color swatch.
            ImVec4 col;
            if (group.permanent) {
                col = ImVec4(0.5f, 0.5f, 0.5f, 1.0f);
            } else {
                col = ImVec4(group.color[0], group.color[1], group.color[2], 1.0f);
            }
            ImGui::ColorButton("##color", col, ImGuiColorEditFlags_NoTooltip, ImVec2(14, 14));
            bool rowHovered = ImGui::IsItemHovered();
            ImGui::SameLine();

            // Group name + node count (as collapsible tree node).
            char label[256];
            std::snprintf(label, sizeof(label), "%s (%zu nodes)",
                          group.name.c_str(), group.nodes.size());

            bool open = ImGui::TreeNode("##tree", "%s", label);
            rowHovered = rowHovered || ImGui::IsItemHovered();

            // Buttons on the same line (only for non-permanent groups).
            if (!group.permanent) {
                ImGui::SameLine();

                // Assign button (only enabled when something is selected).
                bool canAssign = m_hasSelection && !m_selectedShortName.empty();
                if (!canAssign) ImGui::BeginDisabled();
                if (ImGui::SmallButton("Assign")) {
                    m_groupMgr->assign_node(m_selectedShortName, group.id);
                    m_needsSceneColorUpdate = true; m_hasUnsavedChanges = true;
                }
                rowHovered = rowHovered || ImGui::IsItemHovered();
                if (!canAssign) ImGui::EndDisabled();

                ImGui::SameLine();

                // Settings button (color picker + rename).
                if (ImGui::SmallButton("Edit")) {
                    if (m_editingGroupId == group.id) {
                        m_editingGroupId = -1;  // Toggle off.
                    } else {
                        m_editingGroupId = group.id;
                        std::strncpy(m_editNameBuf, group.name.c_str(), sizeof(m_editNameBuf) - 1);
                        m_editNameBuf[sizeof(m_editNameBuf) - 1] = '\0';
                    }
                }
                rowHovered = rowHovered || ImGui::IsItemHovered();

                ImGui::SameLine();

                // Delete button.
                if (ImGui::SmallButton("X")) {
                    if (m_editingGroupId == group.id) m_editingGroupId = -1;
                    m_groupMgr->delete_group(group.id);
                    m_needsSceneColorUpdate = true; m_hasUnsavedChanges = true;
                    ImGui::PopID();
                    if (open) ImGui::TreePop();
                    break;  // Iterator invalidated; redraw next frame.
                }
            }

            // Set hovered group if any widget on this row is hovered.
            if (rowHovered) {
                m_hoveredGroupId = group.id;
            }

            // Inline edit panel (rename + color picker).
            if (m_editingGroupId == group.id) {
                ImGui::Indent();
                ImGui::InputText("Name", m_editNameBuf, sizeof(m_editNameBuf));
                if (ImGui::IsItemDeactivatedAfterEdit()) {
                    group.name = m_editNameBuf;
                }
                if (ImGui::ColorEdit3("Color", group.color.data())) {
                    m_needsSceneColorUpdate = true; m_hasUnsavedChanges = true;
                }
                ImGui::Unindent();
            }

            // Expanded node list — clickable to select in viewport.
            if (open) {
                for (const auto& nodeName : group.nodes) {
                    ImGui::PushID(nodeName.c_str());
                    if (ImGui::Selectable(nodeName.c_str(),
                                          m_hasSelection && m_selectedShortName == nodeName)) {
                        // Select this node in the viewport.
                        select_node_by_name(nodeName);
                    }
                    // Hover over a specific node name highlights just that node.
                    if (ImGui::IsItemHovered()) {
                        m_hoveredNodeName = nodeName;
                    }
                    ImGui::PopID();
                }
                ImGui::TreePop();
            }

            ImGui::PopID();
        }
    }

    // ---------------------------------------------------------------
    //  GUI: Controls help
    // ---------------------------------------------------------------

    void draw_controls_help() {
        if (ImGui::CollapsingHeader("Controls")) {
            ImGui::BulletText("Left-click: select node");
            ImGui::BulletText("Right-drag: orbit");
            ImGui::BulletText("Middle-drag: pan");
            ImGui::BulletText("Scroll: zoom");
            ImGui::BulletText("ESC / close window: exit");
        }
    }

    // ---------------------------------------------------------------
    //  Hover highlight — softer wireframe for all nodes in a group
    // ---------------------------------------------------------------

    void update_hover_highlight() {
        bool changed = (m_hoveredGroupId != m_prevHoveredGroupId) ||
                       (m_hoveredNodeName != m_prevHoveredNodeName);
        if (!changed) return;

        // Remove previous hover highlight.
        remove_hover_highlight();
        m_prevHoveredGroupId = m_hoveredGroupId;
        m_prevHoveredNodeName = m_hoveredNodeName;

        if (!m_groupMgr) return;

        // Build list of nodes to highlight.
        std::vector<std::string> nodesToHighlight;

        if (!m_hoveredNodeName.empty()) {
            // Hovering a specific node in the expanded list — highlight just that one.
            nodesToHighlight.push_back(m_hoveredNodeName);
        } else if (m_hoveredGroupId >= 0) {
            // Hovering a group row — highlight all nodes in the group.
            auto* group = m_groupMgr->group_by_id(m_hoveredGroupId);
            if (group) nodesToHighlight = group->nodes;
        }

        if (nodesToHighlight.empty()) return;

        m_hoverHighlightGroup = vsg::Group::create();

        for (const auto& nodeName : nodesToHighlight) {
            auto it = m_nodePathMap.find(nodeName);
            if (it == m_nodePathMap.end()) continue;
            if (it->second.geomChildren.empty()) continue;

            // Skip if this node is already selected (has red wireframe).
            if (m_hasSelection && nodeName == m_selectedShortName) continue;

            auto transform = vsg::MatrixTransform::create();
            transform->matrix = it->second.worldMatrix;

            auto shaderSet = vsg::createFlatShadedShaderSet();
            auto config = vsg::GraphicsPipelineConfigurator::create(shaderSet);

            auto rasterState = vsg::RasterizationState::create();
            rasterState->polygonMode = VK_POLYGON_MODE_LINE;
            rasterState->lineWidth = 1.0f;
            rasterState->cullMode = VK_CULL_MODE_NONE;

            auto colorBlend = vsg::ColorBlendState::create();
            VkPipelineColorBlendAttachmentState blendAttachment{};
            blendAttachment.blendEnable = VK_TRUE;
            blendAttachment.srcColorBlendFactor = VK_BLEND_FACTOR_SRC_ALPHA;
            blendAttachment.dstColorBlendFactor = VK_BLEND_FACTOR_ONE_MINUS_SRC_ALPHA;
            blendAttachment.colorBlendOp = VK_BLEND_OP_ADD;
            blendAttachment.srcAlphaBlendFactor = VK_BLEND_FACTOR_ONE;
            blendAttachment.dstAlphaBlendFactor = VK_BLEND_FACTOR_ZERO;
            blendAttachment.alphaBlendOp = VK_BLEND_OP_ADD;
            blendAttachment.colorWriteMask = VK_COLOR_COMPONENT_R_BIT | VK_COLOR_COMPONENT_G_BIT |
                                             VK_COLOR_COMPONENT_B_BIT | VK_COLOR_COMPONENT_A_BIT;
            colorBlend->attachments = {blendAttachment};

            auto depthState = vsg::DepthStencilState::create();
            depthState->depthTestEnable = VK_FALSE;
            depthState->depthWriteEnable = VK_FALSE;

            for (auto& ps : config->pipelineStates) {
                if (ps.cast<vsg::RasterizationState>()) ps = rasterState;
                else if (ps.cast<vsg::ColorBlendState>()) ps = colorBlend;
                else if (ps.cast<vsg::DepthStencilState>()) ps = depthState;
            }

            // Always white for hover wireframe — visible against any group color.
            auto mat = vsg::PhongMaterialValue::create();
            mat->value().ambient  = vsg::vec4{1.0f, 1.0f, 1.0f, 0.15f};
            mat->value().diffuse  = vsg::vec4{1.0f, 1.0f, 1.0f, 0.15f};
            mat->value().specular = vsg::vec4{0.0f, 0.0f, 0.0f, 0.0f};
            mat->value().emissive = vsg::vec4{1.0f, 1.0f, 1.0f, 0.15f};
            mat->value().shininess = 0.0f;
            config->assignDescriptor("material", mat);
            config->init();

            auto stateGroup = vsg::StateGroup::create();
            config->copyTo(stateGroup->stateCommands);
            for (auto& child : it->second.geomChildren) stateGroup->addChild(child);
            transform->addChild(stateGroup);
            m_hoverHighlightGroup->addChild(transform);
        }

        if (m_hoverHighlightGroup->children.empty()) {
            m_hoverHighlightGroup = {};
            return;
        }

        m_sceneRoot->addChild(m_hoverHighlightGroup);

        if (m_viewer && m_viewer->compileManager) {
            auto result = m_viewer->compileManager->compile(m_hoverHighlightGroup);
            vsg::updateTasks(m_viewer->recordAndSubmitTasks, m_viewer->compileManager, result);
        }
    }

    void remove_hover_highlight() {
        if (m_hoverHighlightGroup && m_sceneRoot) {
            auto& children = m_sceneRoot->children;
            children.erase(
                std::remove(children.begin(), children.end(),
                            vsg::ref_ptr<vsg::Node>(m_hoverHighlightGroup)),
                children.end());
            m_hoverHighlightGroup = {};
        }
    }

    // ---------------------------------------------------------------
    //  Click handler
    // ---------------------------------------------------------------

    void on_click(int32_t x, int32_t y) {
        if (!m_camera || !m_sceneRoot) return;

        remove_highlight();

        auto intersector = vsg::LineSegmentIntersector::create(*m_camera, x, y);
        m_sceneRoot->accept(*intersector);

        if (intersector->intersections.empty()) {
            if (!m_selectedNodeName.empty()) {
                m_selectedNodeName.clear();
                m_selectedShortName.clear();
                m_hasSelection = false;
                std::printf("[EASIR] Deselected\n");
            }
            return;
        }

        auto& isects = intersector->intersections;
        auto closest = std::min_element(isects.begin(), isects.end(),
            [](const auto& a, const auto& b) { return a->ratio < b->ratio; });
        auto& hit = *closest;

        std::string nodeName = find_node_name(hit->nodePath);
        std::string shortName = SemanticGroupManager::extract_short_name(nodeName);

        m_selectionPoint = hit->worldIntersection;
        m_hasSelection = true;
        m_selectedNodeName = nodeName;
        m_selectedShortName = shortName;

        std::printf("[EASIR] Selected: '%s' at (%.2f, %.2f, %.2f)\n",
                    shortName.c_str(),
                    hit->worldIntersection.x,
                    hit->worldIntersection.y,
                    hit->worldIntersection.z);

        add_highlight(hit->nodePath);
    }

    // ---------------------------------------------------------------
    //  Node name extraction
    // ---------------------------------------------------------------

    static std::string find_node_name(const vsg::Intersector::NodePath& nodePath) {
        for (auto it = nodePath.rbegin(); it != nodePath.rend(); ++it) {
            std::string name;
            if ((*it)->getValue("name", name) && !name.empty()) {
                return name;
            }
        }
        return "<unnamed>";
    }

    // ---------------------------------------------------------------
    //  Selection wireframe highlight
    // ---------------------------------------------------------------

    void add_highlight(const vsg::Intersector::NodePath& nodePath) {
        const vsg::Node* meshNode = nullptr;
        size_t meshIdx = 0;
        for (size_t i = nodePath.size(); i > 0; --i) {
            std::string name;
            if (nodePath[i - 1]->getValue("name", name) && !name.empty()) {
                meshNode = nodePath[i - 1];
                meshIdx = i - 1;
                break;
            }
        }
        if (!meshNode) return;

        vsg::dmat4 worldMatrix(1.0);
        for (size_t i = 0; i <= meshIdx; ++i) {
            auto mt = dynamic_cast<const vsg::MatrixTransform*>(nodePath[i]);
            if (mt) worldMatrix = worldMatrix * mt->matrix;
        }

        // Extract raw geometry nodes by digging through StateGroups.
        // This ensures the wireframe pipeline isn't overridden by child StateGroups.
        std::vector<vsg::ref_ptr<vsg::Node>> geomChildren;
        auto* group = dynamic_cast<const vsg::Group*>(meshNode);
        if (group) {
            // Use the same geometry extraction as the discovery visitor.
            struct GeomCollector {
                static void collect(const vsg::Group* g, std::vector<vsg::ref_ptr<vsg::Node>>& out) {
                    for (auto& child : g->children) {
                        auto* sg = dynamic_cast<const vsg::StateGroup*>(child.get());
                        if (sg) {
                            for (auto& sgChild : sg->children) out.push_back(sgChild);
                            continue;
                        }
                        auto* grp = dynamic_cast<const vsg::Group*>(child.get());
                        if (grp) { collect(grp, out); continue; }
                        out.push_back(child);
                    }
                }
            };
            GeomCollector::collect(group, geomChildren);
        } else {
            geomChildren.push_back(vsg::ref_ptr<vsg::Node>(const_cast<vsg::Node*>(meshNode)));
        }

        m_highlightGroup = vsg::Group::create();

        {
            auto transform = vsg::MatrixTransform::create();
            transform->matrix = worldMatrix;

            auto shaderSet = vsg::createFlatShadedShaderSet();
            auto config = vsg::GraphicsPipelineConfigurator::create(shaderSet);

            auto rasterState = vsg::RasterizationState::create();
            rasterState->polygonMode = VK_POLYGON_MODE_LINE;
            rasterState->lineWidth = 2.0f;
            rasterState->cullMode = VK_CULL_MODE_NONE;

            auto colorBlend = vsg::ColorBlendState::create();
            VkPipelineColorBlendAttachmentState blendAttachment{};
            blendAttachment.blendEnable = VK_TRUE;
            blendAttachment.srcColorBlendFactor = VK_BLEND_FACTOR_SRC_ALPHA;
            blendAttachment.dstColorBlendFactor = VK_BLEND_FACTOR_ONE_MINUS_SRC_ALPHA;
            blendAttachment.colorBlendOp = VK_BLEND_OP_ADD;
            blendAttachment.srcAlphaBlendFactor = VK_BLEND_FACTOR_ONE;
            blendAttachment.dstAlphaBlendFactor = VK_BLEND_FACTOR_ZERO;
            blendAttachment.alphaBlendOp = VK_BLEND_OP_ADD;
            blendAttachment.colorWriteMask = VK_COLOR_COMPONENT_R_BIT | VK_COLOR_COMPONENT_G_BIT |
                                             VK_COLOR_COMPONENT_B_BIT | VK_COLOR_COMPONENT_A_BIT;
            colorBlend->attachments = {blendAttachment};

            auto depthState = vsg::DepthStencilState::create();
            depthState->depthTestEnable = VK_FALSE;
            depthState->depthWriteEnable = VK_FALSE;

            for (auto& ps : config->pipelineStates) {
                if (ps.cast<vsg::RasterizationState>()) ps = rasterState;
                else if (ps.cast<vsg::ColorBlendState>()) ps = colorBlend;
                else if (ps.cast<vsg::DepthStencilState>()) ps = depthState;
            }

            auto mat = vsg::PhongMaterialValue::create();
            mat->value().ambient  = vsg::vec4{1.0f, 0.0f, 0.0f, 0.3f};
            mat->value().diffuse  = vsg::vec4{1.0f, 0.0f, 0.0f, 0.3f};
            mat->value().specular = vsg::vec4{0.0f, 0.0f, 0.0f, 0.0f};
            mat->value().emissive = vsg::vec4{1.0f, 0.0f, 0.0f, 0.3f};
            mat->value().shininess = 0.0f;
            config->assignDescriptor("material", mat);
            config->init();

            auto stateGroup = vsg::StateGroup::create();
            config->copyTo(stateGroup->stateCommands);
            for (auto& child : geomChildren) stateGroup->addChild(child);
            transform->addChild(stateGroup);
            m_highlightGroup->addChild(transform);
        }

        m_sceneRoot->addChild(m_highlightGroup);

        if (m_viewer && m_viewer->compileManager) {
            auto result = m_viewer->compileManager->compile(m_highlightGroup);
            if (result.requiresViewerUpdate()) {
                vsg::updateTasks(m_viewer->recordAndSubmitTasks, m_viewer->compileManager, result);
            }
        }
    }

    void remove_highlight() {
        if (m_highlightGroup && m_sceneRoot) {
            auto& children = m_sceneRoot->children;
            children.erase(
                std::remove(children.begin(), children.end(),
                            vsg::ref_ptr<vsg::Node>(m_highlightGroup)),
                children.end());
            m_highlightGroup = {};
        }
    }

    // ---------------------------------------------------------------
    //  Scene color update flag
    // ---------------------------------------------------------------
public:
    bool needs_scene_color_update() const { return m_needsSceneColorUpdate; }
    void clear_scene_color_update() { m_needsSceneColorUpdate = false; }
private:
    bool m_needsSceneColorUpdate = false;
};

} // namespace easir
