classdef Easir < handle
    %EASIR  MATLAB wrapper for the EASIR headless renderer DLL.
    %
    %   r = Easir(config_json)   Create a renderer with the given config.
    %   r = Easir()              Create a renderer with default config.
    %
    %   r.set_state(state_json)  Update dynamic state (camera, objects, …).
    %   r.render()               Render one frame.
    %   img = r.get_image()      Retrieve the rendered image as [H,W,4] uint8.
    %   cfg = r.get_config()     Get the live config as a MATLAB struct.
    %   st  = r.get_state()      Get the live state as a MATLAB struct.
    %
    %   clear r                  Destroy the renderer and release GPU resources.
    %
    %   Static helpers (no renderer needed):
    %   cfg = Easir.default_config()   Default EasirConfig as a struct.
    %   st  = Easir.default_state()    Default EasirState as a struct.
    %   err = Easir.last_error()       Last error message from the DLL.
    %
    %   Example:
    %     cfg = Easir.default_config();
    %     cfg.camera.width  = 1280;
    %     cfg.camera.height = 720;
    %     r = Easir(jsonencode(cfg));
    %     r.render();
    %     img = r.get_image();
    %     imshow(img(:,:,1:3));
    %     clear r;

    properties (Access = private)
        Handle uint64 = 0
    end

    properties (Constant, Access = private)
        LibName = 'easir'
    end

    % ---------------------------------------------------------------
    %  Construction / destruction
    % ---------------------------------------------------------------
    methods
        function obj = Easir(config_json)
            %EASIR  Create a headless renderer instance.
            %   r = Easir(config_json)  — config as a JSON string
            %   r = Easir()             — use all defaults
            Easir.ensure_loaded();

            if nargin < 1 || isempty(config_json)
                config_json = '{}';
            end

            h = calllib(Easir.LibName, 'easir_create', config_json);
            if h == 0
                error('Easir:createFailed', 'easir_create failed: %s', ...
                    Easir.last_error());
            end
            obj.Handle = h;
        end

        function delete(obj)
            if obj.Handle ~= 0
                calllib(Easir.LibName, 'easir_destroy', obj.Handle);
                obj.Handle = 0;
            end
        end
    end

    % ---------------------------------------------------------------
    %  Instance methods
    % ---------------------------------------------------------------
    methods
        function set_state(obj, state_json)
            %SET_STATE  Update dynamic state for the next render call.
            obj.check_handle();
            rc = calllib(Easir.LibName, 'easir_set_state', ...
                obj.Handle, state_json);
            if rc ~= 0
                error('Easir:setStateFailed', 'easir_set_state failed: %s', ...
                    Easir.last_error());
            end
        end

        function rc = render(obj)
            %RENDER  Execute one render frame.  Returns 0 on success.
            obj.check_handle();
            rc = calllib(Easir.LibName, 'easir_render', obj.Handle);
        end

        function [w, h, ch] = get_image_info(obj)
            %GET_IMAGE_INFO  Query dimensions of the last rendered image.
            obj.check_handle();
            wp = libpointer('int32Ptr', 0);
            hp = libpointer('int32Ptr', 0);
            cp = libpointer('int32Ptr', 0);
            rc = calllib(Easir.LibName, 'easir_get_image_info', ...
                obj.Handle, wp, hp, cp);
            if rc ~= 0
                error('Easir:noImage', 'No rendered image available: %s', ...
                    Easir.last_error());
            end
            w  = wp.Value;
            h  = hp.Value;
            ch = cp.Value;
        end

        function img = get_image(obj)
            %GET_IMAGE  Retrieve the rendered image as [H, W, 4] uint8 RGBA.
            [w, h, ch] = obj.get_image_info();
            n = w * h * ch;
            bufptr = libpointer('uint8Ptr', zeros(n, 1, 'uint8'));
            rc = calllib(Easir.LibName, 'easir_get_image', ...
                obj.Handle, bufptr, int32(n));
            if rc ~= 0
                error('Easir:getImageFailed', 'easir_get_image failed: %s', ...
                    Easir.last_error());
            end
            buf = bufptr.Value;
            img = permute(reshape(buf, [ch, w, h]), [3, 2, 1]);
        end

        function cfg = get_config(obj)
            %GET_CONFIG  Return the live config as a MATLAB struct.
            obj.check_handle();
            s = calllib(Easir.LibName, 'easir_get_config', obj.Handle);
            cfg = jsondecode(s);
        end

        function st = get_state(obj)
            %GET_STATE  Return the live state as a MATLAB struct.
            obj.check_handle();
            s = calllib(Easir.LibName, 'easir_get_state', obj.Handle);
            st = jsondecode(s);
        end
    end

    % ---------------------------------------------------------------
    %  Static helpers
    % ---------------------------------------------------------------
    methods (Static)
        function cfg = default_config()
            %DEFAULT_CONFIG  Return the default EasirConfig as a struct.
            Easir.ensure_loaded();
            s = calllib(Easir.LibName, 'easir_get_default_config');
            cfg = jsondecode(s);
        end

        function st = default_state()
            %DEFAULT_STATE  Return the default EasirState as a struct.
            Easir.ensure_loaded();
            s = calllib(Easir.LibName, 'easir_get_default_state');
            st = jsondecode(s);
        end

        function msg = last_error()
            %LAST_ERROR  Return the last error message from the DLL.
            Easir.ensure_loaded();
            msg = calllib(Easir.LibName, 'easir_get_last_error');
        end
    end

    % ---------------------------------------------------------------
    %  Private helpers
    % ---------------------------------------------------------------
    methods (Access = private)
        function check_handle(obj)
            if obj.Handle == 0
                error('Easir:invalidHandle', 'Renderer has been destroyed.');
            end
        end
    end

    methods (Static, Access = private)
        function ensure_loaded()
            %ENSURE_LOADED  Load the DLL if not already loaded.
            if libisloaded(Easir.LibName)
                return
            end

            this_dir  = fileparts(mfilename('fullpath'));
            repo_root = fullfile(this_dir, '..');

            dll_dir     = fullfile(repo_root, 'build_vs', 'bin', 'Release');
            header_path = fullfile(repo_root, 'include', 'easir', 'easir_api.h');

            % Put the DLL directory on PATH so MATLAB can find easir.dll
            % and any Vulkan runtime dependencies.
            if ~contains(getenv('PATH'), dll_dir)
                setenv('PATH', [dll_dir ';' getenv('PATH')]);
            end

            if ~isfile(fullfile(dll_dir, 'easir.dll'))
                error('Easir:dllNotFound', ...
                    ['easir.dll not found in:\n  %s\n' ...
                     'Build it first:\n' ...
                     '  cmake --build build_vs --config Release --target easir'], ...
                    dll_dir);
            end

            [~, warnings] = loadlibrary(Easir.LibName, header_path);
            % Filter out known-harmless Windows SDK header-parsing noise.
            if ~isempty(warnings)
                dominated_by_sdk = contains(warnings, ...
                    {'__crt_locale_data', '__crt_multibyte_data', ...
                     'corecrt.h', 'Unescaped left brace'});
                unexpected = warnings(~dominated_by_sdk);
                if ~isempty(unexpected)
                    warning('Easir:loadWarnings', ...
                        'Unexpected loadlibrary warnings:\n%s', ...
                        strjoin(unexpected, '\n'));
                end
            end
        end
    end
end
