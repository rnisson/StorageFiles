%% easir_example.m
% Demonstrates using the EASIR DLL from MATLAB via the Easir wrapper class.
%
% Prerequisites:
%   1. Build the 'easir' DLL:
%        cmake --build build_vs --config Release --target easir
%   2. Vulkan SDK installed (vulkan-1.dll must be on PATH).
%   3. MATLAB R2009b or later.
%
% Usage:
%   >> cd('path/to/EASIR/matlab')
%   >> easir_example

%% --- 0. Setup ---
repo_root   = fullfile(fileparts(mfilename('fullpath')), '..');
config_path = fullfile(repo_root, 'configs', 'default_config.json');
state_path  = fullfile(repo_root, 'configs', 'default_state.json');

%% --- 1. Inspect defaults ---
def_cfg = Easir.default_config();
def_st  = Easir.default_state();

fprintf('Default config fields: %s\n', strjoin(fieldnames(def_cfg), ', '));
fprintf('Default state  fields: %s\n', strjoin(fieldnames(def_st), ', '));

%% --- 2. Build config ---
cfg = jsondecode(fileread(config_path));

% Set data_root so the DLL can find assets relative to the repo.
cfg.data_root = strrep(repo_root, '\', '/');

% Set render resolution.
cfg.camera.width  = 1280;
cfg.camera.height = 720;

%% --- 3. Create renderer (headless) ---
r = Easir(jsonencode(cfg));
disp('Renderer created.');

%% --- 4. Set dynamic state ---
st = jsondecode(fileread(state_path));
st.camera_position    = [0; 0; 10];
st.camera_orientation = [0; 0; 0; 1];
st.sun_direction      = [0.7071; 0.7071; 0];

r.set_state(jsonencode(st));

%% --- 5. Render ---
for i = 1:3
    rc = r.render();
    fprintf('  render frame %d: rc=%d\n', i, rc);
end

%% --- 6. Retrieve the rendered image ---
img = r.get_image();
fprintf('Image: %dx%d, %d channels (RGBA)\n', ...
    size(img, 2), size(img, 1), size(img, 3));

% Display RGB (drop alpha).
figure('Name', 'EASIR Render');
imshow(img(:,:,1:3));
title(sprintf('EASIR — %dx%d', size(img, 2), size(img, 1)));
drawnow;

% Save.
out_path = fullfile(repo_root, 'easir_matlab_output.png');
imwrite(img(:,:,1:3), out_path);
fprintf('Saved: %s\n', out_path);

%% --- 7. Round-trip config ---
live_cfg = r.get_config();
disp('Round-trip config verified.');

%% --- 8. Cleanup ---
clear r;
disp('Done.');
