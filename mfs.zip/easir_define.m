%% easir_define.m
% Load the EASIR DLL and verify all API functions are available.
%
% This script is optional — the Easir wrapper class calls loadlibrary
% automatically.  Run it to check that the DLL loads correctly and to
% see the list of available functions.
%
% Prerequisites:
%   - MATLAB R2009b or later
%   - Vulkan SDK installed
%   - easir.dll built:  cmake --build build_vs --config Release --target easir

%% --- Paths ---
repo_root   = fullfile(fileparts(mfilename('fullpath')), '..');
dll_dir     = fullfile(repo_root, 'build_vs', 'bin', 'Release');
header_path = fullfile(repo_root, 'include', 'easir', 'easir_api.h');

if ~isfile(fullfile(dll_dir, 'easir.dll'))
    error('easir:notFound', ...
        ['DLL not found at:\n  %s\n' ...
         'Build it first:\n' ...
         '  cmake --build build_vs --config Release --target easir'], ...
        dll_dir);
end

%% --- Ensure DLL directory is on PATH ---
if ~contains(getenv('PATH'), dll_dir)
    setenv('PATH', [dll_dir ';' getenv('PATH')]);
end

%% --- Load the library ---
if libisloaded('easir')
    unloadlibrary('easir');
end

loadlibrary('easir', header_path);

%% --- Verify ---
funcs = libfunctions('easir', '-full');
fprintf('\n=== EASIR library loaded ===\n');
fprintf('Functions available: %d\n', numel(funcs));
for i = 1:numel(funcs)
    fprintf('  %s\n', funcs{i});
end
fprintf('\nUse the Easir wrapper class for a clean API:\n');
fprintf('  r = Easir(config_json);\n');
fprintf('  r.render();\n');
fprintf('  img = r.get_image();\n');
fprintf('See easir_example.m for a full demo.\n');
