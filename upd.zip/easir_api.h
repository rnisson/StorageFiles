#pragma once

/**
 * @file easir_api.h
 * @brief Flat C API for the EASIR renderer — consumable from MATLAB via loadlibrary().
 *
 * All functions use basic C types and opaque handles so that MATLAB's
 * loadlibrary() can parse this header directly without code generation.
 *
 * Usage pattern:
 * @code
 *   EasirHandle h = easir_create(config_json_str);
 *   easir_set_state(h, state_json_str);
 *   easir_render(h);
 *
 *   int w, h_px, ch;
 *   easir_get_image_info(h, &w, &h_px, &ch);
 *   unsigned char* buf = malloc(w * h_px * ch);
 *   easir_get_image(h, buf, w * h_px * ch);
 *
 *   easir_destroy(h);
 * @endcode
 *
 * Returned strings are owned by the library via thread-local storage and
 * remain valid until the next string-returning API call on the same thread.
 * easir_free_string() is provided for backward compatibility but is a no-op.
 */

#ifdef __cplusplus
extern "C" {
#endif

#include <stddef.h>
#include <stdint.h>

// ---------------------------------------------------------------------------
// Export / import macro
// ---------------------------------------------------------------------------
// When building the DLL:  easir_EXPORTS is defined by CMake → dllexport
// Otherwise (EXE, MATLAB clibgen, external consumer): empty.
//
// dllimport is intentionally omitted — it is only an optimisation hint for
// function calls and is not required for correct linking via the import
// library.  Omitting it lets MATLAB's clibgen parse this header directly.
#if defined(easir_EXPORTS)
  #ifdef _WIN32
    #define EASIR_API __declspec(dllexport)
  #else
    #define EASIR_API __attribute__((visibility("default")))
  #endif
#else
  #define EASIR_API
#endif

// ---------------------------------------------------------------------------
// Opaque handle
// ---------------------------------------------------------------------------

typedef uint64_t EasirHandle;

// ---------------------------------------------------------------------------
// Lifecycle
// ---------------------------------------------------------------------------

/**
 * @brief Create a renderer instance.
 *
 * @param config_json  UTF-8 JSON string conforming to the EasirConfig schema.
 *                     Pass NULL or an empty string to use all defaults.
 * @return Opaque handle on success, NULL on failure.
 *         Call easir_get_last_error() to retrieve a description.
 */
EASIR_API EasirHandle easir_create(const char* config_json);

/**
 * @brief Destroy a renderer instance and release all Vulkan resources.
 *
 * @param handle  Handle returned by easir_create(). Passing NULL is a no-op.
 */
EASIR_API void easir_destroy(EasirHandle handle);

// ---------------------------------------------------------------------------
// State updates
// ---------------------------------------------------------------------------

/**
 * @brief Update the dynamic state for the next render call.
 *
 * @param handle      Valid EasirHandle.
 * @param state_json  UTF-8 JSON string conforming to the EasirState schema.
 *                    Pass NULL or empty string to leave state unchanged.
 * @return 0 on success, non-zero on error.
 */
EASIR_API int easir_set_state(EasirHandle handle, const char* state_json);

// ---------------------------------------------------------------------------
// Rendering
// ---------------------------------------------------------------------------

/**
 * @brief Execute one render frame.
 *
 * In headless mode the result is written to the internal image buffer;
 * retrieve it immediately with easir_get_image().
 *
 * @param handle  Valid EasirHandle.
 * @return 0 on success, non-zero on error.
 */
EASIR_API int easir_render(EasirHandle handle);

// ---------------------------------------------------------------------------
// Image output
// ---------------------------------------------------------------------------

/**
 * @brief Query the dimensions of the last rendered image.
 *
 * @param handle    Valid EasirHandle.
 * @param width     [out] Image width in pixels.
 * @param height    [out] Image height in pixels.
 * @param channels  [out] Number of channels (always 4).
 * @return 0 on success, non-zero if no image is available yet.
 */
EASIR_API int easir_get_image_info(EasirHandle handle,
                                  int* width, int* height, int* channels);

/**
 * @brief Copy the rendered pixel buffer (RGBA8) into a caller-owned buffer.
 *
 * The caller must allocate at least width * height * channels bytes.
 * Call easir_get_image_info() first to learn the required size.
 *
 * @param handle    Valid EasirHandle.
 * @param buffer    [out] Caller-allocated buffer to receive the pixel data.
 * @param buf_size  Size of the buffer in bytes (must be >= w * h * channels).
 * @return 0 on success, non-zero on error.
 */
EASIR_API int easir_get_image(EasirHandle handle,
                             unsigned char* buffer,
                             int            buf_size);

// ---------------------------------------------------------------------------
// Introspection — returns thread-local JSON strings
// ---------------------------------------------------------------------------

/**
 * @brief Return the current config as a pretty-printed JSON string.
 * Valid until the next string-returning API call on the same thread.
 */
EASIR_API const char* easir_get_config(EasirHandle handle);

/**
 * @brief Return the current state as a pretty-printed JSON string.
 * Valid until the next string-returning API call on the same thread.
 */
EASIR_API const char* easir_get_state(EasirHandle handle);

/**
 * @brief Return the default EasirConfig as a pretty-printed JSON string.
 * Valid until the next string-returning API call on the same thread.
 */
EASIR_API const char* easir_get_default_config(void);

/**
 * @brief Return the default EasirState as a pretty-printed JSON string.
 * Valid until the next string-returning API call on the same thread.
 */
EASIR_API const char* easir_get_default_state(void);

/**
 * @brief No-op, retained for backward compatibility.
 *
 * Returned strings are now managed by thread-local storage and do not
 * need to be freed by the caller.
 */
EASIR_API void easir_free_string(const char* str);

// ---------------------------------------------------------------------------
// Error reporting
// ---------------------------------------------------------------------------

/**
 * @brief Return a human-readable description of the last error that occurred.
 *
 * The returned pointer is owned by the library and is valid until the next
 * EASIR API call on the same thread.  Do not free it.
 */
EASIR_API const char* easir_get_last_error(void);

#ifdef __cplusplus
} // extern "C"
#endif
