# EASIR

**EASIR** (working title) is a physically-based rendering system for synthetic image generation in the space domain — spacecraft, star fields, and planetary bodies. It is built on [VulkanSceneGraph (VSG)](https://github.com/vsg-dev/VulkanSceneGraph) and targets two use cases from a single codebase: a standalone windowed executable for visual iteration and regression testing, and a headless shared library (DLL/SO) loadable from MATLAB via `loadlibrary` for automated simulation workflows.

---

## Table of Contents

1. [Project Structure](#project-structure)
2. [Prerequisites & Vulkan SDK Setup](#prerequisites--vulkan-sdk-setup)
3. [Populating Vendored Dependencies](#populating-vendored-dependencies)
4. [Building (CLI)](#building-cli)
5. [Building (Visual Studio)](#building-visual-studio)
6. [Running the Executable](#running-the-executable)
7. [Using the DLL from MATLAB](#using-the-dll-from-matlab)
8. [Extending Config and State](#extending-config-and-state)
9. [API Reference](#api-reference)

---

## Project Structure

```
EASIR/
├── CMakeLists.txt               # Top-level build file (CMake 3.20+)
├── README.md
├── .gitignore
│
├── extern/                      # Vendored dependencies (see below)
│   ├── vsg/                     # VulkanSceneGraph source (git clone required)
│   ├── vsgXchange/              # VSG model loader — glTF/glb (git clone required)
│   └── nlohmann_json/           # JSON library — header-only, committed to repo
│
├── include/
│   └── easir/
│       ├── easir_api.h           # Flat C API (extern "C") — MATLAB entry point
│       ├── config.h             # EasirConfig struct + JSON serialisation
│       ├── state.h              # EasirState struct + JSON serialisation
│       ├── renderer.h           # EasirRenderer class
│       └── render_pipeline.h    # RenderPipeline + RenderPass abstractions
│
├── src/
│   ├── easir_api.cpp             # C API wrapper around EasirRenderer
│   ├── config.cpp               # Config helpers
│   ├── state.cpp                # State helpers
│   ├── renderer.cpp             # Core renderer implementation
│   ├── render_pipeline.cpp      # Pipeline + ForwardPass implementation
│   └── main.cpp                 # EXE entry point only
│
├── matlab/
│   ├── Easir.m                   # OOP wrapper class (loadlibrary/calllib)
│   ├── easir_example.m           # End-to-end MATLAB usage example
│   └── easir_define.m            # DLL load diagnostic script
│
├── assets/
│   └── test_geometry.glb        # Test model (not committed — see assets/README.md)
│
├── configs/
│   ├── default_config.json      # Default EasirConfig
│   └── default_state.json       # Default EasirState
│
└── docs/
    └── api_reference.md         # Full C API documentation
```

---

## Prerequisites & Vulkan SDK Setup

### Compiler

| Platform | Minimum version |
|----------|----------------|
| Windows  | MSVC 2022 (Visual Studio 17.x) — `/std:c++20` |
| Linux    | GCC 12 or Clang 15 — `-std=c++20` |

### CMake

CMake 3.20 or later. Download from https://cmake.org/download/.

### MATLAB (optional — for DLL usage)

MATLAB R2009b or later (uses `loadlibrary`/`calllib` — no toolbox dependencies).

### Vulkan SDK (Windows — step by step)

The Vulkan SDK is a **system-level prerequisite** and is not vendored.

1. Download the LunarG Vulkan SDK installer from  
   https://vulkan.lunarg.com/sdk/home#windows  
   Choose the latest stable release (≥ 1.3.x).

2. Run the installer. Accept the defaults. The installer sets the
   `VULKAN_SDK` environment variable automatically.

3. Open a new terminal and verify the installation:
   ```cmd
   echo %VULKAN_SDK%
   vulkaninfo | findstr "Vulkan Instance Version"
   ```
   You should see something like `Vulkan Instance Version: 1.3.xxx`.

4. If `vulkaninfo` is not found, add `%VULKAN_SDK%\Bin` to your `PATH`.

### Vulkan SDK (Linux — quick reference)

```bash
# Ubuntu / Debian
sudo apt update
sudo apt install libvulkan-dev vulkan-tools

# Or install the full LunarG SDK tarball for the latest version:
# https://vulkan.lunarg.com/sdk/home#linux
```

---

## Populating Vendored Dependencies

`nlohmann/json` is already committed to this repository under
`extern/nlohmann_json/`.

VSG and vsgXchange must be cloned separately (they are large C++ libraries):

```bash
git clone https://github.com/vsg-dev/VulkanSceneGraph.git extern/vsg
git clone https://github.com/vsg-dev/vsgXchange.git        extern/vsgXchange
```

Or configure them as git submodules:

```bash
git submodule add https://github.com/vsg-dev/VulkanSceneGraph.git extern/vsg
git submodule add https://github.com/vsg-dev/vsgXchange.git        extern/vsgXchange
git submodule update --init --recursive
```

CMake will emit a clear `FATAL_ERROR` if either directory is missing.

---

## Building (CLI)

```bash
# 1. Clone the repository (or pull latest)
git clone <repo-url> EASIR
cd EASIR

# 2. Populate vendored VSG dependencies (see above)
git clone https://github.com/vsg-dev/VulkanSceneGraph.git extern/vsg
git clone https://github.com/vsg-dev/vsgXchange.git        extern/vsgXchange

# 3. Configure
cmake -B build -DCMAKE_BUILD_TYPE=Release

# 4. Build
cmake --build build --config Release --parallel

# Outputs:
#   build/bin/easir_app      (or easir_app.exe on Windows)
#   build/bin/easir.dll      (Windows) / build/lib/libeasir.so (Linux)
```

### Build options

| Option              | Default | Description |
|---------------------|---------|-------------|
| `EASIR_BUILD_APP`    | `ON`    | Build the standalone executable. |
| `EASIR_BUILD_DLL`    | `ON`    | Build the shared library for MATLAB. |

Example — DLL only:
```bash
cmake -B build -DEASIR_BUILD_APP=OFF -DEASIR_BUILD_DLL=ON
```

---

## Building (Visual Studio)

```bash
# Generate a Visual Studio 2022 solution
cmake -G "Visual Studio 17 2022" -A x64 -B build_vs

# Open in Visual Studio
start build_vs\EASIR.sln
```

Select the `Release` configuration and build the `easir_app` or `easir` target
from the Solution Explorer.

---

## Running the Executable

```bash
# Use default config and state
./build/bin/easir_app

# Specify a config file
./build/bin/easir_app configs/default_config.json

# Specify both config and initial state
./build/bin/easir_app configs/default_config.json configs/default_state.json
```

The window will open and render the configured scene.  Close the window to exit.

---

## Using the DLL from MATLAB

EASIR provides an `Easir` wrapper class (`matlab/Easir.m`) that loads the DLL
automatically via `loadlibrary` and exposes a clean object-oriented API.  No
code-generation or build step is needed in MATLAB — just `cd` into `matlab/`
and start using it.

### Quick start

```matlab
cd('path/to/EASIR/matlab')
easir_example          % runs the full demo
```

### Manual usage

```matlab
% Inspect the default config
cfg = Easir.default_config();
cfg.camera.width  = 1280;
cfg.camera.height = 720;

% Create a headless renderer
r = Easir(jsonencode(cfg));

% Set state and render
st = Easir.default_state();
st.camera_position = [0; 0; 10];
r.set_state(jsonencode(st));
r.render();

% Retrieve the image as [H, W, 4] uint8 RGBA
img = r.get_image();
imshow(img(:,:,1:3));

% Cleanup (also happens automatically when r goes out of scope)
clear r;
```

### Diagnostics

Run `easir_define.m` to verify the DLL loads correctly and list all available
C API functions:

```matlab
easir_define
```

### MATLAB CRT compatibility

The CMake build automatically copies the MSVC runtime DLLs (`msvcp140.dll`,
`vcruntime140.dll`, `vcruntime140_1.dll`) next to `easir.dll`.  This ensures
that older MATLAB versions (e.g. R2019b) which bundle an older CRT don't
conflict with the MSVC 2022-built DLL.

If MATLAB still crashes on `easir_create`, verify that the runtime DLLs are
present in the same directory as `easir.dll`:

```
build_vs/bin/Release/
  easir.dll
  msvcp140.dll
  vcruntime140.dll
  vcruntime140_1.dll
```

If they are missing, manually copy them from your Visual Studio installation:

```
C:\Program Files\Microsoft Visual Studio\2022\<Edition>\VC\Redist\MSVC\<ver>\x64\
```

---

## Extending Config and State

EASIR is designed for easy extension.  The JSON serialisation uses `contains()`
guards so that **existing JSON files will never break** when new fields are added.

### Adding a new EasirConfig field

1. Add the field with a default value to the appropriate sub-struct in
   `include/easir/config.h`:
   ```cpp
   struct PipelineConfig {
       // ... existing fields ...
       bool my_new_pass = false;   // ← new field
   };
   ```

2. Add serialisation entries in the same header:
   ```cpp
   inline void to_json(nlohmann::json& j, const PipelineConfig& p) {
       j["my_new_pass"] = p.my_new_pass;  // ← add here
       // ...
   }
   inline void from_json(const nlohmann::json& j, PipelineConfig& p) {
       if (j.contains("my_new_pass")) j.at("my_new_pass").get_to(p.my_new_pass);
       // ...
   }
   ```

3. Update `configs/default_config.json` to include the new field.

4. Implement the behaviour in `src/render_pipeline.cpp`.

### Adding a new EasirState field

Same pattern — edit `include/easir/state.h` and `configs/default_state.json`.

Per-object fields (position, orientation, velocity) live in the `SceneObjectState`
struct; global fields (camera, sun, time) live in `EasirState`.

### Versioning note

The DLL binary API (`easir_api.h`) uses opaque handles and JSON strings, so
adding fields to the structs **does not change the ABI**.  MATLAB code written
against an older version of the DLL will continue to work.

---

## API Reference

See [`docs/api_reference.md`](docs/api_reference.md) for the full C API
documentation including all function signatures, parameters, return values,
and JSON schemas.
