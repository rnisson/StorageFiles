#include "easir/state.h"

#include <stdexcept>

namespace easir {

std::string state_to_json_string(const EasirState& state) {
    nlohmann::json j = state;
    return j.dump(4);
}

EasirState state_from_json_string(const std::string& json_str) {
    EasirState state{};
    if (json_str.empty()) {
        return state;
    }
    try {
        auto j = nlohmann::json::parse(json_str);
        j.get_to(state);
    } catch (const nlohmann::json::exception& ex) {
        throw std::runtime_error(std::string("EasirState JSON parse error: ") + ex.what());
    }
    return state;
}

std::string default_state_json() {
    return state_to_json_string(EasirState{});
}

} // namespace easir
