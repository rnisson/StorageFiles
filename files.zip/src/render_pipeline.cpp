#include "easir/render_pipeline.h"
#include "easir/math_utils.h"
#include "easir/trace.h"

#include <cstdio>
#include <filesystem>
#include <format>
#include <stdexcept>
#include <unordered_set>

namespace easir {

// ---------------------------------------------------------------------------
// ForwardPass
// ---------------------------------------------------------------------------

void ForwardPass::setup(RenderContext& ctx) {
    if (!ctx.scene_root || !ctx.config) {
        return;
    }

    // Create a group that will hold all scene geometry loaded from .glb files.
    m_scene_objects_group = vsg::Group::create();

    // vsgXchange options for loading glTF/glb assets.
    auto options = vsg::Options::create();
    options->add(vsgXchange::all::create());

    // Load each declared scene object (editor mode: first only).
    namespace fs = std::filesystem;
    const bool editor = ctx.config->global.editor_mode;
    EASIR_LOG("[EASIR] Loading %zu scene_objects (editor_mode=%d)\n",
              ctx.config->scene_objects.size(), editor ? 1 : 0);
    for (const auto& obj : ctx.config->scene_objects) {
        if (obj.asset_path.empty()) {
            continue;
        }
        // Resolve relative asset paths against data_root.
        fs::path asset_path(obj.asset_path);
        if (asset_path.is_relative() && !ctx.config->data_root.empty()) {
            asset_path = fs::path(ctx.config->data_root) / asset_path;
        }
        EASIR_LOG("[EASIR] Loading asset: %s\n", asset_path.string().c_str());
        auto node = vsg::read_cast<vsg::Node>(asset_path.string(), options);
        if (node) {
            // Wrap in a MatrixTransform so we can set position/orientation per frame.
            auto transform = vsg::MatrixTransform::create();
            transform->addChild(node);
            m_object_transforms[obj.id] = transform;
            m_asset_paths[obj.id] = asset_path;
            m_scene_objects_group->addChild(transform);
            EASIR_LOG("[EASIR] Loaded asset '%s' successfully\n", obj.id.c_str());
        } else {
            EASIR_LOG("[EASIR] WARNING: Failed to load asset: %s\n", asset_path.string().c_str());
        }

    }

    // Apply semantic rendering mode if requested.
    if (ctx.config->camera.render_mode == "semantic" || ctx.config->camera.render_mode == "edge") {
        EASIR_LOG("[EASIR] Render mode: semantic\n");
        EASIR_TRACE("ForwardPass::setup: semantic mode active");

        for (const auto& [id, transform] : m_object_transforms) {
            auto path_it = m_asset_paths.find(id);
            if (path_it == m_asset_paths.end()) continue;

            auto colorMap = SemanticColorMap::load(path_it->second);
            SemanticMaterialVisitor visitor(colorMap);
            transform->accept(visitor);

            // Per-asset material map (used by renderer.cpp to build AssetContext).
            auto& assetMap = m_per_asset_material_maps[id];
            for (auto& [name, mat] : visitor.material_map()) {
                assetMap[name] = mat;
                // Also populate legacy combined map for backward compat.
                m_materialMap[name] = mat;
            }

            EASIR_LOG("[EASIR] Applied semantic colors to %d nodes for object '%s' (%zu materials)\n",
                        visitor.replaced_count(), id.c_str(), assetMap.size());
            EASIR_TRACE("ForwardPass: replaced %d StateGroups for '%s'",
                        visitor.replaced_count(), id.c_str());
        }
    }

    // Directional light representing the sun.
    m_sun_light = vsg::DirectionalLight::create();
    m_sun_light->name      = "sun";
    m_sun_light->color     = vsg::vec3{
        ctx.config->universe.sun_color[0],
        ctx.config->universe.sun_color[1],
        ctx.config->universe.sun_color[2],
    };
    m_sun_light->intensity = ctx.config->universe.sun_intensity;

    // Default direction — will be overridden each frame in execute().
    m_sun_light->direction = vsg::vec3{1.0f, 0.0f, 0.0f};

    // Ambient light.
    auto ambient = vsg::AmbientLight::create();
    ambient->name      = "ambient";
    ambient->color     = vsg::vec3{1.0f, 1.0f, 1.0f};
    ambient->intensity = ctx.config->universe.ambient_intensity;

    ctx.scene_root->addChild(m_sun_light);
    ctx.scene_root->addChild(ambient);
    ctx.scene_root->addChild(m_scene_objects_group);
}

/// Build a 4x4 model matrix from position (metres) and orientation quaternion [x,y,z,w].
static vsg::dmat4 pose_to_matrix(const std::array<double, 3>& pos,
                                  const std::array<double, 4>& q) {
    const double x = q[0], y = q[1], z = q[2], w = q[3];

    // Rotation matrix from unit quaternion.
    vsg::dmat4 m(
        1.0 - 2.0*(y*y + z*z),  2.0*(x*y + w*z),        2.0*(x*z - w*y),        0.0,
        2.0*(x*y - w*z),         1.0 - 2.0*(x*x + z*z),  2.0*(y*z + w*x),        0.0,
        2.0*(x*z + w*y),         2.0*(y*z - w*x),         1.0 - 2.0*(x*x + y*y), 0.0,
        pos[0],                  pos[1],                  pos[2],                  1.0
    );
    return m;
}

void ForwardPass::execute(RenderContext& ctx) {
    if (!m_sun_light || !ctx.state) {
        return;
    }

    // In editor mode, skip sun direction update — the editor's [L] button
    // sets the direction manually and we don't want to overwrite it.
    if (!ctx.config->global.editor_mode) {
        m_sun_light->direction = vsg::vec3{
            static_cast<float>(ctx.state->sun_direction[0]),
            static_cast<float>(ctx.state->sun_direction[1]),
            static_cast<float>(ctx.state->sun_direction[2]),
        };
    }

    // Update per-object top-level transforms from state.
    for (const auto& obj_state : ctx.state->scene_objects) {
        auto it = m_object_transforms.find(obj_state.id);
        if (it != m_object_transforms.end()) {
            it->second->matrix = pose_to_matrix(obj_state.position, obj_state.orientation);
        }
    }

    // Phase L: drive EVERY registered joint each frame, walked by owning
    // top-level scene_object. The nested registry keeps joints with the same
    // local name on different spacecraft fully isolated. State overrides are
    // looked up under the joint's owning top — missing override = home pose,
    // so clearing a state entry snaps that joint back next frame.
    for (auto& [topId, jointMap] : m_joints) {
        // Find the matching SceneObjectState for this owning top, if any.
        const SceneObjectState* obj = nullptr;
        for (const auto& s : ctx.state->scene_objects) {
            if (s.id == topId) { obj = &s; break; }
        }

        for (auto& [jointName, binding] : jointMap) {
            const JointState* override = nullptr;
            if (obj) {
                auto jit = obj->joints.find(jointName);
                if (jit != obj->joints.end()) override = &jit->second;
            }
            const vsg::dvec3 pos = (override && override->position)
                ? array_to_dvec3(*override->position)
                : binding.homePos;
            const vsg::dquat q = (override && override->orientation)
                ? array_to_dquat(*override->orientation)
                : binding.homeQuat;
            binding.transform->matrix =
                pose_to_matrix_d_pivot(pos, q, binding.pivotOffset);
        }
    }

    // Secondary pass: warn (once) about state entries that reference a
    // joint that doesn't exist under the owning top. Catches typos and
    // stale references. Throttled per (top, name) pair so a recurring
    // typo only logs once per session.
    for (const auto& obj_state : ctx.state->scene_objects) {
        auto outerIt = m_joints.find(obj_state.id);
        for (const auto& [jointName, js] : obj_state.joints) {
            const bool topMissing = (outerIt == m_joints.end());
            const bool jointMissing = !topMissing &&
                (outerIt->second.find(jointName) == outerIt->second.end());
            if (topMissing || jointMissing) {
                static std::unordered_set<std::string> warnedUnknown;
                std::string key = obj_state.id + "|" + jointName;
                if (warnedUnknown.insert(key).second) {
                    EASIR_LOG("[EASIR] WARN: joint state '%s/%s' has no registered binding (one-time)\n",
                                obj_state.id.c_str(), jointName.c_str());
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// RenderPipeline
// ---------------------------------------------------------------------------

void RenderPipeline::build(const EasirConfig& config, RenderContext& ctx) {
    m_passes.clear();

    if (config.pipeline.forward_pass) {
        auto pass = std::make_unique<ForwardPass>();
        pass->setup(ctx);
        m_passes.push_back(std::move(pass));
    }

    // Future passes (shadow, bloom, star field, atmosphere …) can be added
    // here with their own config flags, e.g.:
    //
    //   if (config.pipeline.shadow_pass) {
    //       auto pass = std::make_unique<ShadowPass>();
    //       pass->setup(ctx);
    //       m_passes.push_back(std::move(pass));
    //   }
}

void RenderPipeline::execute(RenderContext& ctx) {
    for (auto& pass : m_passes) {
        pass->execute(ctx);
    }
}

void RenderPipeline::teardown(RenderContext& ctx) {
    for (auto& pass : m_passes) {
        pass->teardown(ctx);
    }
    m_passes.clear();
}

} // namespace easir
