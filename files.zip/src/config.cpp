#include "easir/config.h"

#include <stdexcept>

namespace easir {

std::string config_to_json_string(const EasirConfig& cfg) {
    nlohmann::json j = cfg;
    return j.dump(4);
}

EasirConfig config_from_json_string(const std::string& json_str) {
    EasirConfig cfg{};
    if (json_str.empty()) {
        return cfg;
    }
    try {
        auto j = nlohmann::json::parse(json_str);
        j.get_to(cfg);
    } catch (const nlohmann::json::exception& ex) {
        throw std::runtime_error(std::string("EasirConfig JSON parse error: ") + ex.what());
    }
    return cfg;
}

std::string default_config_json() {
    return config_to_json_string(EasirConfig{});
}

} // namespace easir
