#include "easir/semantic_map.h"
#include "easir/trace.h"

#include <nlohmann/json.hpp>

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <fstream>
#include <functional>

namespace easir {

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

std::string SemanticColorMap::extract_short_name(const std::string& full_name) {
    // vsgXchange stores names like "Aqua_Reduced_v0014 [Layer24]"
    // or "Aqua_Reduced_v0014 [Aqua_Layered_02 [Layer10]]"
    // We want the innermost bracketed portion: "Layer24" or "Layer10".
    auto last_open = full_name.rfind('[');
    if (last_open == std::string::npos) return full_name;

    // Find the first ']' after the last '[' (not rfind, which would grab trailing brackets).
    auto close = full_name.find(']', last_open + 1);
    if (close == std::string::npos || close <= last_open) return full_name;

    return full_name.substr(last_open + 1, close - last_open - 1);
}

/// HSV to RGB (h in [0,1], s,v in [0,1]).
static vsg::vec4 hsv_to_rgba(float h, float s, float v) {
    h = h - std::floor(h); // wrap to [0,1)
    float c = v * s;
    float x = c * (1.0f - std::fabs(std::fmod(h * 6.0f, 2.0f) - 1.0f));
    float m = v - c;
    float r, g, b;
    int sector = static_cast<int>(h * 6.0f) % 6;
    switch (sector) {
        case 0: r = c; g = x; b = 0; break;
        case 1: r = x; g = c; b = 0; break;
        case 2: r = 0; g = c; b = x; break;
        case 3: r = 0; g = x; b = c; break;
        case 4: r = x; g = 0; b = c; break;
        default: r = c; g = 0; b = x; break;
    }
    return vsg::vec4{r + m, g + m, b + m, 1.0f};
}

vsg::vec4 SemanticColorMap::auto_color(const std::string& name) {
    // Assign each unique name a sequential index, then use golden-ratio spacing
    // for maximally distinct hues. This avoids similar-named nodes (Layer2..Layer6)
    // getting clustered colors from hash collisions.
    static std::unordered_map<std::string, int> name_to_index;
    static int next_index = 0;

    auto it = name_to_index.find(name);
    if (it == name_to_index.end()) {
        name_to_index[name] = next_index++;
        it = name_to_index.find(name);
    }

    constexpr float golden_ratio_conjugate = 0.618033988749895f;
    float h = std::fmod(it->second * golden_ratio_conjugate, 1.0f);
    return hsv_to_rgba(h, 0.85f, 0.95f);
}

// ---------------------------------------------------------------------------
// load()
// ---------------------------------------------------------------------------

SemanticColorMap SemanticColorMap::load(const std::filesystem::path& glb_path) {
    namespace fs = std::filesystem;
    SemanticColorMap map;

    // Derive expected JSON path: same directory, <stem>_semantic_map.json
    auto json_path = glb_path.parent_path() / (glb_path.stem().string() + "_semantic_map.json");

    if (!fs::exists(json_path)) {
        EASIR_LOG("[EASIR] No %s found — using random per-node colors.\n",
                    json_path.filename().string().c_str());
        EASIR_LOG("[EASIR] Run easir_app in edit mode to configure semantic mapping.\n");
        EASIR_TRACE("SemanticColorMap::load: no map at %s", json_path.string().c_str());
        return map;
    }

    // Parse JSON
    std::ifstream ifs(json_path);
    if (!ifs) {
        EASIR_LOG("[EASIR] Warning: could not open %s\n", json_path.string().c_str());
        return map;
    }

    nlohmann::json root;
    try {
        ifs >> root;
    } catch (const nlohmann::json::parse_error& e) {
        EASIR_LOG("[EASIR] Warning: failed to parse %s: %s\n",
                    json_path.string().c_str(), e.what());
        return map;
    }

    // Parse classes
    if (!root.contains("classes") || !root["classes"].is_object()) {
        EASIR_LOG("[EASIR] Warning: %s has no 'classes' object\n",
                    json_path.string().c_str());
        return map;
    }

    int total_nodes = 0;
    int total_classes = 0;
    for (auto& [class_name, class_def] : root["classes"].items()) {
        // Parse color [R, G, B] in 0-255
        vsg::vec4 color{1.0f, 0.0f, 1.0f, 1.0f}; // magenta fallback
        if (class_def.contains("color") && class_def["color"].is_array() &&
            class_def["color"].size() >= 3) {
            color = vsg::vec4{
                class_def["color"][0].get<float>() / 255.0f,
                class_def["color"][1].get<float>() / 255.0f,
                class_def["color"][2].get<float>() / 255.0f,
                1.0f,
            };
        }

        // Parse nodes list
        if (class_def.contains("nodes") && class_def["nodes"].is_array()) {
            for (auto& node_val : class_def["nodes"]) {
                std::string node_name = node_val.get<std::string>();
                map.m_node_to_color[node_name] = color;
                ++total_nodes;
                EASIR_TRACE("  node '%s' -> class '%s' -> color (%.0f, %.0f, %.0f)",
                            node_name.c_str(), class_name.c_str(),
                            color.x * 255.0f, color.y * 255.0f, color.z * 255.0f);
            }
        }

        ++total_classes;
        EASIR_LOG("[EASIR] Semantic class '%s' (%d,%d,%d): %zu nodes\n",
                    class_name.c_str(),
                    static_cast<int>(color.x * 255.0f),
                    static_cast<int>(color.y * 255.0f),
                    static_cast<int>(color.z * 255.0f),
                    class_def.contains("nodes") ? class_def["nodes"].size() : 0u);
    }

    map.m_has_map = true;
    EASIR_LOG("[EASIR] Loaded semantic map: %s (%d classes, %d nodes)\n",
                json_path.filename().string().c_str(), total_classes, total_nodes);
    EASIR_TRACE("SemanticColorMap::load: loaded %d classes, %d nodes from %s",
                total_classes, total_nodes, json_path.string().c_str());
    return map;
}

// ---------------------------------------------------------------------------
// color_for_node()
// ---------------------------------------------------------------------------

vsg::vec4 SemanticColorMap::color_for_node(const std::string& node_name) const {
    if (!m_has_map) {
        // Auto mode: deterministic color from node name
        return auto_color(extract_short_name(node_name));
    }

    // Try short name first (e.g. "Layer24")
    auto short_name = extract_short_name(node_name);
    auto it = m_node_to_color.find(short_name);
    if (it != m_node_to_color.end()) {
        return it->second;
    }

    // Try full name
    it = m_node_to_color.find(node_name);
    if (it != m_node_to_color.end()) {
        return it->second;
    }

    // Not in map — use magenta to make unmapped nodes obvious
    EASIR_TRACE("SemanticColorMap: node '%s' not in map, using magenta", node_name.c_str());
    return vsg::vec4{1.0f, 0.0f, 1.0f, 1.0f};
}

} // namespace easir
