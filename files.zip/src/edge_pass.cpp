#include "easir/edge_pass.h"
#include "easir/trace.h"

#include <cstdio>
#include <cstring>
#include <string>

namespace easir {

// ---------------------------------------------------------------------------
// GLSL shaders (compiled to SPIR-V at runtime via glslang)
// ---------------------------------------------------------------------------

static const char* fullscreen_vert = R"(
#version 450

layout(location = 0) out vec2 fragUV;

// Full-screen triangle — no vertex buffer needed.
// gl_VertexIndex 0,1,2 produces a triangle that covers the entire screen.
void main() {
    fragUV = vec2((gl_VertexIndex << 1) & 2, gl_VertexIndex & 2);
    gl_Position = vec4(fragUV * 2.0 - 1.0, 0.0, 1.0);
    // No Y-flip: offscreen FBO and window both use Vulkan's top-left origin.
}
)";

// Edge detection fragment shader.
// Parameters are injected as #define constants by createEdgeDetectionPass().
static const char* edge_detect_frag_template = R"(
#version 450

layout(set = 0, binding = 0) uniform sampler2D sceneSampler;

layout(location = 0) in vec2 fragUV;
layout(location = 0) out vec4 outColor;

// Parameters injected via #define:
//   LINE_COLOR_R/G/B, BG_COLOR_R/G/B, LINE_WIDTH, TEXEL_W, TEXEL_H

// Check if a pixel is background (matches the scene clear color = black).
bool isBackground(vec2 uv) {
    vec3 c = texture(sceneSampler, uv).rgb;
    // Scene clear color is (0,0,0). Any non-black pixel is geometry.
    return (c.r + c.g + c.b) < BG_THRESHOLD;
}

void main() {
    float stepX = TEXEL_W * LINE_WIDTH;
    float stepY = TEXEL_H * LINE_WIDTH;

    // Center pixel: is it geometry?
    bool centerIsGeo = !isBackground(fragUV);

    // Silhouette: geometry pixel adjacent to background.
    // Edges extend inward from the geometric boundary.
    // Count how many neighbours are background — require at least 2 to filter
    // isolated single-pixel gaps in the mesh (erosion filter).
    int bgCount = 0;
    if (isBackground(fragUV + vec2(-stepX, -stepY))) bgCount++;
    if (isBackground(fragUV + vec2(   0.0, -stepY))) bgCount++;
    if (isBackground(fragUV + vec2( stepX, -stepY))) bgCount++;
    if (isBackground(fragUV + vec2(-stepX,    0.0))) bgCount++;
    if (isBackground(fragUV + vec2( stepX,    0.0))) bgCount++;
    if (isBackground(fragUV + vec2(-stepX,  stepY))) bgCount++;
    if (isBackground(fragUV + vec2(   0.0,  stepY))) bgCount++;
    if (isBackground(fragUV + vec2( stepX,  stepY))) bgCount++;
    float edge = (centerIsGeo && bgCount >= MIN_BG_COUNT) ? 1.0 : 0.0;

    vec3 lineColor = vec3(LINE_COLOR_R, LINE_COLOR_G, LINE_COLOR_B);
    vec3 bgColor   = vec3(BG_COLOR_R,   BG_COLOR_G,   BG_COLOR_B);
    vec3 color = mix(bgColor, lineColor, edge);

    // DEBUG: uncomment to see the offscreen scene render directly.
    // color = texture(sceneSampler, fragUV).rgb;

    outColor = vec4(color, 1.0);
}
)";

// ---------------------------------------------------------------------------
// Implementation
// ---------------------------------------------------------------------------

vsg::ref_ptr<vsg::Node> createEdgeDetectionPass(
    vsg::ref_ptr<vsg::ImageView> depthImageView,
    const RenderModesConfig& rm,
    uint32_t width,
    uint32_t height)
{
    EASIR_TRACE("createEdgeDetectionPass: %ux%u, mode=%s, lineWidth=%.1f",
                width, height, rm.edge_mode.c_str(), rm.edge_line_width);

    // --- Build fragment shader with parameters baked in as #defines --------
    char defines[1024];
    std::snprintf(defines, sizeof(defines),
        "#define LINE_COLOR_R %.6f\n"
        "#define LINE_COLOR_G %.6f\n"
        "#define LINE_COLOR_B %.6f\n"
        "#define BG_COLOR_R %.6f\n"
        "#define BG_COLOR_G %.6f\n"
        "#define BG_COLOR_B %.6f\n"
        "#define BG_THRESHOLD %.6f\n"
        "#define MIN_BG_COUNT %d\n"
        "#define LINE_WIDTH %.6f\n"
        "#define TEXEL_W %.10f\n"
        "#define TEXEL_H %.10f\n",
        rm.edge_line_color[0], rm.edge_line_color[1], rm.edge_line_color[2],
        rm.edge_background_color[0], rm.edge_background_color[1], rm.edge_background_color[2],
        rm.edge_bg_threshold,
        rm.edge_min_bg_count,
        rm.edge_line_width,
        1.0 / static_cast<double>(width),
        1.0 / static_cast<double>(height));

    // Inject #defines after the #version line.
    std::string fragSource = edge_detect_frag_template;
    auto versionPos = fragSource.find("#version");
    if (versionPos != std::string::npos) {
        auto versionEnd = fragSource.find('\n', versionPos);
        if (versionEnd != std::string::npos) {
            fragSource.insert(versionEnd + 1, defines);
        }
    }

    // --- Shaders -----------------------------------------------------------
    auto vertShader = vsg::ShaderStage::create(
        VK_SHADER_STAGE_VERTEX_BIT, "main", fullscreen_vert);
    auto fragShader = vsg::ShaderStage::create(
        VK_SHADER_STAGE_FRAGMENT_BIT, "main", fragSource);

    if (!vertShader || !fragShader) {
        EASIR_LOG("[EASIR] ERROR: Failed to create edge detection shaders\n");
        return {};
    }
    EASIR_TRACE("createEdgeDetectionPass: shaders created");

    // --- Descriptor set layout (binding 0 = depth sampler) -----------------
    VkDescriptorSetLayoutBinding dslBinding{};
    dslBinding.binding = 0;
    dslBinding.descriptorType = VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER;
    dslBinding.descriptorCount = 1;
    dslBinding.stageFlags = VK_SHADER_STAGE_FRAGMENT_BIT;
    dslBinding.pImmutableSamplers = nullptr;
    auto descriptorSetLayout = vsg::DescriptorSetLayout::create(
        vsg::DescriptorSetLayoutBindings{dslBinding});

    auto pipelineLayout = vsg::PipelineLayout::create(
        vsg::DescriptorSetLayouts{descriptorSetLayout},
        vsg::PushConstantRanges{});

    // --- Pipeline states ---------------------------------------------------
    auto vertexInputState = vsg::VertexInputState::create();
    auto inputAssemblyState = vsg::InputAssemblyState::create();
    inputAssemblyState->topology = VK_PRIMITIVE_TOPOLOGY_TRIANGLE_LIST;

    auto rasterState = vsg::RasterizationState::create();
    rasterState->cullMode = VK_CULL_MODE_NONE;

    auto multisampleState = vsg::MultisampleState::create();

    // No depth test for the post-process quad.
    auto depthStencilState = vsg::DepthStencilState::create();
    depthStencilState->depthTestEnable = VK_FALSE;
    depthStencilState->depthWriteEnable = VK_FALSE;

    auto colorBlendState = vsg::ColorBlendState::create();
    VkPipelineColorBlendAttachmentState blendAttachment{};
    blendAttachment.blendEnable = VK_FALSE;
    blendAttachment.colorWriteMask = VK_COLOR_COMPONENT_R_BIT | VK_COLOR_COMPONENT_G_BIT |
                                     VK_COLOR_COMPONENT_B_BIT | VK_COLOR_COMPONENT_A_BIT;
    colorBlendState->attachments = {blendAttachment};

    vsg::GraphicsPipelineStates pipelineStates{
        vertexInputState,
        inputAssemblyState,
        rasterState,
        multisampleState,
        colorBlendState,
        depthStencilState,
    };

    auto graphicsPipeline = vsg::GraphicsPipeline::create(
        pipelineLayout,
        vsg::ShaderStages{vertShader, fragShader},
        pipelineStates);

    auto bindGraphicsPipeline = vsg::BindGraphicsPipeline::create(graphicsPipeline);

    // --- Scene color sampler + descriptor set --------------------------------
    auto sampler = vsg::Sampler::create();
    sampler->magFilter = VK_FILTER_NEAREST;
    sampler->minFilter = VK_FILTER_NEAREST;
    sampler->mipmapMode = VK_SAMPLER_MIPMAP_MODE_NEAREST;
    sampler->addressModeU = VK_SAMPLER_ADDRESS_MODE_CLAMP_TO_EDGE;
    sampler->addressModeV = VK_SAMPLER_ADDRESS_MODE_CLAMP_TO_EDGE;
    sampler->addressModeW = VK_SAMPLER_ADDRESS_MODE_CLAMP_TO_EDGE;

    auto imageInfo = vsg::ImageInfo::create(
        sampler,
        depthImageView,  // Actually the COLOR image view (parameter name is legacy)
        VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL);

    auto descriptorImage = vsg::DescriptorImage::create(
        imageInfo, 0, 0, VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER);

    auto descriptorSet = vsg::DescriptorSet::create(
        descriptorSetLayout, vsg::Descriptors{descriptorImage});

    auto bindDescriptorSet = vsg::BindDescriptorSet::create(
        VK_PIPELINE_BIND_POINT_GRAPHICS, pipelineLayout, 0, descriptorSet);

    // --- Draw command (3 vertices, no vertex buffer) -----------------------
    auto draw = vsg::Draw::create(3, 1, 0, 0);

    // --- Assemble the state group ------------------------------------------
    auto stateGroup = vsg::StateGroup::create();
    stateGroup->stateCommands.push_back(bindGraphicsPipeline);
    stateGroup->stateCommands.push_back(bindDescriptorSet);
    stateGroup->addChild(draw);

    EASIR_TRACE("createEdgeDetectionPass: scene subgraph created");
    return stateGroup;
}

} // namespace easir
