%% easir_example_legacy.m
% Legacy fallback using loadlibrary/calllib for MATLAB versions that do not
% support clib().  Prefer easir_example.m (clib-based) on R2022b+.
%
% Before running this script:
%   1. Build the 'easir' shared library target with CMake.
%   2. Ensure the DLL/SO is on the MATLAB library path.

%% --- 1. Load the library ---
if ispc
    lib_path = fullfile('..', 'build', 'bin', 'easir.dll');
else
    lib_path = fullfile('..', 'build', 'lib', 'libeasir.so');
end

if ~libisloaded('easir')
    loadlibrary(lib_path, fullfile('..', 'include', 'easir', 'easir_api.h'));
    disp('EASIR library loaded.');
end

%% --- 2. Inspect default config and state ---
default_cfg_json   = calllib('easir', 'easir_get_default_config');
default_state_json = calllib('easir', 'easir_get_default_state');

cfg   = jsondecode(char(default_cfg_json));
state = jsondecode(char(default_state_json));

disp('=== Default EasirConfig ===');
disp(cfg);
disp('=== Default EasirState ===');
disp(state);

calllib('easir', 'easir_free_string', default_cfg_json);
calllib('easir', 'easir_free_string', default_state_json);

%% --- 3. Modify config to point at the test asset ---
cfg.scene_objects(1).asset_path = '../assets/test_geometry.glb';
cfg.camera.width  = 1280;
cfg.camera.height = 720;

%% --- 4. Create renderer ---
config_json_str = jsonencode(cfg);
handle = calllib('easir', 'easir_create', config_json_str);

if isempty(handle) || handle == 0
    err = calllib('easir', 'easir_get_last_error');
    error('easir_create failed: %s', char(err));
end
disp('Renderer created successfully.');

%% --- 5. Set initial state ---
state.scene_objects(1).id       = 'spacecraft_01';
state.scene_objects(1).position = [0, 0, 0];
state.scene_objects(1).orientation = [0, 0, 0, 1];
state.scene_objects(1).velocity = [0, 0, 0];
state.camera_position           = [0, 0, 20];
state.sun_direction             = [0.7071, 0.7071, 0];

state_json_str = jsonencode(state);
ret = calllib('easir', 'easir_set_state', handle, state_json_str);
if ret ~= 0
    warning('easir_set_state returned %d', ret);
end

%% --- 6. Render one frame ---
ret = calllib('easir', 'easir_render', handle);
if ret ~= 0
    warning('easir_render returned %d', ret);
end
disp('Frame rendered.');

%% --- 7. Retrieve and display the image ---
data_ptr = libpointer('uint8Ptr');
w_ptr    = libpointer('int32Ptr', 0);
h_ptr    = libpointer('int32Ptr', 0);
ch_ptr   = libpointer('int32Ptr', 0);

ret = calllib('easir', 'easir_get_image', handle, data_ptr, w_ptr, h_ptr, ch_ptr);

if ret == 0
    img_w  = w_ptr.Value;
    img_h  = h_ptr.Value;
    img_ch = ch_ptr.Value;

    setdatatype(data_ptr, 'uint8Ptr', 1, img_w * img_h * img_ch);
    raw = data_ptr.Value;

    img = reshape(raw, [img_ch, img_w, img_h]);
    img = permute(img, [3, 2, 1]);

    figure('Name', 'EASIR Render');
    imshow(img);
    title(sprintf('EASIR render — %d x %d px, %d ch', img_w, img_h, img_ch));
    drawnow;
    disp('Image displayed.');
else
    disp('No image available (renderer may need a full Vulkan setup).');
end

%% --- 8. Retrieve current config and state back as JSON ---
live_cfg_json   = calllib('easir', 'easir_get_config', handle);
live_state_json = calllib('easir', 'easir_get_state',  handle);

disp('Live config (first 200 chars):');
disp(char(live_cfg_json(1:min(200, length(live_cfg_json)))));

calllib('easir', 'easir_free_string', live_cfg_json);
calllib('easir', 'easir_free_string', live_state_json);

%% --- 9. Save config and state to JSON files ---
fid = fopen('easir_config_snapshot.json', 'w');
fprintf(fid, '%s', jsonencode(cfg, 'PrettyPrint', true));
fclose(fid);

fid = fopen('easir_state_snapshot.json', 'w');
fprintf(fid, '%s', jsonencode(state, 'PrettyPrint', true));
fclose(fid);

disp('Config and state saved to easir_config_snapshot.json / easir_state_snapshot.json');

%% --- 10. Cleanup ---
calllib('easir', 'easir_destroy', handle);
unloadlibrary('easir');
disp('Renderer destroyed. Library unloaded.');
