%% easir_example2.m
% Minimal articulation demo: drive every joint in an authored scene with a
% sine sweep relative to its rest pose, and write animated PNG frames.
%
% Editor side (once, to prepare the scene):
%   1. Open easir_app with a config that loads your top-level spacecraft.
%   2. Click + Add Part → pick a child mesh → tweak position/pivot → Confirm.
%   3. Repeat for every child joint you want.
%   4. Click Save in the main editor. Close.
%
% MATLAB side (this script):
%   - r      = Easir(cfg)                                                     create the headless renderer
%   - joints = r.joints()                                                     struct array: (top, name, home pose) per joint
%   - q      = Easir.compose_joint_delta(joints(j).orientation, axis, deg)    rotate relative to rest, no snap
%   - st     = Easir.set_joint(st, joints(j), 'orientation', q)               write the override into state
%   - r.set_state(st); r.render(); img = r.get_image();
%
% Conventions:
%   - Quaternions are unit, [x y z w] order.
%   - Joint names are namespaced PER spacecraft — two spacecraft may legally
%     share a joint name. Discovery and lookup always return/require the
%     owning top-level scene_object id.
%   - Missing position/orientation on a joint override falls back to the
%     authored home pose from the editor.

%% --- Setup ---
ENABLE_TRACE = false;

repo_root   = fullfile(fileparts(mfilename('fullpath')), '..');
config_path = fullfile(repo_root, 'configs', 'default_config.json');
state_path  = fullfile(repo_root, 'configs', 'default_state.json');
out_dir     = fullfile(repo_root, 'easir_matlab_frames');
if ~exist(out_dir, 'dir'); mkdir(out_dir); end

NUM_FRAMES = 120;
FPS        = 30.0;

if ENABLE_TRACE
    Easir.enable_trace();
end

%% --- Create renderer ---
cfg = Easir.load_config(config_path);
cfg.data_root     = strrep(repo_root, '\', '/');
cfg.camera.width  = 1280;
cfg.camera.height = 720;
if isfield(cfg, 'global') && isfield(cfg.global, 'editor_mode')
    cfg.global.editor_mode = false;
end

r = Easir(cfg);
fprintf('Renderer created.\n');

%% --- Base state ---
st = Easir.load_state(state_path);
st.camera_position    = [0; 0; 15];
st.camera_orientation = [0; 0; 0; 1];
st.sun_direction      = [0.7071; 0.7071; 0];

if isempty(st.scene_objects)
    error('easir_example2:no_scene_objects', ...
          'default_state.json has no scene_objects — cannot drive joints.');
end

%% --- Discover joints ---
% r.joints() returns a struct array with one entry per joint, each
% carrying the owning top-level asset id, the joint name, and the
% authored home pose (position, orientation quat, pivot offset).
% Everything the frame loop needs comes from this one call.
joints = r.joints();
if isempty(joints)
    warning('easir_example2:noJoints', ...
        ['No joints found. Author a child via the editor (Add Part, Save), ' ...
         'then re-run.']);
end

fprintf('Discovered %d joint(s):\n', numel(joints));
for j = 1:numel(joints)
    fprintf('  %s / %s  home pos=[%.2f %.2f %.2f]  quat=[%.3f %.3f %.3f %.3f]\n', ...
        joints(j).top_level_asset_id, joints(j).name, ...
        joints(j).position, joints(j).orientation);
end

%% --- Frame loop ---
% Each frame, sweep every discovered joint with a sine wave around its
% local Z axis relative to authored home. Delta=0 reproduces home
% exactly — no snap on the first frame.
%
% To customise per joint, branch on joints(j).name / .top_level_asset_id:
%     if strcmp(joints(j).name, 'panel_left_hinge')
%         axis = [0 1 0]; amp_deg = 30;
%     end
%
% To drive POSITION alongside (or instead of) orientation:
%     new_pos = joints(j).position + [dx dy dz];
%     st = Easir.set_joint(st, joints(j), 'position', new_pos, ...
%                                          'orientation', q);
% Missing fields fall back to home.
fprintf('Rendering %d frames...\n', NUM_FRAMES);
for k = 0:(NUM_FRAMES - 1)
    t = k / FPS;

    % Sine sweep parameters shared by every joint in this simple demo.
    axis      = [0 0 1];
    amp_deg   = 60.0;
    angle_deg = amp_deg * sin(2 * pi * 0.5 * t);

    % Drive every discovered joint. set_joint overwrites the 'orientation'
    % field in place, so writing the same joint every frame is safe. If
    % your loop conditionally skips joints or sets position on some
    % frames only, reset the joints map each frame with:
    %   st.scene_objects{i}.joints = struct();
    for j = 1:numel(joints)
        q  = Easir.compose_joint_delta(joints(j).orientation, axis, angle_deg);
        st = Easir.set_joint(st, joints(j), 'orientation', q);
    end

    r.set_state(st);
    r.render();

    img = r.get_image();
    imwrite(img(:, :, 1:3), ...
        fullfile(out_dir, sprintf('frame_%04d.png', k)));

    if mod(k, 10) == 0
        fprintf('  frame %3d / %d  (t=%.2fs, angle=%.1f deg)\n', ...
            k, NUM_FRAMES, t, angle_deg);
    end
end

fprintf('Wrote %d frames to %s\n', NUM_FRAMES, out_dir);

%% --- Cleanup ---
clear r;
unloadlibrary('easir');
fprintf('Done.\n');
