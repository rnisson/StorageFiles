classdef Easir < handle
    %EASIR  MATLAB wrapper for the EASIR headless renderer DLL.
    %
    %   r = Easir(config_json)   Create a renderer with the given config.
    %   r = Easir()              Create a renderer with default config.
    %
    %   r.set_state(state_json)  Update dynamic state (camera, objects, …).
    %   r.render()               Render one frame.
    %   img = r.get_image()      Retrieve the rendered image as [H,W,4] uint8.
    %   cfg = r.get_config()     Get the live config as a MATLAB struct.
    %   st  = r.get_state()      Get the live state as a MATLAB struct.
    %
    %   clear r                  Destroy the renderer and release GPU resources.
    %
    %   Static helpers (no renderer needed):
    %   cfg = Easir.default_config()   Default EasirConfig as a struct.
    %   st  = Easir.default_state()    Default EasirState as a struct.
    %   err = Easir.last_error()       Last error message from the DLL.
    %
    %   Example:
    %     cfg = Easir.default_config();
    %     cfg.camera.width  = 1280;
    %     cfg.camera.height = 720;
    %     r = Easir(jsonencode(cfg));
    %     r.render();
    %     img = r.get_image();
    %     imshow(img(:,:,1:3));
    %     clear r;

    properties (Access = private)
        Handle uint64 = 0
    end

    properties (Constant, Access = private)
        LibName = 'easir'
    end

    % ---------------------------------------------------------------
    %  Construction / destruction
    % ---------------------------------------------------------------
    methods
        function obj = Easir(config)
            %EASIR  Create a headless renderer instance.
            %   r = Easir(cfg_struct)   — config as a MATLAB struct (preferred)
            %   r = Easir(config_json)  — config as a JSON string (legacy)
            %   r = Easir()             — use all defaults
            %
            %   Struct input is the idiomatic path — use Easir.load_config()
            %   or Easir.default_config() to get a struct, mutate it in place,
            %   then pass it here. jsonencode / num2cell plumbing is handled
            %   internally.
            Easir.ensure_loaded();

            if nargin < 1 || isempty(config)
                json = '{}';
            elseif ischar(config) || isstring(config)
                json = char(config);
            else
                json = Easir.struct_to_json(config);
            end

            h = calllib(Easir.LibName, 'easir_create', json);
            if h == 0
                error('Easir:createFailed', 'easir_create failed: %s', ...
                    Easir.last_error());
            end
            obj.Handle = h;
        end

        function delete(obj)
            if obj.Handle ~= 0
                calllib(Easir.LibName, 'easir_destroy', obj.Handle);
                obj.Handle = 0;
            end
        end
    end

    % ---------------------------------------------------------------
    %  Instance methods
    % ---------------------------------------------------------------
    methods
        function set_state(obj, state)
            %SET_STATE  Update dynamic state for the next render call.
            %   r.set_state(st_struct)   — state as a MATLAB struct (preferred)
            %   r.set_state(state_json)  — state as a JSON string (legacy)
            %
            %   The struct path handles num2cell / jsonencode internally so
            %   you can mutate st.scene_objects{i}.joints.(name).orientation
            %   in the frame loop without worrying about encoding quirks.
            obj.check_handle();
            if ischar(state) || isstring(state)
                json = char(state);
            else
                json = Easir.struct_to_json(state);
            end
            rc = calllib(Easir.LibName, 'easir_set_state', ...
                obj.Handle, json);
            if rc ~= 0
                error('Easir:setStateFailed', 'easir_set_state failed: %s', ...
                    Easir.last_error());
            end
        end

        function rc = render(obj)
            %RENDER  Execute one render frame.  Returns 0 on success.
            obj.check_handle();
            rc = calllib(Easir.LibName, 'easir_render', obj.Handle);
        end

        function [w, h, ch] = get_image_info(obj)
            %GET_IMAGE_INFO  Query dimensions of the last rendered image.
            obj.check_handle();
            wp = libpointer('int32Ptr', 0);
            hp = libpointer('int32Ptr', 0);
            cp = libpointer('int32Ptr', 0);
            rc = calllib(Easir.LibName, 'easir_get_image_info', ...
                obj.Handle, wp, hp, cp);
            if rc ~= 0
                error('Easir:noImage', 'No rendered image available: %s', ...
                    Easir.last_error());
            end
            w  = wp.Value;
            h  = hp.Value;
            ch = cp.Value;
        end

        function img = get_image(obj)
            %GET_IMAGE  Retrieve the rendered image as [H, W, 4] uint8 RGBA.
            [w, h, ch] = obj.get_image_info();
            n = w * h * ch;
            bufptr = libpointer('uint8Ptr', zeros(n, 1, 'uint8'));
            rc = calllib(Easir.LibName, 'easir_get_image', ...
                obj.Handle, bufptr, int32(n));
            if rc ~= 0
                error('Easir:getImageFailed', 'easir_get_image failed: %s', ...
                    Easir.last_error());
            end
            buf = bufptr.Value;
            img = permute(reshape(buf, [ch, w, h]), [3, 2, 1]);
        end

        function cfg = get_config(obj)
            %GET_CONFIG  Return the live config as a MATLAB struct.
            obj.check_handle();
            s = calllib(Easir.LibName, 'easir_get_config', obj.Handle);
            cfg = jsondecode(s);
        end

        function st = get_state(obj)
            %GET_STATE  Return the live state as a MATLAB struct.
            obj.check_handle();
            s = calllib(Easir.LibName, 'easir_get_state', obj.Handle);
            st = jsondecode(s);
        end

        function tree = joint_names(obj)
            %JOINT_NAMES  Discover all registered joints, grouped by owner.
            %
            %   tree = r.joint_names() returns a struct whose fields are
            %   top-level scene_object ids (e.g. 'spacecraft_01') and whose
            %   values are cell arrays of joint names owned by that
            %   spacecraft.
            %
            %   Returns an empty struct if the scene has no joints.
            %
            %   Phase L: joints are namespaced per spacecraft, so two
            %   spacecraft may legally own joints with the same local name.
            %   Use joint_names_flat() if you'd rather iterate a flat list.
            %
            %   Example:
            %     tree = r.joint_names();
            %     for owner = fieldnames(tree)'
            %         for j = tree.(owner{1})'
            %             fprintf('%s / %s\n', owner{1}, j{1});
            %         end
            %     end
            obj.check_handle();
            s = calllib(Easir.LibName, 'easir_get_joint_names', obj.Handle);
            if isempty(s) || strcmp(s, '{}')
                tree = struct();
                return;
            end
            decoded = jsondecode(s);
            if ~isstruct(decoded)
                tree = struct();
                return;
            end
            % jsondecode collapses single-element JSON arrays into char
            % vectors; normalise every field to a cell array of strings.
            tree = struct();
            fns = fieldnames(decoded);
            for k = 1:numel(fns)
                v = decoded.(fns{k});
                if ischar(v)
                    tree.(fns{k}) = {v};
                elseif iscell(v)
                    tree.(fns{k}) = v;
                else
                    tree.(fns{k}) = cellstr(v);
                end
            end
        end

        function pairs = joint_names_flat(obj)
            %JOINT_NAMES_FLAT  Flat (top, name) pairs for easy iteration.
            %
            %   pairs = r.joint_names_flat() returns an N-by-2 cell array:
            %     pairs{i, 1} = top-level scene_object id
            %     pairs{i, 2} = joint name
            %
            %   Empty {} on scenes with no joints. Convenience wrapper
            %   over joint_names() for callers that want a flat list.
            %   See joints() for the full (top, name, home) bundle.
            tree = obj.joint_names();
            fns = fieldnames(tree);
            rows = {};
            for k = 1:numel(fns)
                names = tree.(fns{k});
                for i = 1:numel(names)
                    rows(end+1, :) = {fns{k}, names{i}}; %#ok<AGROW>
                end
            end
            pairs = rows;
        end

        function all = joints(obj)
            %JOINTS  One-shot discovery: every joint with its authored home pose.
            %
            %   all = r.joints() returns a struct array — one entry per
            %   registered joint across every spacecraft in the scene.
            %   Each entry has fields:
            %     .top_level_asset_id  (char)  owning scene_object id
            %     .name                (char)  joint name within that tree
            %     .position            [x y z]       authored home position
            %     .orientation         [x y z w]     authored home quaternion
            %     .pivot_offset        [x y z]       rotation pivot in body frame
            %
            %   Returns an empty struct array on scenes with no joints.
            %
            %   This is the canonical "give me everything I need to drive
            %   the scene" call — combines joint_names_flat() + joint_home()
            %   into one struct array so the caller can iterate directly:
            %
            %     all = r.joints();
            %     for j = 1:numel(all)
            %         q = Easir.compose_joint_delta(all(j).orientation, [0 0 1], 45);
            %         st = Easir.set_joint(st, all(j), 'orientation', q);
            %     end
            pairs = obj.joint_names_flat();
            if isempty(pairs)
                all = struct('top_level_asset_id', {}, 'name', {}, ...
                             'position', {}, 'orientation', {}, ...
                             'pivot_offset', {});
                return;
            end
            n = size(pairs, 1);
            all = repmat(struct( ...
                'top_level_asset_id', '', 'name', '', ...
                'position', [0 0 0], 'orientation', [0 0 0 1], ...
                'pivot_offset', [0 0 0]), n, 1);
            for j = 1:n
                top  = pairs{j, 1};
                name = pairs{j, 2};
                h    = obj.joint_home(top, name);
                all(j).top_level_asset_id = top;
                all(j).name               = name;
                if isfield(h, 'position'),     all(j).position    = h.position(:)';    end
                if isfield(h, 'orientation'),  all(j).orientation = h.orientation(:)'; end
                if isfield(h, 'pivot_offset'), all(j).pivot_offset = h.pivot_offset(:)'; end
            end
        end

        function home = joint_home(obj, top_level_asset_id, joint_name)
            %JOINT_HOME  Return the authored home pose of a named joint.
            %
            %   home = r.joint_home(top_id, joint_name)
            %
            %   Returns a struct with fields:
            %     .top_level_asset_id  (char)
            %     .position            [x y z]        (metres)
            %     .orientation         [x y z w]      (unit quaternion)
            %     .pivot_offset        [x y z]        (metres, body frame)
            %
            %   Phase L: both arguments are required because joints are
            %   namespaced per spacecraft. Use joint_names() to discover
            %   which (top, name) pairs exist in the loaded scene.
            %
            %   Returns an empty struct if the (top, joint) pair is unknown.
            %
            %   Use this with Easir.compose_joint_delta() to drive a joint
            %   relative to its authored rest pose without snap.
            obj.check_handle();
            s = calllib(Easir.LibName, 'easir_get_joint_home', ...
                obj.Handle, top_level_asset_id, joint_name);
            if isempty(s)
                home = struct();
                return;
            end
            home = jsondecode(s);
            if isempty(fieldnames(home))
                warning('Easir:unknownJoint', ...
                    'joint_home: no binding for top=''%s'' joint=''%s''', ...
                    top_level_asset_id, joint_name);
            end
        end
    end

    % ---------------------------------------------------------------
    %  Static helpers
    % ---------------------------------------------------------------
    methods (Static)
        function cfg = default_config()
            %DEFAULT_CONFIG  Return the default EasirConfig as a struct.
            %   scene_objects is normalised to a cell array so subsequent
            %   indexing is `cfg.scene_objects{i}.field` consistently.
            Easir.ensure_loaded();
            s = calllib(Easir.LibName, 'easir_get_default_config');
            cfg = Easir.normalize_loaded(jsondecode(s));
        end

        function st = default_state()
            %DEFAULT_STATE  Return the default EasirState as a struct.
            %   scene_objects is normalised to a cell array (see default_config).
            Easir.ensure_loaded();
            s = calllib(Easir.LibName, 'easir_get_default_state');
            st = Easir.normalize_loaded(jsondecode(s));
        end

        function cfg = load_config(path)
            %LOAD_CONFIG  Read a config JSON file into a MATLAB struct.
            %
            %   cfg = Easir.load_config('configs/default_config.json')
            %
            %   Returns a MATLAB struct ready to mutate and pass to Easir()
            %   or save_config(). scene_objects is normalised to a cell
            %   array so length-1 arrays round-trip correctly — this fixes
            %   MATLAB's jsondecode/jsonencode trap where a single-element
            %   JSON array decodes as a scalar struct and re-encodes wrong.
            if ~isfile(path)
                error('Easir:loadConfigMissing', ...
                    'load_config: file not found: %s', path);
            end
            cfg = Easir.normalize_loaded(jsondecode(fileread(path)));
        end

        function st = load_state(path)
            %LOAD_STATE  Read a state JSON file into a MATLAB struct.
            %
            %   st = Easir.load_state('configs/default_state.json')
            %
            %   Returns a struct ready to mutate and pass to set_state()
            %   or save_state(). scene_objects is normalised to a cell
            %   array (see load_config for rationale).
            if ~isfile(path)
                error('Easir:loadStateMissing', ...
                    'load_state: file not found: %s', path);
            end
            st = Easir.normalize_loaded(jsondecode(fileread(path)));
        end

        function save_config(cfg, path)
            %SAVE_CONFIG  Serialize a config struct to a JSON file.
            %
            %   Easir.save_config(cfg, 'configs/my_config.json')
            %
            %   Handles num2cell / jsonencode plumbing internally. Pretty-prints
            %   the output for human diffing.
            json = Easir.struct_to_json(cfg);
            Easir.write_pretty_json(json, path);
        end

        function save_state(st, path)
            %SAVE_STATE  Serialize a state struct to a JSON file.
            %
            %   Easir.save_state(st, 'configs/my_state.json')
            %
            %   Handles num2cell / jsonencode plumbing internally. Pretty-prints.
            json = Easir.struct_to_json(st);
            Easir.write_pretty_json(json, path);
        end

        function msg = last_error()
            %LAST_ERROR  Return the last error message from the DLL.
            Easir.ensure_loaded();
            msg = calllib(Easir.LibName, 'easir_get_last_error');
        end

        function enable_trace()
            %ENABLE_TRACE  Enable verbose DLL-side trace logging.
            %   Must be called BEFORE creating a renderer instance.
            %   Opens a console window and writes to easir_trace.log.
            Easir.ensure_loaded();
            calllib(Easir.LibName, 'easir_enable_trace');
        end

        function q_out = compose_joint_delta(home_quat, axis, angle_deg)
            %COMPOSE_JOINT_DELTA  Apply a local-frame delta rotation to a home quat.
            %
            %   q_out = Easir.compose_joint_delta(home_quat, axis, angle_deg)
            %
            %   Inputs:
            %     home_quat  [x y z w]  authored home orientation (see joint_home)
            %     axis       [x y z]    rotation axis in the joint's rest frame
            %     angle_deg  scalar     angle in degrees
            %
            %   Output:
            %     q_out      [x y z w]  absolute joint orientation to write into
            %                           state.scene_objects(i).joints.<name>.orientation
            %
            %   Composition convention: q_out = q_home * q_delta  (Hamilton product)
            %   where q_delta is axis-angle in the joint's rest frame. This means
            %   angle_deg = 0 reproduces the authored home exactly (no snap).
            %
            %   Example:
            %     home  = r.joint_home('sat_a');
            %     q_new = Easir.compose_joint_delta(home.orientation, [0 0 1], 45);
            %     st.scene_objects{1}.joints.sat_a.orientation = q_new;
            a = double(angle_deg) * pi / 180.0;
            s = sin(a * 0.5);
            c = cos(a * 0.5);
            axis = double(axis(:))';
            n = norm(axis);
            if n < eps
                axis = [0 0 1];
            else
                axis = axis / n;
            end
            q_delta = [axis(1)*s, axis(2)*s, axis(3)*s, c];

            h = double(home_quat(:))';
            if numel(h) ~= 4
                error('Easir:compose', 'home_quat must be a 4-element [x y z w] vector');
            end
            % Hamilton product: q_out = h * q_delta, with [x y z w] storage.
            hw = h(4); hx = h(1); hy = h(2); hz = h(3);
            dw = q_delta(4); dx = q_delta(1); dy = q_delta(2); dz = q_delta(3);
            q_out = [ ...
                hw*dx + hx*dw + hy*dz - hz*dy, ...
                hw*dy - hx*dz + hy*dw + hz*dx, ...
                hw*dz + hx*dy - hy*dx + hz*dw, ...
                hw*dw - hx*dx - hy*dy - hz*dz ];
        end

        function idx = scene_object_index(st, id)
            %SCENE_OBJECT_INDEX  Return the index of the scene_object with a
            %given id, or [] if not found.
            %
            %   idx = Easir.scene_object_index(st, 'spacecraft_01')
            %
            %   Convenience for callers who need to write into
            %   st.scene_objects{idx} without writing the strcmp loop
            %   themselves. Returns empty [] on miss so callers can
            %   `if isempty(idx); ... end`.
            idx = [];
            if ~isfield(st, 'scene_objects') || isempty(st.scene_objects)
                return;
            end
            for i = 1:numel(st.scene_objects)
                if strcmp(st.scene_objects{i}.id, id)
                    idx = i;
                    return;
                end
            end
        end

        function st = set_joint(st, joint_or_top, varargin)
            %SET_JOINT  Write a joint override into a state struct.
            %
            %   st = Easir.set_joint(st, joint_struct, 'orientation', q, ...)
            %   st = Easir.set_joint(st, top_id, joint_name, 'orientation', q, ...)
            %
            %   Takes either a joint entry from r.joints() OR an explicit
            %   (top_id, joint_name) pair as the locator, followed by any
            %   number of 'orientation' / 'position' name-value pairs.
            %   Returns the mutated state.
            %
            %   Merges with any existing override on the same joint — so
            %   calling set_joint(st, j, 'position', p) then
            %   set_joint(st, j, 'orientation', q) ends up writing both.
            %
            %   Warns once per unknown (top, joint) pair and leaves the
            %   state unchanged — matches the DLL's tolerant behaviour so
            %   a driver with a stale joint name doesn't crash a render.
            %
            %   Example:
            %     all = r.joints();
            %     q   = Easir.compose_joint_delta(all(1).orientation, [0 0 1], 45);
            %     st  = Easir.set_joint(st, all(1), 'orientation', q);

            % Resolve locator form.
            if isstruct(joint_or_top)
                top  = joint_or_top.top_level_asset_id;
                name = joint_or_top.name;
                args = varargin;
            elseif ischar(joint_or_top) || isstring(joint_or_top)
                if numel(varargin) < 1
                    error('Easir:setJointUsage', ...
                        'set_joint: joint name must follow the top-id string');
                end
                top  = char(joint_or_top);
                name = char(varargin{1});
                args = varargin(2:end);
            else
                error('Easir:setJointUsage', ...
                    'set_joint: first arg must be a joint struct or top-id string');
            end

            % Locate the matching scene_object.
            idx = Easir.scene_object_index(st, top);
            if isempty(idx)
                persistent warnedMissing;
                if isempty(warnedMissing); warnedMissing = containers.Map(); end
                key = [top '|' name];
                if ~isKey(warnedMissing, key)
                    warnedMissing(key) = true;
                    warning('Easir:setJointUnknownTop', ...
                        'set_joint: no scene_object ''%s'' in state (one-time; joint=''%s'')', ...
                        top, name);
                end
                return;
            end

            % Parse name-value pairs.
            if mod(numel(args), 2) ~= 0
                error('Easir:setJointUsage', ...
                    'set_joint: name-value arguments must come in pairs');
            end

            % Ensure a joints struct exists on this scene_object.
            if ~isfield(st.scene_objects{idx}, 'joints') || ...
               ~isstruct(st.scene_objects{idx}.joints)
                st.scene_objects{idx}.joints = struct();
            end

            % Merge with any existing override on this same joint.
            if isfield(st.scene_objects{idx}.joints, name)
                js = st.scene_objects{idx}.joints.(name);
            else
                js = struct();
            end

            for p = 1:2:numel(args)
                k = lower(char(args{p}));
                v = args{p+1};
                switch k
                    case 'orientation'
                        js.orientation = v(:)';  % normalise to row
                    case 'position'
                        js.position = v(:)';
                    otherwise
                        error('Easir:setJointUsage', ...
                            'set_joint: unknown key ''%s'' (expected ''orientation'' or ''position'')', k);
                end
            end

            st.scene_objects{idx}.joints.(name) = js;
        end
    end

    % ---------------------------------------------------------------
    %  Private helpers
    % ---------------------------------------------------------------
    methods (Access = private)
        function check_handle(obj)
            if obj.Handle == 0
                error('Easir:invalidHandle', 'Renderer has been destroyed.');
            end
        end
    end

    methods (Static, Access = private)
        function ensure_loaded()
            %ENSURE_LOADED  Load the DLL if not already loaded.
            if libisloaded(Easir.LibName)
                return
            end

            this_dir  = fileparts(mfilename('fullpath'));
            repo_root = fullfile(this_dir, '..');

            dll_dir     = fullfile(repo_root, 'build_vs', 'bin', 'Release');
            header_path = fullfile(repo_root, 'include', 'easir', 'easir_api.h');

            % Put the DLL directory on PATH so MATLAB can find easir.dll
            % and any Vulkan runtime dependencies.
            if ~contains(getenv('PATH'), dll_dir)
                setenv('PATH', [dll_dir ';' getenv('PATH')]);
            end

            if ~isfile(fullfile(dll_dir, 'easir.dll'))
                error('Easir:dllNotFound', ...
                    ['easir.dll not found in:\n  %s\n' ...
                     'Build it first:\n' ...
                     '  cmake --build build_vs --config Release --target easir'], ...
                    dll_dir);
            end

            [~, warnings] = loadlibrary(Easir.LibName, header_path);
            % Filter out known-harmless Windows SDK header-parsing noise.
            if ~isempty(warnings)
                dominated_by_sdk = contains(warnings, ...
                    {'__crt_locale_data', '__crt_multibyte_data', ...
                     'corecrt.h', 'Unescaped left brace'});
                unexpected = warnings(~dominated_by_sdk);
                if ~isempty(unexpected)
                    warning('Easir:loadWarnings', ...
                        'Unexpected loadlibrary warnings:\n%s', ...
                        strjoin(unexpected, '\n'));
                end
            end
        end

        function out = normalize_loaded(s)
            %NORMALIZE_LOADED  Post-process a jsondecode result so callers can
            %index scene_objects uniformly as a cell array regardless of how
            %many entries the JSON had. Single-element arrays decode to scalar
            %structs; we promote them to 1-element cells so the round-trip
            %through jsonencode produces a JSON array and example code can
            %always use `cfg.scene_objects{i}` syntax.
            out = s;
            if isfield(out, 'scene_objects')
                v = out.scene_objects;
                if isstruct(v)
                    out.scene_objects = num2cell(v);
                elseif ~iscell(v)
                    % Unexpected type — leave as-is and let the DLL error out.
                end
            end
        end

        function json = struct_to_json(s)
            %STRUCT_TO_JSON  Serialise a config/state struct to JSON, applying
            %the single-element-array fixup so the DLL sees the schema shape
            %it expects. See feedback_matlab_json_quirks memory for rationale.
            %
            %Today the only top-level field that needs the num2cell wrap is
            %`scene_objects`. If future schema additions introduce new
            %top-level arrays, extend this list explicitly — don't try to
            %detect generically (scalar structs for "object" fields like
            %`camera` are indistinguishable from length-1 array decodes).
            if isfield(s, 'scene_objects') && isstruct(s.scene_objects)
                s.scene_objects = num2cell(s.scene_objects);
            end
            json = jsonencode(s);
        end

        function write_pretty_json(json, path)
            %WRITE_PRETTY_JSON  Write a JSON string to disk with human-
            %friendly 2-space indentation. jsonencode compacts by default,
            %which makes diffs unreadable — this re-parses via the DLL's
            %default encoder by round-tripping through jsondecode +
            %jsonencode with 'PrettyPrint' (R2021a+). Fallback for older
            %MATLAB: write compact.
            try
                pretty = jsonencode(jsondecode(json), 'PrettyPrint', true);
            catch
                pretty = json;
            end
            fid = fopen(path, 'w');
            if fid == -1
                error('Easir:writeJsonFailed', ...
                    'write_pretty_json: could not open %s for writing', path);
            end
            cleanup = onCleanup(@() fclose(fid));
            fwrite(fid, pretty, 'char');
        end
    end
end
