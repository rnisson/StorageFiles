#pragma once

/**
 * @file editor_handler.h
 * @brief EditorHandler — input handler and ImGui panel for editor mode.
 *
 * Handles:
 *   - Left-click:  select node via ray intersection, highlight with wireframe
 *   - Scroll:      zoom toward cursor (zoom + subtle recentering toward mouse)
 *   - ImGui panel: semantic group management (create/delete/assign/rename/recolor)
 *   - Hover:       highlight all nodes in a group when hovering in the panel
 */

#include "trace.h"
#include "draw_call_split.h"
#include "face_adjacency.h"
#include "math_utils.h"
#include "render_pipeline.h"
#include "semantic_group_manager.h"
#include "semantic_map.h"
#include "semantic_visitor.h"
#include "state.h"
#include "win32_file_picker.h"

#include <vsg/all.h>
#include <vsg/utils/LineSegmentIntersector.h>
#include <vsg/utils/GraphicsPipelineConfigurator.h>

#include <vsgImGui/RenderImGui.h>
#include <vsgImGui/imgui.h>

#include <array>
#include <cmath>
#include <cstdio>
#include <filesystem>
#include <functional>
#include <memory>
#include <optional>
#include <string>
#include <unordered_set>
#include <vector>

namespace easir {

/// Per-node info stored by EditorHandler's NodeDiscoveryVisitor.
/// At namespace scope so AssetContext can reference it.
struct EditorNodeInfo {
    std::vector<vsg::ref_ptr<vsg::Node>> geomChildren;
    vsg::dmat4 worldMatrix;
    std::string fullName;  // full vsgXchange name
};

/// All state the editor tracks for a single loaded asset.
/// The editor can hold many (one per loaded scene_object + articulation child),
/// keyed by assetId, but only one is "active" for editing at a time.
struct AssetContext {
    using MaterialMap = std::unordered_map<std::string, vsg::ref_ptr<vsg::PhongMaterialValue>>;

    std::string assetId;
    std::filesystem::path assetPath;
    vsg::ref_ptr<vsg::MatrixTransform> rootTransform;      // top xform holding this asset's subtree
    vsg::ref_ptr<vsg::Node> rootNode;                       // loaded geometry root (child of rootTransform)
    std::unique_ptr<SemanticGroupManager> groupMgr;
    MaterialMap materialMap;
    MaterialMap originalMaterials;                          // pre-split snapshot (for revert)
    std::unordered_map<std::string, EditorNodeInfo> nodePathMap;
    std::unordered_map<vsg::VertexIndexDraw*, FaceAdjacency> adjacencyCache;
    std::unordered_map<std::string, vsg::ref_ptr<vsg::StateGroup>> splitOriginals;

    // Articulation metadata (empty for root; populated in Phase D+)
    std::string parentAssetId;
    std::string jointName;
    vsg::dvec3  localPosition{0,0,0};
    vsg::dquat  localOrientation{0,0,0,1};
    std::vector<std::string> childAssetIds;
    bool isActive = true;
};

/// A child asset reference that failed to resolve during articulated load.
/// Surfaced to the user via a modal at startup (Phase D: Remove/Cancel only;
/// Phase H wires Locate to the file picker).
struct MissingFileEntry {
    std::filesystem::path expectedPath;     // canonicalized path that did not exist
    std::string parentAssetId;              // owning parent AssetContext id
    std::string jointName;                  // joint name inside the parent's JSON
};

class EditorHandler : public vsg::Inherit<vsg::Visitor, EditorHandler> {
public:
    EditorHandler(vsg::ref_ptr<vsg::Camera> camera,
                  vsg::ref_ptr<vsg::Group> sceneRoot,
                  vsg::ref_ptr<vsg::Trackball> trackball,
                  vsg::ref_ptr<vsg::Viewer> viewer)
        : m_camera(camera)
        , m_sceneRoot(sceneRoot)
        , m_trackball(trackball)
        , m_viewer(viewer)
    {
    }

    /// Material map type alias (forwarded from AssetContext).
    using MaterialMap = AssetContext::MaterialMap;

    // ---------------------------------------------------------------
    //  Legacy single-asset setters (pre-Phase A). Kept as thin shims
    //  so renderer.cpp can still call them during the incremental
    //  refactor. Phase A-final: renderer.cpp calls register_asset()
    //  directly and these shims are removed.
    // ---------------------------------------------------------------

    /// Legacy: store the group manager. Creates a synthetic "default" asset
    /// if no asset is registered yet.
    void set_group_manager(SemanticGroupManager* mgr) {
        // The caller retains ownership of the group manager (renderer.cpp owns
        // it via m_group_manager). Since our AssetContext wants unique_ptr,
        // we instead store the raw pointer via m_groupMgr directly. Subsequent
        // calls to register_asset() supersede this.
        m_groupMgr = mgr;
    }

    /// Legacy: copy the material map into the active editor state.
    void set_material_map(const MaterialMap& map) { m_materialMap = map; }

    /// Legacy: set initial split state.
    void set_initial_split_state(
            const std::unordered_map<std::string, vsg::ref_ptr<vsg::StateGroup>>& originals,
            const MaterialMap& preOriginalMaterials) {
        m_splitOriginals = originals;
        m_originalMaterials = preOriginalMaterials;
    }

    // ---------------------------------------------------------------
    //  Asset context management (multi-asset foundation)
    // ---------------------------------------------------------------

    /// Register a fully-built AssetContext. First registered asset becomes active.
    /// The context is stored in m_assets; if no asset is active yet, this asset
    /// becomes active and its per-asset fields are swapped into the editor member
    /// storage for direct code access. Non-first assets are NOT auto-dimmed here
    /// (their materialMap may still be empty); the caller should call
    /// dim_all_inactive_assets() after all registrations are complete.
    void register_asset(AssetContext&& ctx) {
        const std::string id = ctx.assetId;
        EASIR_LOG("[EASIR] register_asset(id='%s'): path='%s' nodes=%zu materials=%zu custom=%zu\n",
                    id.c_str(), ctx.assetPath.string().c_str(),
                    ctx.nodePathMap.size(), ctx.materialMap.size(),
                    ctx.groupMgr ? ctx.groupMgr->custom_nodes().size() : 0);
        bool makeActive = m_activeAssetId.empty();
        m_assets[id] = std::move(ctx);
        if (makeActive) {
            set_active_asset(id);
        }
        EASIR_LOG("[EASIR] register_asset: total=%zu active='%s'\n",
                    m_assets.size(), m_activeAssetId.c_str());
    }

    /// Walk all non-active assets and apply inactive appearance.
    /// Call this AFTER all assets have been registered and fully populated.
    void dim_all_inactive_assets() {
        for (auto& [id, ctx] : m_assets) {
            if (id == m_activeAssetId) continue;
            apply_inactive_appearance(ctx);
        }
    }

    /// Public wrapper so renderer.cpp setup can switch between assets.
    void switch_to_asset(const std::string& newId) { switch_active_asset(newId); }

    /// Queue missing-file entries to be displayed in a modal the next time
    /// draw_gui() runs. Called once by renderer.cpp after the articulated
    /// load finishes.
    void open_missing_files_popup(std::vector<MissingFileEntry> entries) {
        if (entries.empty()) return;
        EASIR_LOG("[EASIR] open_missing_files_popup: %zu entries queued\n", entries.size());
        m_missingFiles = std::move(entries);
        m_missingFilesOpen = true;
    }

    /// Returns the active AssetContext or nullptr.
    AssetContext* active_asset() {
        if (m_activeAssetId.empty()) return nullptr;
        auto it = m_assets.find(m_activeAssetId);
        return it == m_assets.end() ? nullptr : &it->second;
    }

    /// Look up an asset by id.
    AssetContext* asset_by_id(const std::string& id) {
        auto it = m_assets.find(id);
        return it == m_assets.end() ? nullptr : &it->second;
    }

    bool has_active_asset() const { return !m_activeAssetId.empty(); }

    /// Switch active asset. Swaps the active asset's per-asset fields (materials,
    /// nodePathMap, adjacency, splits) between the EditorHandler's member storage
    /// and the AssetContext in m_assets. This preserves existing call sites that
    /// access m_materialMap, m_nodePathMap, etc. as value members.
    ///
    /// The swap semantics: on switch, we first push the currently-active state
    /// back into its AssetContext, then pull the newly-active state out of its
    /// AssetContext into the member fields.
    void set_active_asset(const std::string& id) {
        auto it = m_assets.find(id);
        if (it == m_assets.end()) {
            EASIR_LOG("[EASIR] set_active_asset('%s'): NOT FOUND\n", id.c_str());
            return;
        }
        if (id == m_activeAssetId) return;  // no-op

        EASIR_LOG("[EASIR] active asset: '%s' -> '%s'\n",
                    m_activeAssetId.c_str(), id.c_str());

        // Push current state back into the formerly-active context (if any).
        if (!m_activeAssetId.empty()) {
            auto prevIt = m_assets.find(m_activeAssetId);
            if (prevIt != m_assets.end()) {
                AssetContext& prev = prevIt->second;
                prev.materialMap      = std::move(m_materialMap);
                prev.originalMaterials= std::move(m_originalMaterials);
                prev.nodePathMap      = std::move(m_nodePathMap);
                prev.adjacencyCache   = std::move(m_adjacencyCache);
                prev.splitOriginals   = std::move(m_splitOriginals);
            }
        }

        // Pull new state out of the newly-active context.
        AssetContext& ctx = it->second;
        m_activeAssetId    = id;
        m_groupMgr         = ctx.groupMgr.get();
        m_materialMap      = std::move(ctx.materialMap);
        m_originalMaterials= std::move(ctx.originalMaterials);
        m_nodePathMap      = std::move(ctx.nodePathMap);
        m_adjacencyCache   = std::move(ctx.adjacencyCache);
        m_splitOriginals   = std::move(ctx.splitOriginals);
    }

    /// Set the edge preview Switch node for toggling between scene and edge view.
    void set_edge_preview_switch(vsg::ref_ptr<vsg::Switch> sw) { m_edgePreviewSwitch = sw; }

    /// Set the sun light reference (for reset light direction feature).
    void set_sun_light(vsg::ref_ptr<vsg::DirectionalLight> light) { m_sunLight = light; }

    /// Phase E test: non-owning pointer to EasirRenderer::m_state so the
    /// debug "Joint Test" panel can write joint overrides each frame.
    void set_test_state_ptr(EasirState* s) { m_testStatePtr = s; }

    /// Phase H: vsg::Options used to read_cast new child assets at runtime.
    void set_vsg_options(vsg::ref_ptr<vsg::Options> opts) { m_vsgOptions = opts; }

    /// Phase H: non-owning pointer to the ForwardPass so the "Add Part" flow
    /// can register newly-authored joints / material maps.
    void set_forward_pass(ForwardPass* fp) { m_forwardPass = fp; }

    /// Build a map of short_name -> nodePath for all named nodes in a subtree.
    /// Default: walks the full m_sceneRoot (legacy single-asset behaviour).
    /// When a subtree is passed, walks only that subtree — used by renderer.cpp
    /// to discover each loaded asset's nodes into its own AssetContext.
    /// Writes results into the currently-active asset's nodePathMap (via the
    /// m_nodePathMap member, which is swap-backed by set_active_asset).
    void discover_nodes(vsg::ref_ptr<vsg::Node> subtreeRoot = {}) {
        vsg::ref_ptr<vsg::Node> root = subtreeRoot ? subtreeRoot : vsg::ref_ptr<vsg::Node>(m_sceneRoot);
        if (!root) return;
        m_nodePathMap.clear();

        // Use a proper VSG visitor to traverse the scene graph — this ensures
        // correct dispatch through all node types (Group, MatrixTransform,
        // StateGroup, Switch, etc.) unlike dynamic_cast which can miss types.
        struct NodeDiscoveryVisitor : public vsg::Visitor {
            std::unordered_map<std::string, NodeInfo>& nodeMap;
            std::vector<vsg::dmat4> matrixStack;

            NodeDiscoveryVisitor(std::unordered_map<std::string, NodeInfo>& m)
                : nodeMap(m) { matrixStack.push_back(vsg::dmat4(1.0)); }

            void apply(vsg::Node& node) override { node.traverse(*this); }

            void apply(vsg::Group& group) override {
                check_and_store(group);
                group.traverse(*this);
            }

            void apply(vsg::MatrixTransform& mt) override {
                matrixStack.push_back(matrixStack.back() * mt.matrix);
                check_and_store(mt);
                mt.traverse(*this);
                matrixStack.pop_back();
            }

            void check_and_store(vsg::Node& node) {
                std::string name;
                if (!node.getValue("name", name) || name.empty()) return;

                std::string shortName = SemanticGroupManager::extract_short_name(name);

                if (nodeMap.find(shortName) != nodeMap.end()) return;

                NodeInfo info;
                info.fullName = name;
                info.worldMatrix = matrixStack.back();

                // Collect the raw geometry nodes (VertexIndexDraw etc.) by digging
                // through StateGroups. This ensures the wireframe highlight's pipeline
                // isn't overridden by the child StateGroup's own pipeline.
                auto* grp = dynamic_cast<vsg::Group*>(&node);
                if (grp) {
                    collect_geometry(grp, info.geomChildren);
                }

                // Only accept nodes that contain actual geometry (filters out
                // container/transform nodes that are just structural parents).
                // Works for both GLB (bracket names) and OBJ (plain group names).
                if (info.geomChildren.empty()) return;

                nodeMap[shortName] = std::move(info);
            }

            // Recursively find geometry leaf nodes (VertexIndexDraw, BindVertexBuffers etc.)
            // by digging through StateGroups and other containers.
            // Stops at child groups that have their own name (those are separate nodes).
            static void collect_geometry(vsg::Group* group,
                                         std::vector<vsg::ref_ptr<vsg::Node>>& out) {
                for (auto& child : group->children) {
                    // If it's a StateGroup, dig into its children for geometry.
                    auto* sg = dynamic_cast<vsg::StateGroup*>(child.get());
                    if (sg) {
                        for (auto& sgChild : sg->children) {
                            out.push_back(sgChild);
                        }
                        continue;
                    }
                    // If it's another Group, recurse — but skip named child groups
                    // (those belong to a different node in the hierarchy).
                    auto* grp = dynamic_cast<vsg::Group*>(child.get());
                    if (grp) {
                        std::string childName;
                        if (child->getValue("name", childName) && !childName.empty()) {
                            continue;  // This is a separate named node.
                        }
                        collect_geometry(grp, out);
                        continue;
                    }
                    // Otherwise it's a leaf geometry node.
                    out.push_back(child);
                }
            }
        };

        // Dump full scene graph hierarchy for diagnostics.
        struct SceneGraphDumper : public vsg::Visitor {
            int depth = 0;
            void apply(vsg::Node& node) override {
                std::string name;
                node.getValue("name", name);
                EASIR_LOG("[EASIR] SCENE %*s%s%s%s\n", depth * 2, "",
                          node.className(),
                          name.empty() ? "" : " name='",
                          name.empty() ? "" : (name + "'").c_str());
                ++depth; node.traverse(*this); --depth;
            }
        };
        SceneGraphDumper dumper;
        root->accept(dumper);

        NodeDiscoveryVisitor visitor(m_nodePathMap);
        root->accept(visitor);

        EASIR_LOG("[EASIR] Discovered %zu named nodes (asset='%s'):\n",
                    m_nodePathMap.size(), m_activeAssetId.c_str());
        for (auto& [name, info] : m_nodePathMap) {
            EASIR_LOG("[EASIR]   '%s' — %zu children\n", name.c_str(), info.geomChildren.size());
        }
    }

    // ---------------------------------------------------------------
    //  Track mouse position (for zoom-toward-cursor)
    // ---------------------------------------------------------------

    void apply(vsg::MoveEvent& move) override {
        m_lastMouseX = move.x;
        m_lastMouseY = move.y;
    }

    // ---------------------------------------------------------------
    //  Keyboard events — track modifier keys
    // ---------------------------------------------------------------

    void apply(vsg::KeyPressEvent& key) override {
        if (key.keyBase == vsg::KEY_Shift_L || key.keyBase == vsg::KEY_Shift_R)
            m_shiftHeld = true;
    }

    void apply(vsg::KeyReleaseEvent& key) override {
        if (key.keyBase == vsg::KEY_Shift_L || key.keyBase == vsg::KEY_Shift_R)
            m_shiftHeld = false;
    }

    // ---------------------------------------------------------------
    //  Mouse button events — detect click vs drag
    // ---------------------------------------------------------------

    void apply(vsg::ButtonPressEvent& press) override {
        if (imgui_wants_mouse()) return;
        if (press.button == 1) {
            m_leftPressX = press.x;
            m_leftPressY = press.y;
            m_leftPressed = true;
        }
    }

    void apply(vsg::ButtonReleaseEvent& release) override {
        if (imgui_wants_mouse()) { m_leftPressed = false; return; }
        if (m_edgePreviewActive) { m_leftPressed = false; return; }  // No selection in edge preview
        if (release.button == 1 && m_leftPressed) {
            m_leftPressed = false;

            int dx = release.x - m_leftPressX;
            int dy = release.y - m_leftPressY;
            if (dx * dx + dy * dy < 25) {
                on_click(release.x, release.y);
            }
        }
    }

    // ---------------------------------------------------------------
    //  Scroll — zoom toward cursor (recentering only when zooming in)
    // ---------------------------------------------------------------

    void apply(vsg::ScrollWheelEvent& scroll) override {
        if (imgui_wants_mouse()) return;
        if (!m_camera || scroll.handled) return;
        scroll.handled = true;

        auto* lookAt = dynamic_cast<vsg::LookAt*>(m_camera->viewMatrix.get());
        if (!lookAt) return;

        bool zoomingIn = scroll.delta.y > 0;
        double zoomFactor = zoomingIn ? 0.9 : 1.1;

        vsg::dvec3 eye_to_center = lookAt->center - lookAt->eye;
        double distance = vsg::length(eye_to_center);
        if (distance < 1e-6) return;

        double newDistance = distance * zoomFactor;
        vsg::dvec3 dir = eye_to_center / distance;
        lookAt->eye = lookAt->center - dir * newDistance;

        if (zoomingIn) {
            auto intersector = vsg::LineSegmentIntersector::create(
                *m_camera, m_lastMouseX, m_lastMouseY);
            m_sceneRoot->accept(*intersector);

            if (!intersector->intersections.empty()) {
                auto& isects = intersector->intersections;
                auto closest = std::min_element(isects.begin(), isects.end(),
                    [](const auto& a, const auto& b) { return a->ratio < b->ratio; });
                vsg::dvec3 targetPoint = (*closest)->worldIntersection;

                double recenterRatio = 0.1;
                vsg::dvec3 shift = (targetPoint - lookAt->center) * recenterRatio;
                lookAt->center = lookAt->center + shift;
                lookAt->eye = lookAt->eye + shift;
            }
        }
    }

    std::string selected_node_name() const { return m_selectedNodeName; }
    bool has_selection() const { return m_hasSelection; }

    /// Returns true if ImGui wants the mouse.
    static bool imgui_wants_mouse() {
        return ImGui::GetCurrentContext() && ImGui::GetIO().WantCaptureMouse;
    }

    // ---------------------------------------------------------------
    //  ImGui panel — full semantic group editor
    // ---------------------------------------------------------------

    bool draw_gui() {
        ImGui::SetNextWindowPos(ImVec2(10, 10), ImGuiCond_FirstUseEver);
        ImGui::SetNextWindowSize(ImVec2(340, 500), ImGuiCond_FirstUseEver);

        ImGui::Begin("EASIR Editor");

        // View mode toggles (mutually exclusive: Edge, Semantic Shading, Review).
        if (m_edgePreviewSwitch) {
            if (ImGui::Checkbox("Edge Preview", &m_edgePreviewActive)) {
                if (m_edgePreviewActive) {
                    if (m_semanticShadingActive) {
                        m_semanticShadingActive = false;
                        apply_semantic_shading(false);  // Revert materials to flat
                    }
                    if (m_reviewMode) {
                        m_reviewMode = false;
                        apply_review_mode(false);
                        EASIR_LOG("[EASIR] Review Mode: off (superseded by Edge Preview)\n");
                    }
                    m_edgePreviewSwitch->setSingleChildOn(1);
                } else {
                    m_edgePreviewSwitch->setSingleChildOn(0);
                }
            }
        }
        if (ImGui::Checkbox("Semantic Shading", &m_semanticShadingActive)) {
            if (m_semanticShadingActive) {
                if (m_edgePreviewActive) {
                    m_edgePreviewActive = false;
                    if (m_edgePreviewSwitch) m_edgePreviewSwitch->setSingleChildOn(0);
                }
                if (m_reviewMode) {
                    m_reviewMode = false;
                    apply_review_mode(false);
                    EASIR_LOG("[EASIR] Review Mode: off (superseded by Semantic Shading)\n");
                }
            }
            apply_semantic_shading(m_semanticShadingActive);
        }
        if (m_semanticShadingActive && m_sunLight && m_camera) {
            ImGui::SameLine();
            if (ImGui::SmallButton("[L]")) {
                // Reset light direction to camera forward (into screen).
                auto* lookAt = dynamic_cast<vsg::LookAt*>(m_camera->viewMatrix.get());
                if (lookAt) {
                    auto fwd = vsg::normalize(lookAt->center - lookAt->eye);
                    m_sunLight->direction = vsg::vec3{
                        static_cast<float>(fwd.x),
                        static_cast<float>(fwd.y),
                        static_cast<float>(fwd.z)};
                }
            }
            if (ImGui::IsItemHovered()) ImGui::SetTooltip("Reset light to camera direction");
        }

        // Review Mode toggle (Phase G): render ALL assets in full color with
        // editing locked out. Great for inspecting the whole assembly.
        if (ImGui::Checkbox("Review Mode", &m_reviewMode)) {
            EASIR_LOG("[EASIR] Review Mode: %s\n", m_reviewMode ? "on" : "off");
            if (m_reviewMode) {
                if (m_edgePreviewActive) {
                    m_edgePreviewActive = false;
                    if (m_edgePreviewSwitch) m_edgePreviewSwitch->setSingleChildOn(0);
                    EASIR_LOG("[EASIR] Edge Preview: off (superseded by Review Mode)\n");
                }
                if (m_semanticShadingActive) {
                    m_semanticShadingActive = false;
                    apply_semantic_shading(false);
                    EASIR_LOG("[EASIR] Semantic Shading: off (superseded by Review Mode)\n");
                }
            }
            apply_review_mode(m_reviewMode);
        }
        ImGui::Separator();

        // Disable editing controls while edge preview or review mode is active.
        const bool editingLocked = m_edgePreviewActive || m_reviewMode;
        if (editingLocked) ImGui::BeginDisabled();

        draw_asset_dropdown();
        draw_save_load_buttons();
        ImGui::Separator();
        draw_selection_mode();
        ImGui::Separator();
        draw_selection_info();
        ImGui::Separator();
        draw_group_list();
        ImGui::Separator();
        draw_articulation_section();
        ImGui::Separator();
        draw_joint_test_panel();
        ImGui::Separator();
        draw_controls_help();

        if (editingLocked) ImGui::EndDisabled();

        ImGui::End();

        // Missing-file modal (Phase D: Remove/Cancel; Phase H adds Locate).
        draw_missing_files_popup();

        // Follow-up modal after a successful Locate.
        draw_locate_restart_popup();

        // Handle hover highlight — check if it changed this frame.
        update_hover_highlight();

        // Live recolor when assignments change.
        if (m_needsSceneColorUpdate) {
            recolor_scene();
            m_needsSceneColorUpdate = false;
        }

        return true;
    }

private:
    vsg::ref_ptr<vsg::Camera> m_camera;
    vsg::ref_ptr<vsg::Group> m_sceneRoot;
    vsg::ref_ptr<vsg::Trackball> m_trackball;
    vsg::ref_ptr<vsg::Viewer> m_viewer;
    // Per-asset context storage. Active asset's fields are mirrored into the
    // m_*Ptr pointers below so existing code can access them without routing
    // through active_asset() on every reference.
    std::unordered_map<std::string, AssetContext> m_assets;
    std::string m_activeAssetId;

    // Pointers into the ACTIVE asset's AssetContext. Updated by set_active_asset().
    // Safe to use as long as the active asset exists. null when no active asset.
    SemanticGroupManager* m_groupMgr = nullptr;  // aliases m_assets[m_activeAssetId].groupMgr.get()
    vsg::ref_ptr<vsg::Switch> m_edgePreviewSwitch;
    bool m_edgePreviewActive = false;
    bool m_semanticShadingActive = false;
    bool m_reviewMode = false;
    bool m_hasUnsavedChanges = false;
    vsg::ref_ptr<vsg::DirectionalLight> m_sunLight;

    // Joint test panel — interactive joint driver for the active tree.
    // Slider values are DELTAS from the joint's authored home pose, so
    // toggling Drive on produces no visible snap.
    EasirState* m_testStatePtr = nullptr;
    bool  m_jointTestEnabled = false;
    char  m_jointTestName[128] = "sat_child_joint";
    char  m_jointTestTopId[128] = "spacecraft_01";
    float m_jointTestAngleDeg = 0.0f;       // delta around chosen axis (deg)
    int   m_jointTestAxis = 2;              // 0=X, 1=Y, 2=Z
    bool  m_jointTestSweep = false;
    float m_jointTestSweepTime = 0.0f;
    bool  m_jointTestOverridePos = false;
    float m_jointTestPos[3] = {0.0f, 0.0f, 0.0f};  // absolute position override
    // Captured home pose (refreshed when the target joint or topId changes).
    std::string m_jointTestCapturedFor;     // joint name last captured
    vsg::dvec3  m_jointTestHomePos{0, 0, 0};
    vsg::dquat  m_jointTestHomeQuat{0, 0, 0, 1};

    // Missing-file modal state
    std::vector<MissingFileEntry> m_missingFiles;
    bool m_missingFilesOpen = false;
    size_t m_missingFileIndex = 0;

    // Follow-up "restart required" modal after a successful Locate.
    bool m_locateRestartOpen = false;
    std::string m_locateRestartMessage;

    // Phase H: runtime asset authoring.
    vsg::ref_ptr<vsg::Options> m_vsgOptions;
    ForwardPass* m_forwardPass = nullptr;

    /// State carried while an Add Part flow is in progress (between picking
    /// the file and clicking Confirm / Cancel).
    struct PendingChild {
        std::filesystem::path absPath;       // canonicalized chosen file
        std::string parentAssetId;           // the active asset when Add Part was clicked
        char jointNameBuf[128] = {};
        std::string jointName;               // current (valid) joint name snapshot
        float posDeg[3] = {0.0f, 0.0f, 0.0f};   // DragFloat3 position (metres, not degrees)
        float eulerDeg[3] = {0.0f, 0.0f, 0.0f}; // UI Euler angles (ZYX intrinsic)
        float pivot[3] = {0.0f, 0.0f, 0.0f};    // pivot in body frame
        bool  useEuler = true;                 // editing via Euler or direct quat?
        vsg::dquat storedQuat{0.0, 0.0, 0.0, 1.0};

        // Runtime state while the preview is live:
        std::string tempAssetId;                              // id under which the temp AssetContext is registered
        vsg::ref_ptr<vsg::MatrixTransform> tempXform;         // pointer into the scene graph
        bool loaded = false;
    };
    std::optional<PendingChild> m_pendingChild;

    // Phase H: pending remove (used by draw_articulation_section; Phase I wires it).
    std::string m_pendingRemoveJoint;

    int32_t m_lastMouseX = 0;
    int32_t m_lastMouseY = 0;

    int m_leftPressX = 0;
    int m_leftPressY = 0;
    bool m_leftPressed = false;
    bool m_shiftHeld = false;

    std::string m_selectedNodeName;   // full vsgXchange name
    std::string m_selectedShortName;  // extracted short name
    vsg::dvec3 m_selectionPoint{0.0, 0.0, 0.0};
    bool m_hasSelection = false;
    vsg::ref_ptr<vsg::Group> m_highlightGroup;

    // Hover state
    int m_hoveredGroupId = -1;
    int m_prevHoveredGroupId = -1;
    std::string m_hoveredNodeName;       // when hovering a specific node in the list
    std::string m_prevHoveredNodeName;
    vsg::ref_ptr<vsg::Group> m_hoverHighlightGroup;

    // Per-group edit state (for inline rename / color picker)
    int m_editingGroupId = -1;
    char m_editNameBuf[128] = {};

    // Pending delete confirmations
    int m_pendingDeleteGroupId = -1;
    std::string m_pendingDeleteCustomNode;

    // Selection mode: Node (whole node) or Triangle (flood-fill)
    enum class SelectionMode { Node, Triangle };
    SelectionMode m_selectionMode = SelectionMode::Node;

    // Flood-fill state
    struct FloodFillState {
        std::string parentNodeName;       // short name of the mesh node
        vsg::VertexIndexDraw* sourceVID = nullptr;  // the original VID
        uint32_t startFace = UINT32_MAX;  // face that was clicked
        std::unordered_set<uint32_t> selectedFaces;
        vsg::ref_ptr<vsg::Group> highlightGroup;
        vsg::dmat4 worldMatrix;
    };
    std::optional<FloodFillState> m_floodFill;
    float m_floodFillAngleDeg = 30.0f;

    // Per-asset editor state. Stored by-value so existing call sites keep working.
    // On set_active_asset(), we swap these with the corresponding fields in
    // m_assets[previousId] / m_assets[newId]. This keeps the code unchanged while
    // supporting multi-asset switching.
    std::unordered_map<vsg::VertexIndexDraw*, FaceAdjacency> m_adjacencyCache;
    std::unordered_map<std::string, vsg::ref_ptr<vsg::StateGroup>> m_splitOriginals;
    MaterialMap m_originalMaterials;
    std::unordered_map<std::string, EditorNodeInfo> m_nodePathMap;
    MaterialMap m_materialMap;

    // Diagnostic counters for highlight leak detection.
    int m_ffHighlightCreated = 0;
    int m_ffHighlightRemoved = 0;

    size_t m_splitDeepCopyTotal = 0;  // cumulative deep-copy bytes across all splits

    // NodeInfo alias for backward compatibility with existing method signatures.
    using NodeInfo = EditorNodeInfo;

    // ---------------------------------------------------------------
    //  Wireframe highlight pipeline helper
    // ---------------------------------------------------------------

    /// Create a depth-aware wireframe highlight: two passes drawn as siblings.
    /// Pass 1 (front): depth test GREATER (reverse-Z visible), full color.
    /// Pass 2 (back): depth test LESS (reverse-Z occluded), dimmed color.
    /// Returns a Group with two StateGroup children — caller adds geometry
    /// as children of EACH StateGroup (both draw the same geometry).
    /// Use add_wireframe_geometry() helper to add geometry to both passes.
    struct WireframePasses {
        vsg::ref_ptr<vsg::Group> group;
        vsg::ref_ptr<vsg::StateGroup> frontPass;
        vsg::ref_ptr<vsg::StateGroup> backPass;
    };

    WireframePasses create_wireframe_pipeline(
            vsg::vec4 color = {1.0f, 0.0f, 0.0f, 0.3f},
            float lineWidth = 2.0f) {
        WireframePasses result;
        result.group = vsg::Group::create();

        // Shared blend state.
        VkPipelineColorBlendAttachmentState blendAttachment{};
        blendAttachment.blendEnable = VK_TRUE;
        blendAttachment.srcColorBlendFactor = VK_BLEND_FACTOR_SRC_ALPHA;
        blendAttachment.dstColorBlendFactor = VK_BLEND_FACTOR_ONE_MINUS_SRC_ALPHA;
        blendAttachment.colorBlendOp = VK_BLEND_OP_ADD;
        blendAttachment.srcAlphaBlendFactor = VK_BLEND_FACTOR_ONE;
        blendAttachment.dstAlphaBlendFactor = VK_BLEND_FACTOR_ZERO;
        blendAttachment.alphaBlendOp = VK_BLEND_OP_ADD;
        blendAttachment.colorWriteMask = VK_COLOR_COMPONENT_R_BIT | VK_COLOR_COMPONENT_G_BIT |
                                         VK_COLOR_COMPONENT_B_BIT | VK_COLOR_COMPONENT_A_BIT;

        // Back pass (occluded) — drawn first so front pass renders on top.
        {
            vsg::vec4 dimColor{color.x, color.y, color.z, color.w * 0.3f};

            auto shaderSet = vsg::createFlatShadedShaderSet();
            auto config = vsg::GraphicsPipelineConfigurator::create(shaderSet);

            auto rasterState = vsg::RasterizationState::create();
            rasterState->polygonMode = VK_POLYGON_MODE_LINE;
            rasterState->lineWidth = lineWidth;
            rasterState->cullMode = VK_CULL_MODE_NONE;

            auto colorBlend = vsg::ColorBlendState::create();
            colorBlend->attachments = {blendAttachment};

            auto depthState = vsg::DepthStencilState::create();
            depthState->depthTestEnable = VK_TRUE;
            depthState->depthWriteEnable = VK_FALSE;
            depthState->depthCompareOp = VK_COMPARE_OP_LESS;  // reverse-Z: LESS = behind geometry

            for (auto& ps : config->pipelineStates) {
                if (ps.cast<vsg::RasterizationState>()) ps = rasterState;
                else if (ps.cast<vsg::ColorBlendState>()) ps = colorBlend;
                else if (ps.cast<vsg::DepthStencilState>()) ps = depthState;
            }

            auto mat = vsg::PhongMaterialValue::create();
            mat->value().ambient  = dimColor;
            mat->value().diffuse  = dimColor;
            mat->value().specular = vsg::vec4{0.0f, 0.0f, 0.0f, 0.0f};
            mat->value().emissive = dimColor;
            mat->value().shininess = 0.0f;
            config->assignDescriptor("material", mat);
            config->init();

            result.backPass = vsg::StateGroup::create();
            config->copyTo(result.backPass->stateCommands);
            result.group->addChild(result.backPass);
        }

        // Front pass (visible) — drawn second, on top.
        {
            auto shaderSet = vsg::createFlatShadedShaderSet();
            auto config = vsg::GraphicsPipelineConfigurator::create(shaderSet);

            auto rasterState = vsg::RasterizationState::create();
            rasterState->polygonMode = VK_POLYGON_MODE_LINE;
            rasterState->lineWidth = lineWidth;
            rasterState->cullMode = VK_CULL_MODE_NONE;

            auto colorBlend = vsg::ColorBlendState::create();
            colorBlend->attachments = {blendAttachment};

            auto depthState = vsg::DepthStencilState::create();
            depthState->depthTestEnable = VK_TRUE;
            depthState->depthWriteEnable = VK_FALSE;
            depthState->depthCompareOp = VK_COMPARE_OP_GREATER_OR_EQUAL;  // reverse-Z: GREATER = in front

            for (auto& ps : config->pipelineStates) {
                if (ps.cast<vsg::RasterizationState>()) ps = rasterState;
                else if (ps.cast<vsg::ColorBlendState>()) ps = colorBlend;
                else if (ps.cast<vsg::DepthStencilState>()) ps = depthState;
            }

            auto mat = vsg::PhongMaterialValue::create();
            mat->value().ambient  = color;
            mat->value().diffuse  = color;
            mat->value().specular = vsg::vec4{0.0f, 0.0f, 0.0f, 0.0f};
            mat->value().emissive = color;
            mat->value().shininess = 0.0f;
            config->assignDescriptor("material", mat);
            config->init();

            result.frontPass = vsg::StateGroup::create();
            config->copyTo(result.frontPass->stateCommands);
            result.group->addChild(result.frontPass);
        }

        return result;
    }

    /// Add geometry children to both wireframe passes.
    static void add_wireframe_geometry(WireframePasses& wp,
                                        const std::vector<vsg::ref_ptr<vsg::Node>>& geomChildren) {
        for (auto& child : geomChildren) {
            wp.frontPass->addChild(child);
            wp.backPass->addChild(child);
        }
    }

    static void add_wireframe_geometry(WireframePasses& wp,
                                        vsg::ref_ptr<vsg::Node> geomChild) {
        wp.frontPass->addChild(geomChild);
        wp.backPass->addChild(geomChild);
    }

    // ---------------------------------------------------------------
    //  Select node by short name (from GUI panel click)
    // ---------------------------------------------------------------

    /// Create a wireframe highlight group for a custom node's face subset.
    /// Returns nullptr if the parent VID can't be found.
    vsg::ref_ptr<vsg::Group> create_custom_node_highlight(
            const CustomNodeDef& def, vsg::vec4 color = {1.0f, 0.0f, 0.0f, 0.3f},
            float lineWidth = 2.0f) {
        // Find parent node info.
        auto parentIt = m_nodePathMap.find(def.parent);
        if (parentIt == m_nodePathMap.end()) return {};

        // Find the VID in parent's geomChildren.
        vsg::VertexIndexDraw* parentVID = nullptr;
        for (auto& child : parentIt->second.geomChildren) {
            parentVID = dynamic_cast<vsg::VertexIndexDraw*>(child.get());
            if (parentVID) break;
        }
        if (!parentVID) return {};

        // Build/retrieve adjacency to get the index data.
        auto adjIt = m_adjacencyCache.find(parentVID);
        if (adjIt == m_adjacencyCache.end()) {
            auto adj = buildFaceAdjacency(parentVID);
            adjIt = m_adjacencyCache.emplace(parentVID, std::move(adj)).first;
        }
        const auto& adj = adjIt->second;

        // Build subset index buffer.
        std::vector<uint32_t> validFaces;
        for (uint32_t f : def.faces) {
            if (f < adj.faceCount) validFaces.push_back(f);
        }
        if (validFaces.empty()) return {};

        auto newIndices = vsg::uintArray::create(static_cast<uint32_t>(validFaces.size() * 3));
        uint32_t idx = 0;
        for (uint32_t f : validFaces) {
            newIndices->at(idx++) = adj.indices[f * 3 + 0];
            newIndices->at(idx++) = adj.indices[f * 3 + 1];
            newIndices->at(idx++) = adj.indices[f * 3 + 2];
        }

        auto subsetVID = vsg::VertexIndexDraw::create();
        vsg::DataList arrayData;
        for (auto& buf : parentVID->arrays) {
            if (buf && buf->data) arrayData.push_back(buf->data);
        }
        subsetVID->assignArrays(arrayData);
        subsetVID->assignIndices(newIndices);
        subsetVID->indexCount = static_cast<uint32_t>(newIndices->size());
        subsetVID->instanceCount = 1;

        auto transform = vsg::MatrixTransform::create();
        transform->matrix = parentIt->second.worldMatrix;

        auto wp = create_wireframe_pipeline(color, lineWidth);
        add_wireframe_geometry(wp, subsetVID);
        transform->addChild(wp.group);

        auto group = vsg::Group::create();
        group->addChild(transform);
        return group;
    }

    /// Select a custom node from the sidebar panel.
    void select_custom_node_by_name(const std::string& customName) {
        if (!m_groupMgr) return;
        const auto* def = m_groupMgr->custom_node(customName);
        if (!def) return;

        remove_highlight();

        m_selectedShortName = customName;
        m_selectedNodeName = customName;
        m_hasSelection = true;

        auto hlGroup = create_custom_node_highlight(*def);
        if (!hlGroup) return;

        m_highlightGroup = hlGroup;
        m_sceneRoot->addChild(m_highlightGroup);

        if (m_viewer && m_viewer->compileManager) {
            auto result = m_viewer->compileManager->compile(m_highlightGroup);
            if (result.requiresViewerUpdate()) {
                vsg::updateTasks(m_viewer->recordAndSubmitTasks, m_viewer->compileManager, result);
            }
        }

        EASIR_LOG("[EASIR] Selected custom node (from panel): '%s' (%zu faces)\n",
                    customName.c_str(), def->faces.size());
    }

    /// Given a parent node name and hit vertex indices, check if the hit face
    /// belongs to a custom node. Returns the custom node name, or empty string.
    std::string find_custom_node_for_face(const std::string& parentShortName,
                                           uint32_t v0, uint32_t v1, uint32_t v2) {
        if (!m_groupMgr) return {};
        auto customNodes = m_groupMgr->custom_nodes_for_parent(parentShortName);
        if (customNodes.empty()) return {};

        // Find the parent VID and its adjacency to look up the face index.
        auto parentIt = m_nodePathMap.find(parentShortName);
        if (parentIt == m_nodePathMap.end()) return {};

        vsg::VertexIndexDraw* parentVID = nullptr;
        for (auto& child : parentIt->second.geomChildren) {
            parentVID = dynamic_cast<vsg::VertexIndexDraw*>(child.get());
            if (parentVID) break;
        }
        if (!parentVID) return {};

        auto adjIt = m_adjacencyCache.find(parentVID);
        if (adjIt == m_adjacencyCache.end()) {
            auto adj = buildFaceAdjacency(parentVID);
            adjIt = m_adjacencyCache.emplace(parentVID, std::move(adj)).first;
        }

        uint32_t hitFace = findFaceFromVertexIndices(adjIt->second, v0, v1, v2);
        if (hitFace == UINT32_MAX) return {};

        // Check which custom node owns this face.
        for (const auto* cn : customNodes) {
            for (uint32_t f : cn->faces) {
                if (f == hitFace) return cn->name;
            }
        }
        return {};
    }

    void select_node_by_name(const std::string& shortName) {
        auto it = m_nodePathMap.find(shortName);
        if (it == m_nodePathMap.end()) return;

        remove_highlight();

        m_selectedShortName = shortName;
        m_selectedNodeName = it->second.fullName;
        m_hasSelection = true;
        // Selection point = center of the node's bounding box (approximate).
        // Just use the transform origin for now.
        m_selectionPoint = vsg::dvec3(
            it->second.worldMatrix[3][0],
            it->second.worldMatrix[3][1],
            it->second.worldMatrix[3][2]);

        EASIR_LOG("[EASIR] Selected (from panel): '%s' — %zu children, matrix[3]=(%f,%f,%f)\n",
                    shortName.c_str(), it->second.geomChildren.size(),
                    it->second.worldMatrix[3][0], it->second.worldMatrix[3][1], it->second.worldMatrix[3][2]);

        // Build highlight using stored node info.
        if (it->second.geomChildren.empty()) {
            EASIR_LOG("[EASIR] WARNING: No geomChildren for '%s', cannot highlight\n", shortName.c_str());
            return;
        }

        // If the node has custom nodes carved from it, only highlight remaining faces.
        if (m_groupMgr && !m_groupMgr->custom_nodes_for_parent(shortName).empty()) {
            add_highlight_excluding_custom(shortName);
            return;
        }

        m_highlightGroup = vsg::Group::create();
        auto transform = vsg::MatrixTransform::create();
        transform->matrix = it->second.worldMatrix;

        auto wp = create_wireframe_pipeline();
        add_wireframe_geometry(wp, it->second.geomChildren);
        transform->addChild(wp.group);
        m_highlightGroup->addChild(transform);

        m_sceneRoot->addChild(m_highlightGroup);

        if (m_viewer && m_viewer->compileManager) {
            auto result = m_viewer->compileManager->compile(m_highlightGroup);
            // Always update tasks — even if requiresViewerUpdate is false, the new
            // StateGroup/pipeline was compiled and needs to be part of the render.
            vsg::updateTasks(m_viewer->recordAndSubmitTasks, m_viewer->compileManager, result);
        }
    }

    // ---------------------------------------------------------------
    //  Live recoloring — update materials from group manager
    // ---------------------------------------------------------------

    /// Run the draw-call split visitor to partition parent VIDs by custom nodes.
    /// Call after creating or deleting custom nodes.
    /// Reverts any previous splits first, then re-splits from the originals.
    void run_draw_call_split() {
        if (!m_groupMgr || !m_sceneRoot || !m_viewer) return;

        EASIR_LOG("[EASIR] DCS: run_draw_call_split() entry — "
                    "splitOriginals=%zu, origMaterials=%zu, matMap=%zu, custom=%zu\n",
                    m_splitOriginals.size(), m_originalMaterials.size(),
                    m_materialMap.size(), m_groupMgr->custom_nodes().size());

        // Save original materials before first split (so we can restore them on revert).
        if (m_originalMaterials.empty()) {
            m_originalMaterials = m_materialMap;
            EASIR_LOG("[EASIR] DCS: captured initial origMaterials (%zu)\n",
                        m_originalMaterials.size());
        }

        // Revert: restore original materials into the map.
        for (auto& [name, mat] : m_originalMaterials) {
            m_materialMap[name] = mat;
        }
        // Remove any split-generated material entries that aren't in the originals.
        size_t removed = 0;
        for (auto it = m_materialMap.begin(); it != m_materialMap.end(); ) {
            if (m_originalMaterials.find(it->first) == m_originalMaterials.end()) {
                it = m_materialMap.erase(it);
                ++removed;
            } else {
                ++it;
            }
        }
        EASIR_LOG("[EASIR] DCS: reverted matMap — removed %zu split entries, now %zu\n",
                    removed, m_materialMap.size());

        // Wait for all in-flight GPU frames to finish before swapping scene graph
        // nodes. The revert drops the last ref to the splitter group's VIDs/materials,
        // freeing their GPU buffers — in-flight command buffers must not still reference them.
        if (!m_splitOriginals.empty() && m_viewer) {
            EASIR_LOG("[EASIR] DCS: deviceWaitIdle before scene graph revert...\n");
            m_viewer->deviceWaitIdle();
            EASIR_LOG("[EASIR] DCS: deviceWaitIdle done\n");
        }

        // Track which parents we actually reverted so we can compile them even if
        // they don't get re-split (deletion case with no custom nodes left).
        std::vector<std::string> revertedParents;

        // Revert any previous splits by restoring original StateGroups.
        for (auto& [shortName, orig] : m_splitOriginals) {
            // Find the named parent group in the scene graph and restore.
            struct Restorer : public vsg::Visitor {
                const std::string& targetShortName;
                vsg::ref_ptr<vsg::StateGroup> originalSG;
                bool restored = false;

                Restorer(const std::string& name, vsg::ref_ptr<vsg::StateGroup> sg)
                    : targetShortName(name), originalSG(sg) {}

                void apply(vsg::Node& node) override { node.traverse(*this); }
                void apply(vsg::Group& group) override {
                    std::string name;
                    if (group.getValue("name", name) && !name.empty()) {
                        auto sn = SemanticGroupManager::extract_short_name(name);
                        if (sn == targetShortName) {
                            // Find and replace the splitter group with the original SG.
                            for (size_t i = 0; i < group.children.size(); ++i) {
                                // The splitter is a plain Group (not StateGroup).
                                auto* child = group.children[i].get();
                                if (!dynamic_cast<vsg::StateGroup*>(child) &&
                                    dynamic_cast<vsg::Group*>(child)) {
                                    group.children[i] = originalSG;
                                    restored = true;
                                    return;
                                }
                            }
                        }
                    }
                    group.traverse(*this);
                }
                void apply(vsg::MatrixTransform& mt) override {
                    std::string name;
                    if (mt.getValue("name", name) && !name.empty()) {
                        auto sn = SemanticGroupManager::extract_short_name(name);
                        if (sn == targetShortName) {
                            for (size_t i = 0; i < mt.children.size(); ++i) {
                                auto* child = mt.children[i].get();
                                if (!dynamic_cast<vsg::StateGroup*>(child) &&
                                    dynamic_cast<vsg::Group*>(child)) {
                                    mt.children[i] = originalSG;
                                    restored = true;
                                    return;
                                }
                            }
                        }
                    }
                    mt.traverse(*this);
                }
            };
            Restorer restorer(shortName, orig);
            m_sceneRoot->accept(restorer);
            if (restorer.restored) {
                revertedParents.push_back(shortName);
                EASIR_LOG("[EASIR] DCS: reverted '%s' to original StateGroup\n",
                            shortName.c_str());
            } else {
                EASIR_LOG("[EASIR] DCS: no revert needed for '%s' (already original)\n",
                            shortName.c_str());
            }
        }

        // Now run the split visitor on the restored scene (deep copy for runtime).
        EASIR_LOG("[EASIR] DCS: running new split visitor (deepCopy=true)...\n");
        DrawCallSplitVisitor splitVisitor(*m_groupMgr, m_materialMap, /*deepCopy=*/true);
        m_sceneRoot->accept(splitVisitor);
        EASIR_LOG("[EASIR] DCS: new split produced %zu new materials, %zu original VIDs\n",
                    splitVisitor.new_materials().size(),
                    splitVisitor.original_vids().size());

        // Update m_splitOriginals: remove entries for parents that were reverted
        // but NOT re-split (their custom nodes were all deleted).
        std::unordered_set<std::string> newSplitParents;
        for (auto& [name, orig] : splitVisitor.original_vids()) {
            newSplitParents.insert(name);
            if (m_splitOriginals.find(name) == m_splitOriginals.end()) {
                m_splitOriginals[name] = orig.stateGroup;
            }
        }
        // Remove reverted parents that weren't re-split.
        for (const auto& name : revertedParents) {
            if (newSplitParents.find(name) == newSplitParents.end()) {
                m_splitOriginals.erase(name);
                EASIR_LOG("[EASIR] DCS: cleared m_splitOriginals['%s'] (reverted, not re-split)\n",
                            name.c_str());
            }
        }

        // Merge new materials into our map for live recoloring.
        for (auto& [name, mat] : splitVisitor.new_materials()) {
            m_materialMap[name] = mat;
        }

        // Compile affected parent subtrees. We must compile:
        // 1. Any parent that was just re-split (new splitter group needs compilation)
        // 2. Any parent that was reverted but NOT re-split (restored original StateGroup
        //    was never compiled — it existed before the startup split but the initial
        //    m_viewer->compile() only saw the split scene graph).
        std::unordered_set<std::string> parentsToCompile;
        for (auto& [name, orig] : splitVisitor.original_vids()) {
            parentsToCompile.insert(name);
        }
        for (const auto& name : revertedParents) {
            if (newSplitParents.find(name) == newSplitParents.end()) {
                parentsToCompile.insert(name);
            }
        }
        EASIR_LOG("[EASIR] DCS: parents to compile: %zu\n", parentsToCompile.size());

        if (m_viewer && m_viewer->compileManager) {
            for (const auto& name : parentsToCompile) {
                // Find the parent group node in the scene.
                auto parentIt = m_nodePathMap.find(name);
                if (parentIt == m_nodePathMap.end()) continue;
                // The parent node's geomChildren were from the original VID.
                // We need to find the actual named node in the scene graph.
                struct NodeFinder : public vsg::Visitor {
                    const std::string& target;
                    vsg::ref_ptr<vsg::Node> found;
                    NodeFinder(const std::string& t) : target(t) {}
                    void apply(vsg::Node& node) override { node.traverse(*this); }
                    void apply(vsg::Group& group) override {
                        std::string n;
                        if (group.getValue("name", n)) {
                            auto sn = SemanticGroupManager::extract_short_name(n);
                            if (sn == target) { found = &group; return; }
                        }
                        group.traverse(*this);
                    }
                    void apply(vsg::MatrixTransform& mt) override {
                        std::string n;
                        if (mt.getValue("name", n)) {
                            auto sn = SemanticGroupManager::extract_short_name(n);
                            if (sn == target) { found = &mt; return; }
                        }
                        mt.traverse(*this);
                    }
                };
                NodeFinder finder(name);
                m_sceneRoot->accept(finder);
                if (finder.found) {
                    EASIR_LOG("[EASIR] DCS: compiling subtree for '%s'...\n", name.c_str());
                    try {
                        auto result = m_viewer->compileManager->compile(finder.found);
                        EASIR_LOG("[EASIR] DCS: compile done for '%s', requiresUpdate=%d\n",
                                    name.c_str(), result.requiresViewerUpdate());
                        if (result.requiresViewerUpdate()) {
                            vsg::updateTasks(m_viewer->recordAndSubmitTasks,
                                             m_viewer->compileManager, result);
                        }
                    } catch (const std::exception& e) {
                        EASIR_LOG("[EASIR] DCS: COMPILE EXCEPTION for '%s': %s\n",
                                    name.c_str(), e.what());
                    } catch (...) {
                        EASIR_LOG("[EASIR] DCS: COMPILE UNKNOWN EXCEPTION for '%s'\n",
                                    name.c_str());
                    }
                } else {
                    EASIR_LOG("[EASIR] DCS: WARNING could not find scene node '%s' to compile\n",
                                name.c_str());
                }
            }
        }

        m_splitDeepCopyTotal += splitVisitor.deep_copy_bytes();
        EASIR_LOG("[EASIR] DCS: run_draw_call_split() complete — "
                    "%zu new materials, deep-copy %.1f KB (total %.1f MB)\n",
                    splitVisitor.new_materials().size(),
                    splitVisitor.deep_copy_bytes() / 1024.0,
                    m_splitDeepCopyTotal / (1024.0 * 1024.0));

        // Note: adjacency cache is NOT invalidated here. The cache is keyed by
        // the original VID pointer (from m_nodePathMap.geomChildren), which never
        // changes. Face indices in custom nodes always reference the original
        // VID's index buffer, so the adjacency stays valid across splits.
    }

    void recolor_scene() {
        if (!m_groupMgr) return;
        EASIR_LOG("[EASIR] recolor_scene: iterating %zu materials\n", m_materialMap.size());
        size_t updated = 0;
        for (auto& [shortName, mat] : m_materialMap) {
            if (!mat) continue;
            vsg::vec4 color = m_groupMgr->color_for_node(shortName);
            apply_material_color(mat, color, m_semanticShadingActive);
            ++updated;
        }
        EASIR_LOG("[EASIR] recolor_scene: updated %zu materials\n", updated);
    }

    /// Apply a semantic color to a material, respecting the shading toggle.
    static void apply_material_color(vsg::ref_ptr<vsg::PhongMaterialValue>& mat,
                                      const vsg::vec4& color, bool shading) {
        if (shading) {
            // N·L shading: emissive provides base brightness, diffuse adds lighting.
            mat->value().ambient  = vsg::vec4{0.0f, 0.0f, 0.0f, 1.0f};
            mat->value().diffuse  = vsg::vec4{color.x * 0.7f, color.y * 0.7f, color.z * 0.7f, 1.0f};
            mat->value().emissive = vsg::vec4{color.x * 0.3f, color.y * 0.3f, color.z * 0.3f, 1.0f};
        } else {
            // Flat: emissive only, output = color exactly.
            mat->value().ambient  = vsg::vec4{0.0f, 0.0f, 0.0f, 1.0f};
            mat->value().diffuse  = vsg::vec4{0.0f, 0.0f, 0.0f, 1.0f};
            mat->value().emissive = color;
        }
        mat->value().specular = vsg::vec4{0.0f, 0.0f, 0.0f, 1.0f};
        mat->value().shininess = 0.0f;
        mat->dirty();
    }

    /// Toggle semantic shading on/off for all materials.
    void apply_semantic_shading(bool enabled) {
        // Note: m_semanticShadingActive must already reflect the new state
        // when this is called (draw_gui updates it via ImGui::Checkbox BEFORE calling).
        // Active asset: full semantic colors.
        if (m_groupMgr) {
            for (auto& [shortName, mat] : m_materialMap) {
                if (!mat) continue;
                vsg::vec4 color = m_groupMgr->color_for_node(shortName);
                apply_material_color(mat, color, enabled);
            }
        }
        // Inactive assets: reapply dim (which honours current shading mode).
        for (auto& [id, ctx] : m_assets) {
            if (id == m_activeAssetId) continue;
            apply_inactive_appearance(ctx);
        }
    }

    // ---------------------------------------------------------------
    //  GUI: Asset dropdown (multi-asset selector)
    // ---------------------------------------------------------------

    /// Build a depth-first ordered list of (assetId, displayLabel) pairs that
    /// reflects the parent/child articulation tree. Roots (assets with empty
    /// parentAssetId) anchor the walk; children are visited after their parent
    /// with two spaces of indentation per depth level. Unparented but
    /// unreferenced assets (shouldn't happen in practice) are appended at the
    /// end under "(orphans)".
    void build_tree_labels(std::vector<std::pair<std::string, std::string>>& out) {
        out.clear();
        if (m_assets.empty()) return;

        std::unordered_set<std::string> visited;

        std::function<void(const std::string&, int)> visit =
            [&](const std::string& id, int depth) {
                auto it = m_assets.find(id);
                if (it == m_assets.end()) return;
                if (!visited.insert(id).second) return;  // already visited

                AssetContext& ctx = it->second;
                std::string label(static_cast<size_t>(depth) * 2, ' ');
                if (ctx.jointName.empty()) {
                    label += id;  // root
                } else {
                    // Show the joint name as the primary label for children so
                    // the hierarchy reads as bus -> panel_left_hinge, etc.
                    label += ctx.jointName;
                    label += "  [";
                    label += id;
                    label += "]";
                }
                out.emplace_back(id, std::move(label));

                for (const auto& childId : ctx.childAssetIds) {
                    visit(childId, depth + 1);
                }
            };

        // Roots first (depth 0), in insertion order via a stable pass.
        for (auto& [id, ctx] : m_assets) {
            if (ctx.parentAssetId.empty()) visit(id, 0);
        }
        // Any orphans (shouldn't normally happen).
        for (auto& [id, ctx] : m_assets) {
            if (!visited.count(id)) {
                EASIR_LOG("[EASIR] tree dropdown: orphan asset '%s' (parent='%s')\n",
                            id.c_str(), ctx.parentAssetId.c_str());
                visit(id, 0);
            }
        }
    }

    void draw_asset_dropdown() {
        if (m_assets.size() <= 1) return;  // no dropdown needed for single asset

        // Compute label for the currently-selected item (what the combo shows
        // when closed). Uses the same format as the list entries but with no
        // leading indentation so the collapsed combo reads cleanly.
        std::string currentLabel;
        if (m_activeAssetId.empty()) {
            currentLabel = "(none)";
        } else {
            auto it = m_assets.find(m_activeAssetId);
            if (it != m_assets.end() && !it->second.jointName.empty()) {
                currentLabel = it->second.jointName + "  [" + m_activeAssetId + "]";
            } else {
                currentLabel = m_activeAssetId;
            }
        }

        std::vector<std::pair<std::string, std::string>> entries;
        build_tree_labels(entries);

        if (ImGui::BeginCombo("Asset", currentLabel.c_str())) {
            for (auto& [id, label] : entries) {
                bool sel = (id == m_activeAssetId);
                // Push a unique ImGui id per line so entries with duplicate
                // labels (shouldn't happen but cheap insurance) remain clickable.
                ImGui::PushID(id.c_str());
                if (ImGui::Selectable(label.c_str(), sel)) {
                    EASIR_LOG("[EASIR] dropdown: switching to '%s'\n", id.c_str());
                    switch_active_asset(id);
                }
                if (sel) ImGui::SetItemDefaultFocus();
                ImGui::PopID();
            }
            ImGui::EndCombo();
        }
        ImGui::Separator();
    }

    /// Apply (or revert) Review Mode: when enabled, every asset is restored
    /// to its full semantic coloring regardless of active-asset focus. When
    /// disabled, all non-active assets are re-dimmed.
    ///
    /// The active asset's materials live in the editor member fields (m_materialMap
    /// etc.) courtesy of the swap pattern, so we handle it separately from the
    /// contexts in m_assets. For inactive assets we use the mini-helper
    /// restore_asset_full_color which walks the AssetContext's own material map.
    void apply_review_mode(bool on) {
        if (on) {
            size_t restored = 0;
            // Active asset: its materials are mirrored in m_materialMap — reuse
            // restore_active_appearance which walks them via m_groupMgr.
            if (has_active_asset()) {
                restore_active_appearance();
                restored += m_materialMap.size();
            }
            // Non-active assets: walk their per-context materialMap and use
            // each one's own group manager for coloring.
            for (auto& [id, ctx] : m_assets) {
                if (id == m_activeAssetId) continue;
                size_t n = 0;
                for (auto& [shortName, mat] : ctx.materialMap) {
                    if (!mat || !ctx.groupMgr) continue;
                    vsg::vec4 color = ctx.groupMgr->color_for_node(shortName);
                    apply_material_color(mat, color, m_semanticShadingActive);
                    ++n;
                }
                ctx.isActive = true;  // logical marker; reverted when review off
                restored += n;
                EASIR_LOG("[EASIR] review: restored '%s' (%zu materials)\n",
                            id.c_str(), n);
            }
            EASIR_LOG("[EASIR] review: ON, restored %zu materials across %zu assets\n",
                        restored, m_assets.size());
        } else {
            // Re-dim every non-active asset.
            size_t dimmed = 0;
            for (auto& [id, ctx] : m_assets) {
                if (id == m_activeAssetId) continue;
                apply_inactive_appearance(ctx);
                dimmed += ctx.materialMap.size();
                ctx.isActive = false;
            }
            // Active asset stays full-color.
            if (has_active_asset()) restore_active_appearance();
            EASIR_LOG("[EASIR] review: OFF, re-dimmed %zu materials across %zu inactive assets\n",
                        dimmed, m_assets.size() - (has_active_asset() ? 1 : 0));
        }
    }

    /// Switch active asset AND update appearances (dim old, restore new).
    /// Wraps set_active_asset with dimming logic.
    void switch_active_asset(const std::string& newId) {
        if (newId == m_activeAssetId) return;
        std::string oldId = m_activeAssetId;
        set_active_asset(newId);
        // After swap, the new asset's materials are in m_materialMap.
        // Re-apply active appearance (full color) to the new asset.
        restore_active_appearance();
        // Dim the previously-active asset (its materials now live in m_assets[oldId].materialMap).
        if (!oldId.empty()) {
            auto it = m_assets.find(oldId);
            if (it != m_assets.end()) apply_inactive_appearance(it->second);
        }
        // Remove any highlights that might belong to the old asset.
        remove_highlight();
        m_selectedNodeName.clear();
        m_selectedShortName.clear();
        m_hasSelection = false;
    }

    /// Apply darker-gray inactive appearance to an asset's materials.
    /// Used for non-active assets when in multi-asset mode.
    /// Both diffuse (for N·L shading) and emissive (for flat unlit mode) are set,
    /// so shading toggle still works on inactive assets.
    void apply_inactive_appearance(AssetContext& ctx) {
        // Darker gray than Phase B initial attempt (which was too light).
        const vsg::vec4 flatGray{0.15f, 0.15f, 0.15f, 1.0f};      // emissive (unlit)
        const vsg::vec4 diffGray{0.18f, 0.18f, 0.18f, 1.0f};      // diffuse (lit)
        const vsg::vec4 emisDim{0.05f, 0.05f, 0.05f, 1.0f};       // small emissive under lighting
        size_t n = 0;
        for (auto& [name, mat] : ctx.materialMap) {
            if (!mat) continue;
            if (m_semanticShadingActive) {
                // N·L shading: keep a low emissive so it's not pure black in shadow.
                mat->value().ambient  = vsg::vec4{0,0,0,1};
                mat->value().diffuse  = diffGray;
                mat->value().emissive = emisDim;
            } else {
                // Flat unlit mode: emissive is the only contributor.
                mat->value().ambient  = vsg::vec4{0,0,0,1};
                mat->value().diffuse  = vsg::vec4{0,0,0,1};
                mat->value().emissive = flatGray;
            }
            mat->value().specular = vsg::vec4{0,0,0,0};
            mat->value().shininess = 0.0f;
            mat->dirty();
            ++n;
        }
        EASIR_LOG("[EASIR] inactive appearance applied: '%s' (%zu materials, shading=%d)\n",
                    ctx.assetId.c_str(), n, m_semanticShadingActive ? 1 : 0);
        ctx.isActive = false;
    }

    /// Restore full semantic colors for the currently-active asset.
    void restore_active_appearance() {
        if (!m_groupMgr) return;
        size_t n = 0;
        for (auto& [shortName, mat] : m_materialMap) {
            if (!mat) continue;
            vsg::vec4 color = m_groupMgr->color_for_node(shortName);
            apply_material_color(mat, color, m_semanticShadingActive);
            ++n;
        }
        EASIR_LOG("[EASIR] active appearance restored: '%s' (%zu materials)\n",
                    m_activeAssetId.c_str(), n);
        auto* a = active_asset();
        if (a) a->isActive = true;
    }

    /// Walk an intersection nodePath backwards and find which asset (by rootTransform)
    /// contains the hit. Returns nullptr if no match.
    AssetContext* asset_for_node_path(const vsg::Intersector::NodePath& path) {
        for (auto it = path.rbegin(); it != path.rend(); ++it) {
            const vsg::Node* n = *it;
            for (auto& [id, ctx] : m_assets) {
                if (ctx.rootTransform.get() == n) return &ctx;
            }
        }
        return nullptr;
    }

    // ---------------------------------------------------------------
    //  GUI: Articulation section (Phase H — Add Part + child editor)
    // ---------------------------------------------------------------

    /// Walk up the parentAssetId chain of `id` until we reach a root (an
    /// asset whose parentAssetId is empty). Returns the root's id, or empty
    /// if `id` is unknown. Cycles are not expected here; the editor never
    /// authors them, but a depth cap of 64 keeps us safe.
    std::string top_level_root_id(const std::string& id) const {
        std::string cur = id;
        for (int depth = 0; depth < 64; ++depth) {
            auto it = m_assets.find(cur);
            if (it == m_assets.end()) return {};
            if (it->second.parentAssetId.empty()) return cur;
            cur = it->second.parentAssetId;
        }
        return {};  // depth cap hit (cycle?)
    }

    /// Is a joint name already in use within the spacecraft tree rooted at
    /// `parentId`? Phase L: scoped per-tree — two spacecraft may legally
    /// own joints with the same local name. Checks live AssetContexts,
    /// the ForwardPass binding registry, and any unsaved in-memory children
    /// in group managers — all restricted to the same tree.
    bool is_joint_name_taken(const std::string& name,
                              const std::string& parentId = "") const {
        if (name.empty()) return true;

        // Composite asset id collision (`parent/name`) is global.
        if (!parentId.empty()) {
            const std::string composite = parentId + "/" + name;
            if (m_assets.find(composite) != m_assets.end()) {
                EASIR_LOG("[EASIR] is_joint_name_taken: composite id '%s' already in use\n",
                            composite.c_str());
                return true;
            }
        }

        // All other checks are scoped to the spacecraft tree containing parentId.
        // If no parent was given (legacy callers), skip the scoped checks.
        if (parentId.empty()) return false;
        const std::string rootId = top_level_root_id(parentId);
        if (rootId.empty()) return false;

        // Live AssetContext joint names within the same tree.
        for (const auto& [id, ctx] : m_assets) {
            if (ctx.jointName.empty()) continue;
            if (ctx.jointName != name) continue;
            // Must belong to the same tree.
            if (top_level_root_id(id) == rootId) {
                EASIR_LOG("[EASIR] is_joint_name_taken: tree-scoped collision in '%s' (asset '%s')\n",
                            rootId.c_str(), id.c_str());
                return true;
            }
        }
        // ForwardPass binding registry, scoped to this tree.
        if (m_forwardPass && m_forwardPass->joint_for(rootId, name)) {
            EASIR_LOG("[EASIR] is_joint_name_taken: tree-scoped collision in '%s' (binding)\n",
                        rootId.c_str());
            return true;
        }
        // Unsaved in-memory children of any group manager in this tree.
        for (const auto& [id, ctx] : m_assets) {
            if (!ctx.groupMgr) continue;
            if (top_level_root_id(id) != rootId) continue;
            for (const auto& c : ctx.groupMgr->children()) {
                if (c.jointName == name) {
                    EASIR_LOG("[EASIR] is_joint_name_taken: tree-scoped collision in '%s' (group mgr child of '%s')\n",
                                rootId.c_str(), id.c_str());
                    return true;
                }
            }
        }
        return false;
    }

    /// Load the mesh the user picked in "Add Part" and attach it under the
    /// active asset as a TEMPORARY articulated child. All the state is stored
    /// in m_pendingChild; Confirm promotes it, Cancel removes it.
    /// Returns true on success.
    bool load_pending_temporary() {
        if (!m_pendingChild) return false;
        PendingChild& pc = *m_pendingChild;
        auto* parent = active_asset();
        if (!parent) {
            EASIR_LOG("[EASIR] load_pending_temporary: no active asset\n");
            return false;
        }
        if (!m_vsgOptions || !m_forwardPass || !m_viewer) {
            EASIR_LOG("[EASIR] load_pending_temporary: editor pointers not wired\n");
            return false;
        }

        EASIR_LOG("[EASIR] load_pending_temporary: file='%s' parent='%s'\n",
                    pc.absPath.string().c_str(), pc.parentAssetId.c_str());

        auto node = vsg::read_cast<vsg::Node>(pc.absPath.string(), m_vsgOptions);
        if (!node) {
            EASIR_LOG("[EASIR] load_pending_temporary: read_cast returned null\n");
            return false;
        }

        // Build the transform with the current pose values.
        pc.storedQuat = pc.useEuler
            ? euler_zyx_intrinsic_to_quat(vsg::dvec3{pc.eulerDeg[0], pc.eulerDeg[1], pc.eulerDeg[2]})
            : pc.storedQuat;
        const vsg::dvec3 pos{pc.posDeg[0], pc.posDeg[1], pc.posDeg[2]};
        const vsg::dvec3 pivot{pc.pivot[0], pc.pivot[1], pc.pivot[2]};

        auto xform = vsg::MatrixTransform::create();
        xform->matrix = pose_to_matrix_d_pivot(pos, pc.storedQuat, pivot);
        xform->addChild(node);

        // Apply semantic coloring FIRST (the visitor rewrites StateGroup
        // pipelines, so this must happen before compile sees the subtree).
        auto colorMap = SemanticColorMap::load(pc.absPath);
        SemanticMaterialVisitor visitor(colorMap);
        xform->accept(visitor);
        AssetContext::MaterialMap childMatMap;
        for (auto& [n, m] : visitor.material_map()) childMatMap[n] = m;
        EASIR_LOG("[EASIR] load_pending_temporary: semantic visitor -> %zu materials\n",
                    childMatMap.size());

        // Collect the child's node short-names so the group manager can be
        // properly initialised. Without this, the Unassigned permanent group
        // is empty and unassign/reassign produces magenta-fallback nodes.
        struct NodeCollect : public vsg::Visitor {
            std::vector<std::string> names;
            void apply(vsg::Node& n) override { n.traverse(*this); }
            void apply(vsg::Group& g) override {
                check(g);
                g.traverse(*this);
            }
            void apply(vsg::MatrixTransform& mt) override {
                check(mt);
                mt.traverse(*this);
            }
            void check(vsg::Object& o) {
                std::string n;
                if (o.getValue("name", n) && !n.empty()) {
                    auto s = SemanticGroupManager::extract_short_name(n);
                    if (std::find(names.begin(), names.end(), s) == names.end())
                        names.push_back(s);
                }
            }
        } nc;
        xform->accept(nc);
        EASIR_LOG("[EASIR] load_pending_temporary: collected %zu node names\n",
                    nc.names.size());

        auto childMgr = std::make_unique<SemanticGroupManager>();
        childMgr->init(nc.names, pc.absPath);
        childMgr->load();  // picks up existing _semantic_map.json if present

        // Attach to the parent's rootTransform — but first wait idle so the
        // scene graph is not being recorded while we mutate it.
        m_viewer->deviceWaitIdle();
        parent->rootTransform->addChild(xform);

        // Compile the (now-rewritten) subtree so Vulkan resources exist
        // before the next frame records it.
        if (m_viewer->compileManager) {
            auto result = m_viewer->compileManager->compile(xform);
            if (result.requiresViewerUpdate()) {
                vsg::updateTasks(m_viewer->recordAndSubmitTasks,
                                 m_viewer->compileManager, result);
            }
            EASIR_LOG("[EASIR] load_pending_temporary: compiled new subtree\n");
        }

        pc.tempAssetId = pc.parentAssetId + "/__pending__";
        pc.tempXform   = xform;
        pc.loaded      = true;

        // Build the AssetContext. We register it in m_assets directly (not via
        // register_asset) so no auto-activation happens — the parent stays
        // active so the user keeps their editing context.
        AssetContext ctx;
        ctx.assetId        = pc.tempAssetId;
        ctx.assetPath      = pc.absPath;
        ctx.rootTransform  = xform;
        ctx.rootNode       = node;
        ctx.groupMgr       = std::move(childMgr);
        ctx.materialMap    = childMatMap;
        ctx.parentAssetId  = pc.parentAssetId;
        ctx.jointName      = "__pending__";   // placeholder; final name set on Confirm
        ctx.localPosition  = pos;
        ctx.localOrientation = pc.storedQuat;
        m_assets[pc.tempAssetId] = std::move(ctx);

        // Now that the child context exists, briefly swap active to it so
        // discover_nodes populates the child's nodePathMap. Then swap back
        // to the parent — switching uses the low-level set_active_asset which
        // only moves the per-asset fields, leaving appearances alone.
        const std::string savedActive = m_activeAssetId;
        set_active_asset(pc.tempAssetId);
        discover_nodes(xform);
        set_material_map(childMatMap);
        set_active_asset(savedActive);

        // Newly-added child is inactive — dim it so it doesn't compete for
        // attention while the user adjusts sliders.
        if (auto* childCtx = asset_by_id(pc.tempAssetId)) {
            apply_inactive_appearance(*childCtx);
        }

        EASIR_LOG("[EASIR] load_pending_temporary: temp context registered id='%s' (active='%s')\n",
                    pc.tempAssetId.c_str(), m_activeAssetId.c_str());
        return true;
    }

    /// Recompose the temp transform's matrix from the current slider values.
    /// Runs each frame while the panel is open — cheap since only a matrix
    /// is written (no compile required).
    void update_pending_transform() {
        if (!m_pendingChild || !m_pendingChild->loaded) return;
        PendingChild& pc = *m_pendingChild;
        if (pc.useEuler) {
            pc.storedQuat = euler_zyx_intrinsic_to_quat(
                vsg::dvec3{pc.eulerDeg[0], pc.eulerDeg[1], pc.eulerDeg[2]});
        }
        const vsg::dvec3 pos{pc.posDeg[0], pc.posDeg[1], pc.posDeg[2]};
        const vsg::dvec3 pivot{pc.pivot[0], pc.pivot[1], pc.pivot[2]};
        pc.tempXform->matrix = pose_to_matrix_d_pivot(pos, pc.storedQuat, pivot);
    }

    /// Commit the pending child: write a ChildAssetRef to the parent's
    /// semantic map, save, rename the temp AssetContext to its final id,
    /// and register a joint binding on the ForwardPass so Phase E-style
    /// state-driven poses can drive it.
    void confirm_pending_child() {
        if (!m_pendingChild || !m_pendingChild->loaded) return;
        PendingChild& pc = *m_pendingChild;
        auto* parent = asset_by_id(pc.parentAssetId);
        if (!parent || !parent->groupMgr) {
            EASIR_LOG("[EASIR] confirm_pending_child: parent '%s' missing\n",
                        pc.parentAssetId.c_str());
            return;
        }

        // Resolve the stored path against the parent JSON directory so we
        // write a relative path when possible.
        std::filesystem::path parentDir = parent->assetPath.parent_path();
        std::error_code ec;
        std::filesystem::path relative =
            std::filesystem::relative(pc.absPath, parentDir, ec);
        std::string writtenPath = (!ec && !relative.empty() &&
                                    relative.native().find(L"..") == std::wstring::npos)
            ? relative.string()
            : pc.absPath.string();

        ChildAssetRef ref;
        ref.assetPath = writtenPath;
        ref.jointName = pc.jointName;
        ref.localPosition    = {pc.posDeg[0], pc.posDeg[1], pc.posDeg[2]};
        ref.localOrientation = {pc.storedQuat.x, pc.storedQuat.y,
                                pc.storedQuat.z, pc.storedQuat.w};
        ref.pivotOffset      = {pc.pivot[0], pc.pivot[1], pc.pivot[2]};
        parent->groupMgr->add_child(ref);
        m_hasUnsavedChanges = true;  // user must click Save to persist

        // Phase L: bindings are owned by the spacecraft TREE root, not the
        // immediate parent (which may itself be a child mid-chain).
        const std::string rootId = top_level_root_id(pc.parentAssetId);
        EASIR_LOG("[EASIR] confirm_pending_child: top='%s' joint='%s' added asset='%s' to '%s' (in-memory, Save required)\n",
                    rootId.c_str(), pc.jointName.c_str(),
                    writtenPath.c_str(),
                    parent->assetPath.filename().string().c_str());

        // Promote the temp AssetContext to its final id.
        const std::string finalId = pc.parentAssetId + "/" + pc.jointName;
        auto it = m_assets.find(pc.tempAssetId);
        if (it != m_assets.end()) {
            AssetContext ctx = std::move(it->second);
            m_assets.erase(it);
            ctx.assetId   = finalId;
            ctx.jointName = pc.jointName;
            m_assets[finalId] = std::move(ctx);
        }
        // Update parent's childAssetIds.
        parent->childAssetIds.push_back(finalId);

        // Register joint binding on the ForwardPass for Phase E-style drives.
        if (m_forwardPass) {
            m_forwardPass->register_joint(
                rootId, pc.jointName, pc.tempXform,
                vsg::dvec3{pc.posDeg[0], pc.posDeg[1], pc.posDeg[2]},
                pc.storedQuat,
                vsg::dvec3{pc.pivot[0], pc.pivot[1], pc.pivot[2]});
        }

        // Apply inactive-gray to the newly-promoted child (it's not the active asset).
        if (auto* newCtx = asset_by_id(finalId)) {
            apply_inactive_appearance(*newCtx);
        }

        m_pendingChild.reset();
    }

    /// Discard the pending child: detach the temp subtree from the parent,
    /// erase the temp AssetContext. No JSON changes.
    void cancel_pending_child() {
        if (!m_pendingChild) return;
        PendingChild& pc = *m_pendingChild;
        EASIR_LOG("[EASIR] cancel_pending_child: removing temp '%s'\n",
                    pc.tempAssetId.c_str());
        if (pc.loaded && pc.tempXform && m_viewer) {
            auto* parent = asset_by_id(pc.parentAssetId);
            if (parent && parent->rootTransform) {
                m_viewer->deviceWaitIdle();
                auto& kids = parent->rootTransform->children;
                kids.erase(
                    std::remove_if(kids.begin(), kids.end(),
                        [&](const vsg::ref_ptr<vsg::Node>& c) {
                            return c.get() == pc.tempXform.get();
                        }),
                    kids.end());
            }
        }
        m_assets.erase(pc.tempAssetId);
        m_pendingChild.reset();
    }

    void draw_articulation_section() {
        if (!ImGui::CollapsingHeader("Articulation",
                                      ImGuiTreeNodeFlags_DefaultOpen)) return;

        auto* a = active_asset();
        if (!a) {
            ImGui::TextDisabled("(no active asset)");
            return;
        }

        // Add Part button — opens the native file picker.
        if (ImGui::Button("+ Add Part")) {
            auto picked = pick_open_file(
                "Pick child asset",
                "Meshes\0*.obj;*.glb;*.gltf\0OBJ\0*.obj\0glTF\0*.glb;*.gltf\0All\0*.*\0\0",
                a->assetPath.parent_path());
            if (picked) {
                PendingChild pc;
                pc.absPath = std::filesystem::weakly_canonical(*picked);
                pc.parentAssetId = a->assetId;
                auto stem = pc.absPath.stem().string();
                // Make an initial joint-name suggestion that's unique within
                // the parent's spacecraft tree (Phase L: per-tree scoping).
                std::string candidate = stem;
                int n = 1;
                while (is_joint_name_taken(candidate, pc.parentAssetId)) {
                    candidate = stem + "_" + std::to_string(++n);
                }
                std::strncpy(pc.jointNameBuf, candidate.c_str(),
                             sizeof(pc.jointNameBuf) - 1);
                pc.jointName = candidate;
                m_pendingChild = std::move(pc);
                if (!load_pending_temporary()) {
                    EASIR_LOG("[EASIR] Add Part: load_pending_temporary failed, discarding\n");
                    m_pendingChild.reset();
                }
            }
        }
        ImGui::SameLine();
        ImGui::TextDisabled("(parent: %s)", a->assetId.c_str());

        // Existing children list with Remove buttons (Phase I wires the action).
        if (a->groupMgr) {
            const auto& children = a->groupMgr->children();
            if (!children.empty()) {
                ImGui::Text("Children (%zu):", children.size());
                for (const auto& cref : children) {
                    ImGui::PushID(cref.jointName.c_str());
                    ImGui::BulletText("%s", cref.jointName.c_str());
                    ImGui::SameLine();
                    if (ImGui::SmallButton("Remove")) {
                        m_pendingRemoveJoint = cref.jointName;
                    }
                    ImGui::PopID();
                }
            }
        }

        // Pending editor panel — floating window while an Add Part flow is in progress.
        draw_pending_child_panel();

        // Remove Part confirmation popup (Phase I).
        draw_remove_part_popup();
    }

    /// Collect the given asset id and all its descendants (via m_assets'
    /// childAssetIds) into `out`. Used by Remove Part to walk a subtree.
    void collect_descendants(const std::string& rootId,
                              std::vector<std::string>& out) const {
        auto it = m_assets.find(rootId);
        if (it == m_assets.end()) return;
        out.push_back(rootId);
        for (const auto& childId : it->second.childAssetIds) {
            collect_descendants(childId, out);
        }
    }

    /// Execute a confirmed Remove Part. Detaches the joint's subtree from
    /// the scene graph, erases the corresponding AssetContext(s), unregisters
    /// every joint binding in the subtree, and removes the ChildAssetRef from
    /// the parent's group manager (in-memory — user must Save to persist).
    void execute_remove_joint(const std::string& parentAssetId,
                               const std::string& jointName) {
        auto* parent = asset_by_id(parentAssetId);
        if (!parent) {
            EASIR_LOG("[EASIR] remove_joint: parent '%s' not found\n",
                        parentAssetId.c_str());
            return;
        }

        // Resolve the spacecraft tree's root once for joint binding lookups.
        // Phase L: ForwardPass bindings are keyed by (root, joint) — a child
        // mid-chain still belongs to the same root that owns the binding.
        const std::string rootId = top_level_root_id(parentAssetId);

        // The composite id is how we find the child AssetContext.
        const std::string childId = parentAssetId + "/" + jointName;
        auto* childCtx = asset_by_id(childId);
        if (!childCtx) {
            // Even if the runtime context is missing (e.g., load failure or
            // stale JSON entry), still remove from the parent's group manager.
            EASIR_LOG("[EASIR] remove_joint: top='%s' no runtime context for '%s'; pruning JSON entry only\n",
                        rootId.c_str(), childId.c_str());
            parent->groupMgr->remove_child(jointName);
            m_hasUnsavedChanges = true;
            return;
        }

        // Collect descendant ids (including the target) before mutating.
        std::vector<std::string> victims;
        collect_descendants(childId, victims);
        EASIR_LOG("[EASIR] remove_joint: top='%s' joint='%s' detaches %zu asset(s)\n",
                    rootId.c_str(), jointName.c_str(), victims.size());
        for (const auto& v : victims) {
            EASIR_LOG("[EASIR] remove_joint:   victim 'top=%s id=%s'\n",
                        rootId.c_str(), v.c_str());
        }

        // Wait for GPU idle before mutating the scene graph.
        if (m_viewer) m_viewer->deviceWaitIdle();

        // Detach the child transform from its parent's rootTransform.
        if (parent->rootTransform && childCtx->rootTransform) {
            auto& kids = parent->rootTransform->children;
            vsg::Node* target = childCtx->rootTransform.get();
            size_t before = kids.size();
            kids.erase(
                std::remove_if(kids.begin(), kids.end(),
                    [&](const vsg::ref_ptr<vsg::Node>& c) {
                        return c.get() == target;
                    }),
                kids.end());
            EASIR_LOG("[EASIR] remove_joint: parent children %zu -> %zu\n",
                        before, kids.size());
        }

        // Unregister ForwardPass joint bindings for every victim whose
        // jointName matches, and erase AssetContexts. All victims share the
        // same `rootId` since they're descendants of the parent we anchored.
        bool activeWasInSubtree = false;
        for (const auto& v : victims) {
            auto it = m_assets.find(v);
            if (it == m_assets.end()) continue;
            const std::string vJoint = it->second.jointName;
            if (!vJoint.empty() && m_forwardPass) {
                m_forwardPass->unregister_joint(rootId, vJoint);
            }
            if (v == m_activeAssetId) activeWasInSubtree = true;
            m_assets.erase(it);
        }

        // Remove the child entry from the parent's childAssetIds list.
        parent->childAssetIds.erase(
            std::remove(parent->childAssetIds.begin(),
                        parent->childAssetIds.end(), childId),
            parent->childAssetIds.end());

        // Prune the ChildAssetRef from the parent's group manager (in-memory;
        // Save persists to disk per Phase H convention).
        parent->groupMgr->remove_child(jointName);
        m_hasUnsavedChanges = true;

        // If the active asset was inside the removed subtree, fall back to
        // the parent so the editor has a valid focus.
        if (activeWasInSubtree) {
            EASIR_LOG("[EASIR] remove_joint: active was in removed subtree; switching to parent '%s'\n",
                        parentAssetId.c_str());
            // Low-level swap — appearances handled below.
            m_activeAssetId.clear();  // force switch via set_active_asset
            set_active_asset(parentAssetId);
            restore_active_appearance();
            remove_highlight();
            m_selectedNodeName.clear();
            m_selectedShortName.clear();
            m_hasSelection = false;
        }

        EASIR_LOG("[EASIR] remove_joint: done (unsaved; click Save to persist)\n");
    }

    /// Draw the Remove-part confirmation popup when a Remove button is
    /// pending. Phase I: only modal shown for the currently-active asset's
    /// children — we carry parentAssetId alongside the joint name to stay
    /// robust to dropdown switches while the popup is open.
    void draw_remove_part_popup() {
        if (m_pendingRemoveJoint.empty()) return;
        auto* parent = active_asset();
        if (!parent) {
            m_pendingRemoveJoint.clear();
            return;
        }

        if (!ImGui::IsPopupOpen("Remove Part?")) ImGui::OpenPopup("Remove Part?");
        if (ImGui::BeginPopupModal("Remove Part?", nullptr,
                                    ImGuiWindowFlags_AlwaysAutoResize)) {
            // Compute descendant count live (in case something changed).
            const std::string childId = parent->assetId + "/" + m_pendingRemoveJoint;
            std::vector<std::string> victims;
            collect_descendants(childId, victims);
            const size_t descendantCount = victims.empty() ? 0 : victims.size() - 1;

            ImGui::Text("Remove joint '%s' from '%s'?",
                        m_pendingRemoveJoint.c_str(), parent->assetId.c_str());
            if (descendantCount > 0) {
                ImGui::TextColored(ImVec4(1, 0.8f, 0.4f, 1),
                    "%zu descendant(s) will also be detached.", descendantCount);
            }
            ImGui::TextDisabled("(in-memory; Save to persist)");
            ImGui::Separator();

            if (ImGui::Button("Remove", ImVec2(100, 0))) {
                execute_remove_joint(parent->assetId, m_pendingRemoveJoint);
                m_pendingRemoveJoint.clear();
                ImGui::CloseCurrentPopup();
            }
            ImGui::SameLine();
            if (ImGui::Button("Cancel", ImVec2(100, 0))) {
                m_pendingRemoveJoint.clear();
                ImGui::CloseCurrentPopup();
            }
            ImGui::EndPopup();
        }
    }

    void draw_pending_child_panel() {
        if (!m_pendingChild) return;
        PendingChild& pc = *m_pendingChild;

        ImGui::SetNextWindowSize(ImVec2(360, 0), ImGuiCond_Appearing);
        ImGui::Begin("New Part", nullptr, ImGuiWindowFlags_AlwaysAutoResize);

        ImGui::Text("File:   %s", pc.absPath.filename().string().c_str());
        ImGui::Text("Parent: %s", pc.parentAssetId.c_str());
        ImGui::Separator();

        // Joint name input.
        if (ImGui::InputText("Joint name", pc.jointNameBuf, sizeof(pc.jointNameBuf))) {
            pc.jointName = pc.jointNameBuf;
        }
        const bool nameEmpty = pc.jointName.empty();
        // Phase L: tree-scoped collision check. The temp AssetContext uses
        // the placeholder jointName "__pending__", so it never false-positives
        // unless the user literally types "__pending__" (acceptable edge case).
        // is_joint_name_taken walks the tree containing pc.parentAssetId.
        const bool nameTaken = !nameEmpty &&
            is_joint_name_taken(pc.jointName, pc.parentAssetId);
        if (nameEmpty)
            ImGui::TextColored(ImVec4(1, 0.5f, 0.5f, 1), "Joint name required");
        else if (nameTaken)
            ImGui::TextColored(ImVec4(1, 0.5f, 0.5f, 1), "Joint name already in use in this spacecraft");

        ImGui::Separator();
        bool changed = false;
        changed |= ImGui::DragFloat3("Local pos",   pc.posDeg, 0.02f);
        changed |= ImGui::DragFloat3("Pivot offset", pc.pivot, 0.02f);

        ImGui::Checkbox("Edit as Euler (ZYX intrinsic, deg — UI only)", &pc.useEuler);
        if (pc.useEuler) {
            changed |= ImGui::DragFloat3("Euler X/Y/Z", pc.eulerDeg, 0.5f);
        } else {
            ImGui::Text("Quat: %.3f %.3f %.3f %.3f",
                        pc.storedQuat.x, pc.storedQuat.y, pc.storedQuat.z, pc.storedQuat.w);
        }

        if (changed) update_pending_transform();

        ImGui::Separator();
        const bool canConfirm = !nameEmpty && !nameTaken;
        if (!canConfirm) ImGui::BeginDisabled();
        if (ImGui::Button("Confirm")) {
            confirm_pending_child();
            ImGui::End();
            return;
        }
        if (!canConfirm) ImGui::EndDisabled();
        ImGui::SameLine();
        if (ImGui::Button("Cancel")) {
            cancel_pending_child();
            ImGui::End();
            return;
        }

        ImGui::End();
    }

    // ---------------------------------------------------------------
    //  GUI: Joint test panel — interactive joint driver
    //  Writes directly into EasirState.scene_objects[...].joints so that
    //  ForwardPass::execute() picks up the override each frame. Logs once
    //  on state transitions to keep the log readable.
    //
    //  Phase L: lookups now require BOTH the top-level id and the joint
    //  name. Two spacecraft may legally share a joint name; the panel's
    //  Top-level id field disambiguates.
    // ---------------------------------------------------------------

    /// Refresh the captured home pose for the current (top, joint) pair
    /// from the ForwardPass binding registry. Called whenever the target
    /// joint name or top-level id changes, or when the panel is enabled.
    void joint_test_capture_home() {
        m_jointTestHomePos  = {0, 0, 0};
        m_jointTestHomeQuat = {0, 0, 0, 1};
        m_jointTestCapturedFor = m_jointTestName;
        if (!m_forwardPass) return;
        const auto* b = m_forwardPass->joint_for(
            std::string(m_jointTestTopId), std::string(m_jointTestName));
        if (!b) {
            EASIR_LOG("[EASIR] joint-test: capture_home: no binding for top='%s' joint='%s'\n",
                        m_jointTestTopId, m_jointTestName);
            return;
        }
        m_jointTestHomePos  = b->homePos;
        m_jointTestHomeQuat = b->homeQuat;
        // Pre-populate the position sliders with home so enabling the
        // override produces no snap.
        m_jointTestPos[0] = static_cast<float>(m_jointTestHomePos.x);
        m_jointTestPos[1] = static_cast<float>(m_jointTestHomePos.y);
        m_jointTestPos[2] = static_cast<float>(m_jointTestHomePos.z);
        EASIR_LOG("[EASIR] joint-test: captured home for top='%s' joint='%s' pos=(%f,%f,%f) quat=(%f,%f,%f,%f)\n",
                    m_jointTestTopId, m_jointTestName,
                    m_jointTestHomePos.x, m_jointTestHomePos.y, m_jointTestHomePos.z,
                    m_jointTestHomeQuat.x, m_jointTestHomeQuat.y,
                    m_jointTestHomeQuat.z, m_jointTestHomeQuat.w);
    }

    void draw_joint_test_panel() {
        if (!ImGui::CollapsingHeader("Joint Test",
                                      ImGuiTreeNodeFlags_DefaultOpen)) return;

        if (!m_testStatePtr) {
            ImGui::TextDisabled("(state pointer not wired)");
            return;
        }

        bool prevEnabled = m_jointTestEnabled;
        ImGui::Checkbox("Drive joint from state", &m_jointTestEnabled);
        if (m_jointTestEnabled != prevEnabled) {
            EASIR_LOG("[EASIR] joint-test: top='%s' joint='%s' %s\n",
                        m_jointTestTopId, m_jointTestName,
                        m_jointTestEnabled ? "ENABLED" : "disabled");
            if (m_jointTestEnabled) {
                // Snap-free start: grab current home and clear any stale deltas.
                joint_test_capture_home();
                m_jointTestAngleDeg = 0.0f;
                m_jointTestSweepTime = 0.0f;
            }
        }

        // Re-capture if the user types a new joint name OR a new top-level id.
        ImGui::InputText("Joint name", m_jointTestName, sizeof(m_jointTestName));
        if (m_jointTestCapturedFor != m_jointTestName) joint_test_capture_home();
        std::string prevTop(m_jointTestTopId);
        ImGui::InputText("Top-level id", m_jointTestTopId, sizeof(m_jointTestTopId));
        if (prevTop != m_jointTestTopId) joint_test_capture_home();

        const char* axes[] = {"X", "Y", "Z"};
        ImGui::Combo("Delta axis", &m_jointTestAxis, axes, 3);

        ImGui::SliderFloat("Delta angle (deg)", &m_jointTestAngleDeg, -180.0f, 180.0f);
        ImGui::Checkbox("Sweep", &m_jointTestSweep);
        ImGui::SameLine();
        if (ImGui::Button("Reset to home")) {
            m_jointTestAngleDeg = 0.0f;
            m_jointTestSweepTime = 0.0f;
            m_jointTestPos[0] = static_cast<float>(m_jointTestHomePos.x);
            m_jointTestPos[1] = static_cast<float>(m_jointTestHomePos.y);
            m_jointTestPos[2] = static_cast<float>(m_jointTestHomePos.z);
            EASIR_LOG("[EASIR] joint-test: reset to home\n");
        }

        ImGui::Checkbox("Override position", &m_jointTestOverridePos);
        if (m_jointTestOverridePos) {
            ImGui::DragFloat3("Position", m_jointTestPos, 0.05f, -1e6f, 1e6f);
        }

        if (!m_jointTestEnabled) {
            // Ensure we don't leave stale overrides in state when the user
            // disables the panel. Remove the entry so home pose takes over.
            auto* so = find_or_make_scene_object(m_jointTestTopId);
            if (so) {
                auto it = so->joints.find(m_jointTestName);
                if (it != so->joints.end()) {
                    EASIR_LOG("[EASIR] joint-test: clearing override top='%s' joint='%s'\n",
                                m_jointTestTopId, m_jointTestName);
                    so->joints.erase(it);
                }
            }
            return;
        }

        // Sweep mode: drive angle with a slow sine (~4s period, ±120°).
        if (m_jointTestSweep) {
            m_jointTestSweepTime += ImGui::GetIO().DeltaTime;
            m_jointTestAngleDeg = 120.0f *
                std::sin(m_jointTestSweepTime * 1.5f);
        }

        // Compose DELTA rotation around the chosen axis, then pre-multiply
        // by the captured home quaternion so delta=0 produces exactly home.
        const double a = m_jointTestAngleDeg * 3.14159265358979323846 / 180.0;
        const double s = std::sin(a * 0.5);
        const double c = std::cos(a * 0.5);
        vsg::dquat qDelta{0.0, 0.0, 0.0, 1.0};
        if (m_jointTestAxis == 0) qDelta = {s, 0.0, 0.0, c};
        else if (m_jointTestAxis == 1) qDelta = {0.0, s, 0.0, c};
        else                            qDelta = {0.0, 0.0, s, c};

        // q = home * delta  (apply delta in home's local frame)
        const vsg::dquat& h = m_jointTestHomeQuat;
        vsg::dquat qOut;
        qOut.w = h.w*qDelta.w - h.x*qDelta.x - h.y*qDelta.y - h.z*qDelta.z;
        qOut.x = h.w*qDelta.x + h.x*qDelta.w + h.y*qDelta.z - h.z*qDelta.y;
        qOut.y = h.w*qDelta.y - h.x*qDelta.z + h.y*qDelta.w + h.z*qDelta.x;
        qOut.z = h.w*qDelta.z + h.x*qDelta.y - h.y*qDelta.x + h.z*qDelta.w;

        auto* so = find_or_make_scene_object(m_jointTestTopId);
        if (!so) return;

        JointState js;
        js.orientation = std::array<double, 4>{qOut.x, qOut.y, qOut.z, qOut.w};
        if (m_jointTestOverridePos) {
            js.position = std::array<double, 3>{
                m_jointTestPos[0],
                m_jointTestPos[1],
                m_jointTestPos[2]
            };
        }
        so->joints[m_jointTestName] = js;

        // Readback display.
        ImGui::Text("Home pos:  %.2f %.2f %.2f",
                    m_jointTestHomePos.x, m_jointTestHomePos.y, m_jointTestHomePos.z);
        ImGui::Text("Home quat: %.3f %.3f %.3f %.3f",
                    m_jointTestHomeQuat.x, m_jointTestHomeQuat.y,
                    m_jointTestHomeQuat.z, m_jointTestHomeQuat.w);
        ImGui::Text("Out quat:  %.3f %.3f %.3f %.3f",
                    qOut.x, qOut.y, qOut.z, qOut.w);
    }

    /// Locate (or create) a SceneObjectState in the test state by id.
    SceneObjectState* find_or_make_scene_object(const std::string& id) {
        if (!m_testStatePtr) return nullptr;
        for (auto& so : m_testStatePtr->scene_objects) {
            if (so.id == id) return &so;
        }
        SceneObjectState fresh;
        fresh.id = id;
        m_testStatePtr->scene_objects.push_back(std::move(fresh));
        EASIR_LOG("[EASIR] joint-test: created scene_object entry '%s'\n", id.c_str());
        return &m_testStatePtr->scene_objects.back();
    }

    // ---------------------------------------------------------------
    //  GUI: Missing file popup (Phase D scaffold; Phase H wires Locate)
    // ---------------------------------------------------------------

    void draw_missing_files_popup() {
        if (m_missingFilesOpen && !ImGui::IsPopupOpen("Missing Asset")) {
            ImGui::OpenPopup("Missing Asset");
        }
        if (!m_missingFilesOpen) return;

        ImGui::SetNextWindowSize(ImVec2(560, 0), ImGuiCond_Appearing);
        if (ImGui::BeginPopupModal("Missing Asset", nullptr, ImGuiWindowFlags_AlwaysAutoResize)) {
            if (m_missingFileIndex >= m_missingFiles.size()) {
                ImGui::CloseCurrentPopup();
                m_missingFilesOpen = false;
                m_missingFiles.clear();
                m_missingFileIndex = 0;
                ImGui::EndPopup();
                return;
            }

            const auto& entry = m_missingFiles[m_missingFileIndex];
            ImGui::Text("Entry %zu / %zu",
                        m_missingFileIndex + 1, m_missingFiles.size());
            ImGui::Separator();
            ImGui::TextWrapped("Path:   %s", entry.expectedPath.string().c_str());
            ImGui::TextWrapped("Parent: %s", entry.parentAssetId.c_str());
            ImGui::TextWrapped("Joint:  %s", entry.jointName.c_str());
            ImGui::Separator();

            if (ImGui::Button("Locate...")) {
                auto* parent = asset_by_id(entry.parentAssetId);
                std::filesystem::path startDir =
                    parent ? parent->assetPath.parent_path()
                           : entry.expectedPath.parent_path();
                auto picked = pick_open_file(
                    "Locate missing asset",
                    "Meshes\0*.obj;*.glb;*.gltf\0All\0*.*\0\0",
                    startDir);
                if (picked) {
                    auto canon = std::filesystem::weakly_canonical(*picked);
                    EASIR_LOG("[EASIR] missing-asset: Locate -> '%s' for joint '%s' in '%s'\n",
                                canon.string().c_str(),
                                entry.jointName.c_str(),
                                entry.parentAssetId.c_str());
                    if (parent && parent->groupMgr) {
                        // Update the ChildAssetRef in place. Store relative
                        // path when the picked file lives under the parent's
                        // JSON directory (mirrors Add Part's logic).
                        std::filesystem::path parentDir =
                            parent->assetPath.parent_path();
                        std::error_code ec;
                        auto rel = std::filesystem::relative(canon, parentDir, ec);
                        std::string newPath = (!ec && !rel.empty() &&
                                                rel.native().find(L"..") == std::wstring::npos)
                            ? rel.string()
                            : canon.string();
                        auto& refs = parent->groupMgr->children();
                        bool updated = false;
                        for (auto& r : refs) {
                            if (r.jointName == entry.jointName) {
                                EASIR_LOG("[EASIR] missing-asset: path '%s' -> '%s'\n",
                                            r.assetPath.c_str(), newPath.c_str());
                                r.assetPath = newPath;
                                updated = true;
                                break;
                            }
                        }
                        if (updated) {
                            m_hasUnsavedChanges = true;
                            // Surface a follow-up modal so the user knows
                            // they need to Save + restart to pick up the
                            // relocated subtree.
                            m_locateRestartMessage =
                                "Path updated for joint '" + entry.jointName +
                                "'.\n\nClick Save in the main editor, then close "
                                "and relaunch easir_app to load the relocated "
                                "subtree. The child will not appear until then.";
                            m_locateRestartOpen = true;
                        }
                        EASIR_LOG("[EASIR] missing-asset: path fix recorded; restart editor to reload subtree\n");
                    }
                }
                ++m_missingFileIndex;
            }
            ImGui::SameLine();
            if (ImGui::Button("Remove from parent")) {
                auto* parent = asset_by_id(entry.parentAssetId);
                if (parent && parent->groupMgr) {
                    bool ok = parent->groupMgr->remove_child(entry.jointName);
                    if (ok) m_hasUnsavedChanges = true;
                    EASIR_LOG("[EASIR] missing-asset: removed joint '%s' from parent '%s' (%s)\n",
                                entry.jointName.c_str(),
                                entry.parentAssetId.c_str(),
                                ok ? "ok" : "joint not found");
                } else {
                    EASIR_LOG("[EASIR] missing-asset: parent '%s' not found\n",
                                entry.parentAssetId.c_str());
                }
                ++m_missingFileIndex;
            }
            ImGui::SameLine();
            if (ImGui::Button("Cancel (leave as-is)")) {
                EASIR_LOG("[EASIR] missing-asset: cancelled for joint '%s'\n",
                            entry.jointName.c_str());
                ++m_missingFileIndex;
            }

            if (m_missingFileIndex >= m_missingFiles.size()) {
                ImGui::CloseCurrentPopup();
                m_missingFilesOpen = false;
                m_missingFiles.clear();
                m_missingFileIndex = 0;
            }
            ImGui::EndPopup();
        }
    }

    /// Follow-up "Restart Required" modal shown after a successful Locate
    /// action in the missing-file flow. Explains that a restart is needed
    /// because we don't live-reload the subtree from here.
    void draw_locate_restart_popup() {
        if (m_locateRestartOpen && !ImGui::IsPopupOpen("Restart Required")) {
            ImGui::OpenPopup("Restart Required");
        }
        if (!m_locateRestartOpen) return;

        ImGui::SetNextWindowSize(ImVec2(480, 0), ImGuiCond_Appearing);
        if (ImGui::BeginPopupModal("Restart Required", nullptr,
                                    ImGuiWindowFlags_AlwaysAutoResize)) {
            ImGui::TextWrapped("%s", m_locateRestartMessage.c_str());
            ImGui::Separator();
            if (ImGui::Button("OK", ImVec2(120, 0))) {
                m_locateRestartOpen = false;
                m_locateRestartMessage.clear();
                ImGui::CloseCurrentPopup();
            }
            ImGui::EndPopup();
        }
    }

    // ---------------------------------------------------------------
    //  GUI: Save / Load buttons
    // ---------------------------------------------------------------

    void draw_save_load_buttons() {
        if (!m_groupMgr) return;

        // Save button — with unsaved indicator.
        std::string saveLabel = m_hasUnsavedChanges ? "Save *" : "Save";
        if (ImGui::Button(saveLabel.c_str())) {
            if (m_groupMgr->save_file_exists()) {
                ImGui::OpenPopup("Confirm Save");
            } else {
                m_groupMgr->save();
                m_hasUnsavedChanges = false;
            }
        }
        ImGui::SameLine();
        if (ImGui::Button("Load")) {
            if (m_groupMgr->load()) {
                m_needsSceneColorUpdate = true;
                m_hasUnsavedChanges = false;
            }
        }

        // Confirmation modal.
        if (ImGui::BeginPopupModal("Confirm Save", nullptr, ImGuiWindowFlags_AlwaysAutoResize)) {
            auto path = m_groupMgr->save_path();
            ImGui::Text("Overwrite %s?", path.filename().string().c_str());
            ImGui::Separator();
            if (ImGui::Button("Yes", ImVec2(80, 0))) {
                m_groupMgr->save();
                m_hasUnsavedChanges = false;
                ImGui::CloseCurrentPopup();
            }
            ImGui::SameLine();
            if (ImGui::Button("No", ImVec2(80, 0))) {
                ImGui::CloseCurrentPopup();
            }
            ImGui::EndPopup();
        }
    }

    // ---------------------------------------------------------------
    //  GUI: Selection mode toggle
    // ---------------------------------------------------------------

    void draw_selection_mode() {
        int mode = static_cast<int>(m_selectionMode);
        ImGui::Text("Selection Mode:");
        if (ImGui::RadioButton("Node", &mode, 0)) {
            m_selectionMode = SelectionMode::Node;
            // Clear any flood-fill state when switching back to node mode.
            if (m_floodFill) {
                remove_flood_fill_highlight();
                m_floodFill.reset();
            }
        }
        ImGui::SameLine();
        if (ImGui::RadioButton("Triangle", &mode, 1)) {
            m_selectionMode = SelectionMode::Triangle;
            // Clear node selection when switching to triangle mode.
            remove_highlight();
            m_selectedNodeName.clear();
            m_selectedShortName.clear();
            m_hasSelection = false;
        }

        if (m_selectionMode == SelectionMode::Triangle) {
            float prevAngle = m_floodFillAngleDeg;
            ImGui::SliderFloat("Angle Threshold", &m_floodFillAngleDeg, 0.0f, 90.0f, "%.1f deg");
            // Re-run flood-fill when threshold changes.
            if (m_floodFill && std::abs(m_floodFillAngleDeg - prevAngle) > 0.01f) {
                rerun_flood_fill();
            }
        }
    }

    // ---------------------------------------------------------------
    //  GUI: Selection info
    // ---------------------------------------------------------------

    void draw_selection_info() {
        // Triangle selection mode: show flood-fill info.
        if (m_selectionMode == SelectionMode::Triangle) {
            if (m_floodFill && !m_floodFill->selectedFaces.empty()) {
                ImGui::TextColored(ImVec4(1.0f, 0.4f, 0.4f, 1.0f), "Triangle Selection:");
                ImGui::Text("%zu faces from '%s'",
                            m_floodFill->selectedFaces.size(),
                            m_floodFill->parentNodeName.c_str());
                if (m_groupMgr && ImGui::Button("Create Custom Node")) {
                    ImGui::OpenPopup("Name Custom Node");
                }
                ImGui::SameLine();
                if (ImGui::Button("Clear Selection")) {
                    remove_flood_fill_highlight();
                    m_floodFill.reset();
                    m_hasSelection = false;
                }
                // Custom node naming popup.
                if (ImGui::BeginPopupModal("Name Custom Node", nullptr,
                                            ImGuiWindowFlags_AlwaysAutoResize)) {
                    static char nameBuf[128] = "";
                    if (nameBuf[0] == '\0') {
                        snprintf(nameBuf, sizeof(nameBuf), "custom_%d",
                                 static_cast<int>(m_groupMgr->custom_nodes().size() + 1));
                    }
                    ImGui::InputText("Name", nameBuf, sizeof(nameBuf));
                    if (ImGui::Button("Create")) {
                        std::vector<uint32_t> faces(m_floodFill->selectedFaces.begin(),
                                                     m_floodFill->selectedFaces.end());
                        std::string userName(nameBuf);
                        auto createdName = m_groupMgr->create_custom_node(
                            m_floodFill->parentNodeName, faces, userName);
                        run_draw_call_split();
                        m_needsSceneColorUpdate = true;
                        m_hasUnsavedChanges = true;
                        remove_flood_fill_highlight();
                        m_floodFill.reset();
                        nameBuf[0] = '\0';
                        ImGui::CloseCurrentPopup();
                        // Auto-select the newly created custom node.
                        select_custom_node_by_name(createdName);
                    }
                    ImGui::SameLine();
                    if (ImGui::Button("Cancel")) {
                        nameBuf[0] = '\0';
                        ImGui::CloseCurrentPopup();
                    }
                    ImGui::EndPopup();
                }
            } else {
                ImGui::TextColored(ImVec4(0.5f, 0.5f, 0.5f, 1.0f), "No selection");
                ImGui::Text("Left-click to flood-fill select.");
            }
            return;
        }

        // Node selection mode: existing behavior.
        if (m_hasSelection) {
            ImGui::TextColored(ImVec4(1.0f, 0.4f, 0.4f, 1.0f), "Selected:");
            ImGui::TextWrapped("%s", m_selectedShortName.c_str());

            int currentGid = -1;
            if (m_groupMgr) {
                currentGid = m_groupMgr->find_node_group(m_selectedShortName);
                auto* grp = m_groupMgr->group_by_id(currentGid);
                if (grp) {
                    ImGui::Text("Group: %s", grp->name.c_str());
                }
            }

            if (ImGui::Button("Deselect")) {
                remove_highlight();
                m_selectedNodeName.clear();
                m_selectedShortName.clear();
                m_hasSelection = false;
            }
            // Unassign: move the selected node back to the permanent Unassigned group.
            // Only show when it's currently in a non-permanent group.
            if (m_groupMgr && currentGid > 0) {
                ImGui::SameLine();
                if (ImGui::Button("Unassign")) {
                    EASIR_LOG("[EASIR] Unassign '%s' (from group id=%d) — "
                                "isCustom=%d\n",
                                m_selectedShortName.c_str(), currentGid,
                                m_groupMgr->is_custom_node(m_selectedShortName) ? 1 : 0);
                    m_groupMgr->assign_node(m_selectedShortName, 0);  // 0 = Unassigned
                    m_needsSceneColorUpdate = true;
                    m_hasUnsavedChanges = true;
                    EASIR_LOG("[EASIR] Unassign done, needsColorUpdate set\n");
                }
            }
            // Delete: only for custom nodes — opens the same confirmation popup
            // as the group list's X button.
            if (m_groupMgr && m_groupMgr->is_custom_node(m_selectedShortName)) {
                ImGui::SameLine();
                if (ImGui::Button("Delete")) {
                    m_pendingDeleteCustomNode = m_selectedShortName;
                }
            }
        } else {
            ImGui::TextColored(ImVec4(0.5f, 0.5f, 0.5f, 1.0f), "No selection");
            ImGui::Text("Left-click a node in the viewport.");
        }
    }

    // ---------------------------------------------------------------
    //  GUI: Group list
    // ---------------------------------------------------------------

    void draw_group_list() {
        if (!m_groupMgr) {
            ImGui::Text("No group manager.");
            return;
        }

        // Add Group button.
        if (ImGui::Button("+ Add Group")) {
            // Generate a unique default name.
            int idx = static_cast<int>(m_groupMgr->groups().size());
            std::string name = "Group " + std::to_string(idx);

            // Random-ish color based on group count.
            float hue = std::fmod(idx * 0.618033988749895f, 1.0f);
            float r, g, b;
            ImGui::ColorConvertHSVtoRGB(hue, 0.7f, 0.9f, r, g, b);
            m_groupMgr->add_group(name, {r, g, b});
        }

        ImGui::Spacing();

        m_hoveredGroupId = -1;  // Reset; will be set if mouse hovers a group row.
        m_hoveredNodeName.clear();  // Reset; set if mouse hovers a specific node.

        for (auto& group : m_groupMgr->groups()) {
            ImGui::PushID(group.id);

            // Color swatch.
            ImVec4 col;
            if (group.permanent) {
                col = ImVec4(0.5f, 0.5f, 0.5f, 1.0f);
            } else {
                col = ImVec4(group.color[0], group.color[1], group.color[2], 1.0f);
            }
            ImGui::ColorButton("##color", col, ImGuiColorEditFlags_NoTooltip, ImVec2(14, 14));
            bool rowHovered = ImGui::IsItemHovered();
            ImGui::SameLine();

            // Group name + node count (as collapsible tree node).
            char label[256];
            std::snprintf(label, sizeof(label), "%s (%zu nodes)",
                          group.name.c_str(), group.nodes.size());

            bool open = ImGui::TreeNode("##tree", "%s", label);
            rowHovered = rowHovered || ImGui::IsItemHovered();

            // Buttons on the same line (only for non-permanent groups).
            if (!group.permanent) {
                ImGui::SameLine();

                // Assign button (only enabled when something is selected).
                bool canAssign = m_hasSelection && !m_selectedShortName.empty();
                if (!canAssign) ImGui::BeginDisabled();
                if (ImGui::SmallButton("Assign")) {
                    m_groupMgr->assign_node(m_selectedShortName, group.id);
                    m_needsSceneColorUpdate = true; m_hasUnsavedChanges = true;
                }
                rowHovered = rowHovered || ImGui::IsItemHovered();
                if (!canAssign) ImGui::EndDisabled();

                ImGui::SameLine();

                // Settings button (color picker + rename).
                if (ImGui::SmallButton("Edit")) {
                    if (m_editingGroupId == group.id) {
                        m_editingGroupId = -1;  // Toggle off.
                    } else {
                        m_editingGroupId = group.id;
                        std::strncpy(m_editNameBuf, group.name.c_str(), sizeof(m_editNameBuf) - 1);
                        m_editNameBuf[sizeof(m_editNameBuf) - 1] = '\0';
                    }
                }
                rowHovered = rowHovered || ImGui::IsItemHovered();

                ImGui::SameLine();

                // Delete button — sets flag for confirmation popup (rendered outside loop).
                if (ImGui::SmallButton("X")) {
                    m_pendingDeleteGroupId = group.id;
                }
            }

            // Set hovered group if any widget on this row is hovered.
            if (rowHovered) {
                m_hoveredGroupId = group.id;
            }

            // Inline edit panel (rename + color picker).
            if (m_editingGroupId == group.id) {
                ImGui::Indent();
                ImGui::InputText("Name", m_editNameBuf, sizeof(m_editNameBuf));
                if (ImGui::IsItemDeactivatedAfterEdit()) {
                    group.name = m_editNameBuf;
                }
                if (ImGui::ColorEdit3("Color", group.color.data())) {
                    m_needsSceneColorUpdate = true; m_hasUnsavedChanges = true;
                }
                ImGui::Unindent();
            }

            // Expanded node list — clickable to select in viewport.
            if (open) {
                // Copy node list since deletion may modify it.
                auto nodesCopy = group.nodes;
                for (const auto& nodeName : nodesCopy) {
                    ImGui::PushID(nodeName.c_str());
                    bool isCustom = m_groupMgr && m_groupMgr->is_custom_node(nodeName);
                    std::string nodeLabel = isCustom ? ("[C] " + nodeName) : nodeName;
                    // Delete button for custom nodes — sets flag for confirmation popup.
                    if (isCustom) {
                        if (ImGui::SmallButton("X")) {
                            m_pendingDeleteCustomNode = nodeName;
                        }
                        ImGui::SameLine();
                    }
                    if (ImGui::Selectable(nodeLabel.c_str(),
                                          m_hasSelection && m_selectedShortName == nodeName)) {
                        // Select this node in the viewport.
                        if (isCustom)
                            select_custom_node_by_name(nodeName);
                        else
                            select_node_by_name(nodeName);
                    }
                    // Hover over a specific node name highlights just that node.
                    if (ImGui::IsItemHovered()) {
                        m_hoveredNodeName = nodeName;
                    }
                    ImGui::PopID();
                }
                ImGui::TreePop();
            }

            ImGui::PopID();
        }

        // Group delete confirmation popup (rendered outside the group loop).
        if (m_pendingDeleteGroupId >= 0) {
            ImGui::OpenPopup("Delete Group?");
        }
        if (ImGui::BeginPopupModal("Delete Group?", nullptr,
                                    ImGuiWindowFlags_AlwaysAutoResize)) {
            auto* grp = m_groupMgr->group_by_id(m_pendingDeleteGroupId);
            if (grp) {
                ImGui::Text("Delete group '%s'?", grp->name.c_str());
                ImGui::Text("%zu nodes will move to Unassigned.", grp->nodes.size());
            }
            ImGui::Spacing();
            if (ImGui::Button("Delete", ImVec2(80, 0))) {
                if (m_editingGroupId == m_pendingDeleteGroupId) m_editingGroupId = -1;
                m_groupMgr->delete_group(m_pendingDeleteGroupId);
                m_needsSceneColorUpdate = true;
                m_hasUnsavedChanges = true;
                m_pendingDeleteGroupId = -1;
                ImGui::CloseCurrentPopup();
            }
            ImGui::SameLine();
            if (ImGui::Button("Cancel", ImVec2(80, 0))) {
                m_pendingDeleteGroupId = -1;
                ImGui::CloseCurrentPopup();
            }
            ImGui::EndPopup();
        }

        // Custom node delete confirmation popup (rendered outside all loops).
        if (!m_pendingDeleteCustomNode.empty()) {
            ImGui::OpenPopup("Delete Custom Node?");
        }
        if (ImGui::BeginPopupModal("Delete Custom Node?", nullptr,
                                    ImGuiWindowFlags_AlwaysAutoResize)) {
            ImGui::Text("Delete custom node '%s'?", m_pendingDeleteCustomNode.c_str());
            ImGui::Text("Its faces will return to the parent node.");
            ImGui::Spacing();
            if (ImGui::Button("Delete", ImVec2(80, 0))) {
                m_groupMgr->delete_custom_node(m_pendingDeleteCustomNode);
                run_draw_call_split();
                m_needsSceneColorUpdate = true;
                m_hasUnsavedChanges = true;
                m_pendingDeleteCustomNode.clear();
                ImGui::CloseCurrentPopup();
            }
            ImGui::SameLine();
            if (ImGui::Button("Cancel", ImVec2(80, 0))) {
                m_pendingDeleteCustomNode.clear();
                ImGui::CloseCurrentPopup();
            }
            ImGui::EndPopup();
        }
    }

    // ---------------------------------------------------------------
    //  GUI: Controls help
    // ---------------------------------------------------------------

    void draw_controls_help() {
        if (ImGui::CollapsingHeader("Controls")) {
            ImGui::BulletText("Left-click: select node");
            ImGui::BulletText("Right-drag: orbit");
            ImGui::BulletText("Middle-drag: pan");
            ImGui::BulletText("Scroll: zoom");
            ImGui::BulletText("ESC / close window: exit");
        }
    }

    // ---------------------------------------------------------------
    //  Hover highlight — softer wireframe for all nodes in a group
    // ---------------------------------------------------------------

    void update_hover_highlight() {
        if (m_reviewMode) {
            // Ensure no stale highlight lingers when review mode was just enabled.
            if (m_prevHoveredGroupId != -1 || !m_prevHoveredNodeName.empty()) {
                remove_hover_highlight();
                m_prevHoveredGroupId = -1;
                m_prevHoveredNodeName.clear();
            }
            return;
        }
        bool changed = (m_hoveredGroupId != m_prevHoveredGroupId) ||
                       (m_hoveredNodeName != m_prevHoveredNodeName);
        if (!changed) return;

        // Remove previous hover highlight.
        remove_hover_highlight();
        m_prevHoveredGroupId = m_hoveredGroupId;
        m_prevHoveredNodeName = m_hoveredNodeName;

        if (!m_groupMgr) return;

        // Build list of nodes to highlight.
        std::vector<std::string> nodesToHighlight;

        if (!m_hoveredNodeName.empty()) {
            // Hovering a specific node in the expanded list — highlight just that one.
            nodesToHighlight.push_back(m_hoveredNodeName);
        } else if (m_hoveredGroupId >= 0) {
            // Hovering a group row — highlight all nodes in the group.
            auto* group = m_groupMgr->group_by_id(m_hoveredGroupId);
            if (group) nodesToHighlight = group->nodes;
        }

        if (nodesToHighlight.empty()) return;

        m_hoverHighlightGroup = vsg::Group::create();
        vsg::vec4 hoverColor{1.0f, 1.0f, 1.0f, 0.15f};

        for (const auto& nodeName : nodesToHighlight) {
            // Skip if this node is already selected (has red wireframe).
            if (m_hasSelection && nodeName == m_selectedShortName) continue;

            // Custom node: use subset highlight.
            if (m_groupMgr && m_groupMgr->is_custom_node(nodeName)) {
                const auto* def = m_groupMgr->custom_node(nodeName);
                if (def) {
                    auto hlGroup = create_custom_node_highlight(*def, hoverColor, 1.0f);
                    if (hlGroup) m_hoverHighlightGroup->addChild(hlGroup);
                }
                continue;
            }

            auto it = m_nodePathMap.find(nodeName);
            if (it == m_nodePathMap.end()) continue;
            if (it->second.geomChildren.empty()) continue;

            // If parent has custom nodes, create a subset excluding custom faces.
            bool hasCustom = m_groupMgr &&
                !m_groupMgr->custom_nodes_for_parent(nodeName).empty();
            if (hasCustom) {
                CustomNodeDef remainderDef;
                remainderDef.parent = nodeName;
                auto* parentVID = get_original_vid(nodeName);
                if (parentVID) {
                    auto adjIt = m_adjacencyCache.find(parentVID);
                    if (adjIt == m_adjacencyCache.end())
                        adjIt = m_adjacencyCache.emplace(parentVID, buildFaceAdjacency(parentVID)).first;
                    std::unordered_set<uint32_t> claimed;
                    for (const auto* cn : m_groupMgr->custom_nodes_for_parent(nodeName))
                        for (uint32_t f : cn->faces) claimed.insert(f);
                    for (uint32_t f = 0; f < adjIt->second.faceCount; ++f)
                        if (claimed.count(f) == 0) remainderDef.faces.push_back(f);
                }
                auto hlGroup = create_custom_node_highlight(remainderDef, hoverColor, 1.0f);
                if (hlGroup) m_hoverHighlightGroup->addChild(hlGroup);
            } else {
                auto transform = vsg::MatrixTransform::create();
                transform->matrix = it->second.worldMatrix;
                auto wp = create_wireframe_pipeline(hoverColor, 1.0f);
                add_wireframe_geometry(wp, it->second.geomChildren);
                transform->addChild(wp.group);
                m_hoverHighlightGroup->addChild(transform);
            }
        }

        if (m_hoverHighlightGroup->children.empty()) {
            m_hoverHighlightGroup = {};
            return;
        }

        m_sceneRoot->addChild(m_hoverHighlightGroup);

        if (m_viewer && m_viewer->compileManager) {
            auto result = m_viewer->compileManager->compile(m_hoverHighlightGroup);
            vsg::updateTasks(m_viewer->recordAndSubmitTasks, m_viewer->compileManager, result);
        }
    }

    void remove_hover_highlight() {
        if (m_hoverHighlightGroup && m_sceneRoot) {
            auto& children = m_sceneRoot->children;
            children.erase(
                std::remove(children.begin(), children.end(),
                            vsg::ref_ptr<vsg::Node>(m_hoverHighlightGroup)),
                children.end());
            m_hoverHighlightGroup = {};
        }
    }

    // ---------------------------------------------------------------
    //  Click handler
    // ---------------------------------------------------------------

    void on_click(int32_t x, int32_t y) {
        if (!m_camera || !m_sceneRoot) return;
        if (m_reviewMode) return;  // Review Mode: no selection/editing.

        remove_highlight();
        // Don't clear flood-fill when shift is held (additive selection).
        if (!m_shiftHeld || m_selectionMode != SelectionMode::Triangle) {
            remove_flood_fill_highlight();
        }

        auto intersector = vsg::LineSegmentIntersector::create(*m_camera, x, y);
        m_sceneRoot->accept(*intersector);

        if (intersector->intersections.empty()) {
            if (!m_selectedNodeName.empty()) {
                m_selectedNodeName.clear();
                m_selectedShortName.clear();
                m_hasSelection = false;
                EASIR_LOG("[EASIR] Deselected\n");
            }
            m_floodFill.reset();
            return;
        }

        auto& isects = intersector->intersections;
        auto closest = std::min_element(isects.begin(), isects.end(),
            [](const auto& a, const auto& b) { return a->ratio < b->ratio; });
        auto& hit = *closest;

        // Multi-asset click routing: only allow clicks on the active asset.
        if (m_assets.size() > 1) {
            AssetContext* hitAsset = asset_for_node_path(hit->nodePath);
            if (hitAsset && hitAsset->assetId != m_activeAssetId) {
                EASIR_LOG("[EASIR] click ignored: hit inactive asset '%s' (active='%s')\n",
                            hitAsset->assetId.c_str(), m_activeAssetId.c_str());
                return;
            }
            if (!hitAsset) {
                EASIR_LOG("[EASIR] click: couldn't route to any asset (edge/lighting node?)\n");
                return;
            }
        }

        std::string nodeName = find_node_name(hit->nodePath);
        std::string shortName = SemanticGroupManager::extract_short_name(nodeName);

        m_selectionPoint = hit->worldIntersection;
        m_hasSelection = true;
        m_selectedNodeName = nodeName;
        m_selectedShortName = shortName;

        if (m_selectionMode == SelectionMode::Triangle) {
            on_click_triangle(hit, shortName);
        } else {
            m_floodFill.reset();

            // Check if the hit face belongs to a custom node of this parent.
            if (m_groupMgr && hit->indexRatios.size() >= 3) {
                std::string customName = find_custom_node_for_face(
                    shortName,
                    hit->indexRatios[0].index,
                    hit->indexRatios[1].index,
                    hit->indexRatios[2].index);
                if (!customName.empty()) {
                    m_selectedShortName = customName;
                    m_selectedNodeName = customName;
                    select_custom_node_by_name(customName);
                    return;
                }
            }

            EASIR_LOG("[EASIR] Selected: '%s' at (%.2f, %.2f, %.2f)\n",
                        shortName.c_str(),
                        hit->worldIntersection.x,
                        hit->worldIntersection.y,
                        hit->worldIntersection.z);

            // If this parent has custom nodes, highlight only unclaimed faces.
            if (m_groupMgr && !m_groupMgr->custom_nodes_for_parent(shortName).empty()) {
                add_highlight_excluding_custom(shortName);
            } else {
                add_highlight(hit->nodePath);
            }
        }
    }

    /// Get the ORIGINAL (pre-split) VID for a parent node.
    /// Always use this for adjacency/face tracking — split VIDs have partial
    /// index buffers that don't match the original face numbering.
    vsg::VertexIndexDraw* get_original_vid(const std::string& shortName) {
        auto nodeIt = m_nodePathMap.find(shortName);
        if (nodeIt == m_nodePathMap.end()) return nullptr;
        for (auto& child : nodeIt->second.geomChildren) {
            auto* vid = dynamic_cast<vsg::VertexIndexDraw*>(child.get());
            if (vid) return vid;
        }
        return nullptr;
    }

    /// Triangle-mode click: find hit triangle, build adjacency, flood-fill.
    void on_click_triangle(const vsg::ref_ptr<vsg::LineSegmentIntersector::Intersection>& hit,
                           const std::string& shortName) {
        vsg::dmat4 worldMatrix(1.0);
        for (size_t i = 0; i < hit->nodePath.size(); ++i) {
            auto mt = dynamic_cast<const vsg::MatrixTransform*>(hit->nodePath[i]);
            if (mt) worldMatrix = worldMatrix * mt->matrix;
        }

        // Always use the ORIGINAL VID from nodePathMap for adjacency/face tracking.
        // After a split, the intersection may hit a remainder or custom VID, but
        // face indices in custom nodes reference the original index buffer.
        vsg::VertexIndexDraw* vid = get_original_vid(shortName);
        if (!vid) {
            // Fallback: try world matrix from nodePathMap.
            auto nodeIt = m_nodePathMap.find(shortName);
            if (nodeIt != m_nodePathMap.end()) {
                worldMatrix = nodeIt->second.worldMatrix;
            }
            EASIR_LOG("[EASIR] Triangle select: no VertexIndexDraw found for '%s'\n",
                        shortName.c_str());
            return;
        }

        // Use nodePathMap world matrix (more reliable than intersection path after split).
        auto nodeIt = m_nodePathMap.find(shortName);
        if (nodeIt != m_nodePathMap.end()) {
            worldMatrix = nodeIt->second.worldMatrix;
        }

        // Build or retrieve adjacency from the ORIGINAL VID.
        auto adjIt = m_adjacencyCache.find(vid);
        if (adjIt == m_adjacencyCache.end()) {
            EASIR_LOG("[EASIR] Building face adjacency for '%s' ...\n", shortName.c_str());
            auto adj = buildFaceAdjacency(vid);
            EASIR_LOG("[EASIR]   %u faces, %zu vertices\n", adj.faceCount,
                        adj.vertexToFaces.size());
            adjIt = m_adjacencyCache.emplace(vid, std::move(adj)).first;
        }
        const auto& adj = adjIt->second;

        // Identify the clicked triangle from indexRatios.
        if (hit->indexRatios.size() < 3) {
            EASIR_LOG("[EASIR] Triangle select: insufficient indexRatios (got %zu)\n",
                        hit->indexRatios.size());
            return;
        }
        uint32_t v0 = hit->indexRatios[0].index;
        uint32_t v1 = hit->indexRatios[1].index;
        uint32_t v2 = hit->indexRatios[2].index;

        // Validate vertex indices against the VID.
        uint32_t vidVertexCount = vid->arrays.empty() ? 0 :
            (vid->arrays[0]->data ? static_cast<uint32_t>(vid->arrays[0]->data->valueCount()) : 0);
        uint32_t vidIndexCount = vid->indices && vid->indices->data ?
            static_cast<uint32_t>(vid->indices->data->valueCount()) : 0;
        EASIR_LOG("[EASIR] Triangle click: hit verts [%u, %u, %u] on '%s' "
                    "(VID: %u vertices, %u indices, %u faces)\n",
                    v0, v1, v2, shortName.c_str(),
                    vidVertexCount, vidIndexCount, adj.faceCount);

        if (v0 >= vidVertexCount || v1 >= vidVertexCount || v2 >= vidVertexCount) {
            EASIR_LOG("[EASIR] Triangle select: ERROR vertex index out of bounds! "
                        "v0=%u v1=%u v2=%u vertexCount=%u\n", v0, v1, v2, vidVertexCount);
            return;
        }

        uint32_t startFace = findFaceFromVertexIndices(adj, v0, v1, v2);
        EASIR_LOG("[EASIR] Triangle click: face lookup result=%u\n", startFace);
        if (startFace == UINT32_MAX) {
            EASIR_LOG("[EASIR] Triangle select: could not identify face from vertices %u,%u,%u\n",
                        v0, v1, v2);
            return;
        }

        // Run flood-fill.
        float thresholdRad = m_floodFillAngleDeg * 3.14159265f / 180.0f;
        auto selected = floodFill(adj, startFace, thresholdRad);

        // Shift+click: add to existing selection (same parent only).
        bool additive = m_shiftHeld && m_floodFill &&
                        m_floodFill->parentNodeName == shortName;

        if (additive) {
            // Union with existing selection.
            for (uint32_t f : selected) {
                m_floodFill->selectedFaces.insert(f);
            }
            m_floodFill->startFace = startFace;  // update for angle slider re-run
            EASIR_LOG("[EASIR] Flood-fill +shift from face %u: +%zu faces, total %zu (%.1f deg)\n",
                        startFace, selected.size(), m_floodFill->selectedFaces.size(),
                        m_floodFillAngleDeg);
        } else {
            EASIR_LOG("[EASIR] Flood-fill from face %u: %zu faces selected (%.1f deg threshold)\n",
                        startFace, selected.size(), m_floodFillAngleDeg);

            // Remove old highlight BEFORE replacing m_floodFill — otherwise the
            // old highlight group is orphaned (remove uses m_floodFill->highlightGroup).
            remove_flood_fill_highlight();

            FloodFillState state;
            state.parentNodeName = shortName;
            state.sourceVID = vid;
            state.startFace = startFace;
            state.selectedFaces = std::move(selected);
            state.worldMatrix = worldMatrix;
            m_floodFill = std::move(state);
        }

        // For additive path, the old highlight is still in m_floodFill so remove works.
        remove_flood_fill_highlight();
        add_flood_fill_highlight();
    }

    /// Re-run flood-fill from the stored start face with the current angle threshold.
    void rerun_flood_fill() {
        if (!m_floodFill || m_floodFill->startFace == UINT32_MAX) return;

        auto adjIt = m_adjacencyCache.find(m_floodFill->sourceVID);
        if (adjIt == m_adjacencyCache.end()) return;

        float thresholdRad = m_floodFillAngleDeg * 3.14159265f / 180.0f;
        m_floodFill->selectedFaces = floodFill(adjIt->second, m_floodFill->startFace, thresholdRad);

        remove_flood_fill_highlight();
        add_flood_fill_highlight();
    }

    // ---------------------------------------------------------------
    //  Node name extraction
    // ---------------------------------------------------------------

    static std::string find_node_name(const vsg::Intersector::NodePath& nodePath) {
        for (auto it = nodePath.rbegin(); it != nodePath.rend(); ++it) {
            std::string name;
            if ((*it)->getValue("name", name) && !name.empty()) {
                return name;
            }
        }
        return "<unnamed>";
    }

    // ---------------------------------------------------------------
    //  Selection wireframe highlight
    // ---------------------------------------------------------------

    void add_highlight(const vsg::Intersector::NodePath& nodePath) {
        const vsg::Node* meshNode = nullptr;
        size_t meshIdx = 0;
        for (size_t i = nodePath.size(); i > 0; --i) {
            std::string name;
            if (nodePath[i - 1]->getValue("name", name) && !name.empty()) {
                meshNode = nodePath[i - 1];
                meshIdx = i - 1;
                break;
            }
        }
        if (!meshNode) return;

        vsg::dmat4 worldMatrix(1.0);
        for (size_t i = 0; i <= meshIdx; ++i) {
            auto mt = dynamic_cast<const vsg::MatrixTransform*>(nodePath[i]);
            if (mt) worldMatrix = worldMatrix * mt->matrix;
        }

        // Extract raw geometry nodes by digging through StateGroups.
        // This ensures the wireframe pipeline isn't overridden by child StateGroups.
        std::vector<vsg::ref_ptr<vsg::Node>> geomChildren;
        auto* group = dynamic_cast<const vsg::Group*>(meshNode);
        if (group) {
            // Use the same geometry extraction as the discovery visitor.
            struct GeomCollector {
                static void collect(const vsg::Group* g, std::vector<vsg::ref_ptr<vsg::Node>>& out) {
                    for (auto& child : g->children) {
                        auto* sg = dynamic_cast<const vsg::StateGroup*>(child.get());
                        if (sg) {
                            for (auto& sgChild : sg->children) out.push_back(sgChild);
                            continue;
                        }
                        auto* grp = dynamic_cast<const vsg::Group*>(child.get());
                        if (grp) { collect(grp, out); continue; }
                        out.push_back(child);
                    }
                }
            };
            GeomCollector::collect(group, geomChildren);
        } else {
            geomChildren.push_back(vsg::ref_ptr<vsg::Node>(const_cast<vsg::Node*>(meshNode)));
        }

        m_highlightGroup = vsg::Group::create();

        {
            auto transform = vsg::MatrixTransform::create();
            transform->matrix = worldMatrix;

            auto wp = create_wireframe_pipeline();
            add_wireframe_geometry(wp, geomChildren);
            transform->addChild(wp.group);
            m_highlightGroup->addChild(transform);
        }

        m_sceneRoot->addChild(m_highlightGroup);

        if (m_viewer && m_viewer->compileManager) {
            auto result = m_viewer->compileManager->compile(m_highlightGroup);
            if (result.requiresViewerUpdate()) {
                vsg::updateTasks(m_viewer->recordAndSubmitTasks, m_viewer->compileManager, result);
            }
        }
    }

    void remove_highlight() {
        if (m_highlightGroup && m_sceneRoot) {
            // Wait for in-flight GPU frames before dropping the highlight group's
            // ref. The group owns VIDs/BufferInfo/GPU buffers (especially from
            // create_custom_node_highlight which uses assignArrays). Command buffers
            // from the previous frame may still reference those buffers.
            if (m_viewer) {
                m_viewer->deviceWaitIdle();
            }
            auto& children = m_sceneRoot->children;
            children.erase(
                std::remove(children.begin(), children.end(),
                            vsg::ref_ptr<vsg::Node>(m_highlightGroup)),
                children.end());
            m_highlightGroup = {};
        }
    }

    /// Highlight a parent node's unclaimed faces (excluding custom node faces).
    void add_highlight_excluding_custom(const std::string& shortName) {
        if (!m_groupMgr) return;
        auto parentIt = m_nodePathMap.find(shortName);
        if (parentIt == m_nodePathMap.end()) return;

        // Find VID.
        vsg::VertexIndexDraw* parentVID = nullptr;
        for (auto& child : parentIt->second.geomChildren) {
            parentVID = dynamic_cast<vsg::VertexIndexDraw*>(child.get());
            if (parentVID) break;
        }
        if (!parentVID) { return; }

        // Build adjacency if needed.
        auto adjIt = m_adjacencyCache.find(parentVID);
        if (adjIt == m_adjacencyCache.end()) {
            adjIt = m_adjacencyCache.emplace(parentVID, buildFaceAdjacency(parentVID)).first;
        }
        const auto& adj = adjIt->second;

        // Collect all faces claimed by custom nodes.
        std::unordered_set<uint32_t> claimedFaces;
        for (const auto* cn : m_groupMgr->custom_nodes_for_parent(shortName)) {
            for (uint32_t f : cn->faces) claimedFaces.insert(f);
        }

        // Build remainder face list.
        std::vector<uint32_t> remainderFaces;
        for (uint32_t f = 0; f < adj.faceCount; ++f) {
            if (claimedFaces.count(f) == 0) remainderFaces.push_back(f);
        }
        if (remainderFaces.empty()) return;

        // Create a fake CustomNodeDef for the remainder to reuse the helper.
        CustomNodeDef remainderDef;
        remainderDef.name = shortName;
        remainderDef.parent = shortName;
        remainderDef.faces.assign(remainderFaces.begin(), remainderFaces.end());

        m_highlightGroup = create_custom_node_highlight(remainderDef);
        if (!m_highlightGroup) return;

        m_sceneRoot->addChild(m_highlightGroup);
        if (m_viewer && m_viewer->compileManager) {
            auto result = m_viewer->compileManager->compile(m_highlightGroup);
            if (result.requiresViewerUpdate()) {
                vsg::updateTasks(m_viewer->recordAndSubmitTasks, m_viewer->compileManager, result);
            }
        }
    }

    // ---------------------------------------------------------------
    //  Flood-fill triangle highlight
    // ---------------------------------------------------------------

    void add_flood_fill_highlight() {
        if (!m_floodFill || m_floodFill->selectedFaces.empty() || !m_floodFill->sourceVID)
            return;

        auto* vid = m_floodFill->sourceVID;
        auto adjIt = m_adjacencyCache.find(vid);
        if (adjIt == m_adjacencyCache.end()) {
            EASIR_LOG("[EASIR] FF-HL: ERROR adjacency cache miss for VID=%p\n", (void*)vid);
            return;
        }
        const auto& adj = adjIt->second;

        EASIR_LOG("[EASIR] FF-HL: creating highlight for '%s', %zu selected faces\n",
                    m_floodFill->parentNodeName.c_str(), m_floodFill->selectedFaces.size());
        EASIR_LOG("[EASIR] FF-HL: source VID=%p, arrays=%zu, adj.faceCount=%u\n",
                    (void*)vid, vid->arrays.size(), adj.faceCount);
        EASIR_LOG("[EASIR] FF-HL: scene children BEFORE add: %zu\n",
                    m_sceneRoot ? m_sceneRoot->children.size() : 0u);

        // Build index buffer for selected faces only.
        auto newIndices = vsg::uintArray::create(
            static_cast<uint32_t>(m_floodFill->selectedFaces.size() * 3));
        uint32_t idx = 0;
        uint32_t vertexCount = vid->arrays.empty() ? 0 :
            (vid->arrays[0]->data ? static_cast<uint32_t>(vid->arrays[0]->data->valueCount()) : 0);
        uint32_t maxIdx = 0;
        bool indexError = false;
        for (uint32_t f : m_floodFill->selectedFaces) {
            if (f >= adj.faceCount) {
                EASIR_LOG("[EASIR] FF-HL: ERROR face %u >= faceCount %u\n", f, adj.faceCount);
                indexError = true;
                continue;
            }
            for (int k = 0; k < 3; ++k) {
                uint32_t vi = adj.indices[f * 3 + k];
                if (vi >= vertexCount) {
                    EASIR_LOG("[EASIR] FF-HL: ERROR index[face %u][%d]=%u >= vertexCount=%u\n",
                                f, k, vi, vertexCount);
                    indexError = true;
                }
                if (vi > maxIdx) maxIdx = vi;
                newIndices->at(idx++) = vi;
            }
        }
        EASIR_LOG("[EASIR] FF-HL: index buffer: %u indices, max vertex index=%u, vertexCount=%u%s\n",
                    idx, maxIdx, vertexCount, indexError ? " ** HAS ERRORS **" : "");

        if (indexError) {
            EASIR_LOG("[EASIR] FF-HL: ABORTING highlight creation due to index errors\n");
            return;
        }

        // Create subset VID using assignArrays/assignIndices.
        auto subsetVID = vsg::VertexIndexDraw::create();
        vsg::DataList arrayData;
        for (auto& buf : vid->arrays) {
            if (buf && buf->data) arrayData.push_back(buf->data);
        }
        subsetVID->assignArrays(arrayData);
        subsetVID->assignIndices(newIndices);
        subsetVID->indexCount = static_cast<uint32_t>(newIndices->size());
        subsetVID->instanceCount = 1;
        EASIR_LOG("[EASIR] FF-HL: subset VID created, %zu array buffers, indexCount=%u\n",
                    subsetVID->arrays.size(), subsetVID->indexCount);

        auto transform = vsg::MatrixTransform::create();
        transform->matrix = m_floodFill->worldMatrix;

        auto wp = create_wireframe_pipeline();
        add_wireframe_geometry(wp, subsetVID);
        transform->addChild(wp.group);

        m_floodFill->highlightGroup = vsg::Group::create();
        m_floodFill->highlightGroup->addChild(transform);
        m_sceneRoot->addChild(m_floodFill->highlightGroup);

        ++m_ffHighlightCreated;
        EASIR_LOG("[EASIR] FF-HL: highlight #%d added to scene (removed so far: %d, delta: %d)\n",
                    m_ffHighlightCreated, m_ffHighlightRemoved,
                    m_ffHighlightCreated - m_ffHighlightRemoved);
        EASIR_LOG("[EASIR] FF-HL: scene children AFTER add: %zu\n",
                    m_sceneRoot->children.size());

        if (m_viewer && m_viewer->compileManager) {
            EASIR_LOG("[EASIR] FF-HL: compile starting...\n");
            try {
                auto result = m_viewer->compileManager->compile(m_floodFill->highlightGroup);
                EASIR_LOG("[EASIR] FF-HL: compile done, requiresUpdate=%d\n",
                            result.requiresViewerUpdate());
                if (result.requiresViewerUpdate()) {
                    vsg::updateTasks(m_viewer->recordAndSubmitTasks,
                                     m_viewer->compileManager, result);
                    EASIR_LOG("[EASIR] FF-HL: updateTasks done\n");
                }
            } catch (const std::exception& e) {
                EASIR_LOG("[EASIR] FF-HL: COMPILE EXCEPTION: %s\n", e.what());
            } catch (...) {
                EASIR_LOG("[EASIR] FF-HL: COMPILE UNKNOWN EXCEPTION\n");
            }
        }
        EASIR_LOG("[EASIR] FF-HL: add_flood_fill_highlight() complete\n");
    }

    void remove_flood_fill_highlight() {
        if (m_floodFill && m_floodFill->highlightGroup && m_sceneRoot) {
            EASIR_LOG("[EASIR] FF-HL: removing highlight, scene children BEFORE: %zu\n",
                        m_sceneRoot->children.size());

            // Wait for all in-flight GPU frames to finish before destroying
            // the highlight's GPU buffers. Without this, the render thread may
            // still be executing commands that reference the highlight's VID
            // buffers, causing Vulkan use-after-free corruption.
            if (m_viewer) {
                m_viewer->deviceWaitIdle();
            }

            auto& children = m_sceneRoot->children;
            size_t sizeBefore = children.size();
            children.erase(
                std::remove(children.begin(), children.end(),
                            vsg::ref_ptr<vsg::Node>(m_floodFill->highlightGroup)),
                children.end());
            size_t sizeAfter = children.size();
            m_floodFill->highlightGroup = {};
            ++m_ffHighlightRemoved;
            EASIR_LOG("[EASIR] FF-HL: removed (found=%d), scene children AFTER: %zu, "
                        "created=%d removed=%d delta=%d\n",
                        (int)(sizeBefore - sizeAfter), sizeAfter,
                        m_ffHighlightCreated, m_ffHighlightRemoved,
                        m_ffHighlightCreated - m_ffHighlightRemoved);
        } else {
            EASIR_LOG("[EASIR] FF-HL: remove called but nothing to remove "
                        "(floodFill=%d, hlGroup=%d)\n",
                        m_floodFill.has_value(),
                        m_floodFill && m_floodFill->highlightGroup ? 1 : 0);
        }
    }

    // ---------------------------------------------------------------
    //  Scene color update flag
    // ---------------------------------------------------------------
public:
    bool needs_scene_color_update() const { return m_needsSceneColorUpdate; }
    void clear_scene_color_update() { m_needsSceneColorUpdate = false; }
private:
    bool m_needsSceneColorUpdate = false;
};

} // namespace easir
