#pragma once

/**
 * @file win32_file_picker.h
 * @brief Minimal native file-open dialog wrapper (Windows only).
 *
 * Used by the editor (Phase H) to pick child assets when authoring articulated
 * scenes. Returns std::nullopt on cancel / error. Logs dialog open, selection,
 * and failure reasons via EASIR_LOG so interactive bugs are diagnosable.
 */

#include "trace.h"

#include <filesystem>
#include <optional>
#include <string>

#ifdef _WIN32
#  ifndef WIN32_LEAN_AND_MEAN
#    define WIN32_LEAN_AND_MEAN
#  endif
#  ifndef NOMINMAX
#    define NOMINMAX
#  endif
#  include <windows.h>
#  include <commdlg.h>
#endif

namespace easir {

/// Open a native file-picker dialog and return the selected path.
///
/// @param title          Window title shown on the dialog.
/// @param filter         Windows filter spec: pairs of description\0pattern\0,
///                       terminated by double-null. e.g.
///                       "OBJ\0*.obj\0All\0*.*\0\0"
/// @param initialDir     Starting directory (optional).
/// @return               Absolute path on success, nullopt on cancel / error.
inline std::optional<std::filesystem::path> pick_open_file(
        const char* title,
        const char* filter,
        const std::filesystem::path& initialDir = {})
{
#ifdef _WIN32
    char fileBuf[MAX_PATH] = {};
    char initDirBuf[MAX_PATH] = {};

    if (!initialDir.empty()) {
        std::string s = initialDir.string();
        strncpy_s(initDirBuf, s.c_str(), sizeof(initDirBuf) - 1);
    }

    OPENFILENAMEA ofn{};
    ofn.lStructSize  = sizeof(ofn);
    ofn.hwndOwner    = nullptr;
    ofn.lpstrFilter  = filter;
    ofn.lpstrFile    = fileBuf;
    ofn.nMaxFile     = sizeof(fileBuf);
    ofn.lpstrTitle   = title;
    ofn.lpstrInitialDir = initialDir.empty() ? nullptr : initDirBuf;
    ofn.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_NOCHANGEDIR;

    EASIR_LOG("[EASIR] file picker: open title='%s' initialDir='%s'\n",
                title ? title : "",
                initialDir.empty() ? "(none)" : initialDir.string().c_str());

    if (GetOpenFileNameA(&ofn)) {
        std::filesystem::path p(fileBuf);
        EASIR_LOG("[EASIR] file picker: selected '%s'\n", p.string().c_str());
        return p;
    }

    DWORD err = CommDlgExtendedError();
    if (err == 0) {
        EASIR_LOG("[EASIR] file picker: cancelled by user\n");
    } else {
        EASIR_LOG("[EASIR] file picker: ERROR CommDlgExtendedError=0x%lx\n",
                    (unsigned long)err);
    }
    return std::nullopt;
#else
    (void)title; (void)filter; (void)initialDir;
    EASIR_LOG("[EASIR] file picker: not supported on this platform\n");
    return std::nullopt;
#endif
}

} // namespace easir
