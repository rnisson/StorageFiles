#pragma once

/**
 * @file frame_logger.h
 * @brief Depth buffer readback diagnostics for debugging edge rendering.
 *
 * Reads back the depth image to CPU after rendering and prints statistics
 * to the console. Validates that the depth buffer has correct geometry data.
 */

#include <vsg/all.h>
#include <cstdio>
#include <cstdint>
#include <cstring>

namespace easir {

class FrameLogger {
public:
    static void enable(int numFrames) {
        instance().m_framesRemaining = numFrames;
        instance().m_frameIndex = 0;
    }

    static bool active() { return instance().m_framesRemaining > 0; }

    /// Read back depth buffer and print statistics.
    /// The depth image should be in DEPTH_STENCIL_READ_ONLY_OPTIMAL layout
    /// (as left by the offscreen render pass).
    static void logDepthStats(vsg::ref_ptr<vsg::Device> device,
                               vsg::ref_ptr<vsg::Image> depthImage,
                               uint32_t width, uint32_t height,
                               int queueFamily) {
        auto& inst = instance();
        if (inst.m_framesRemaining <= 0) return;
        inst.m_framesRemaining--;
        inst.m_frameIndex++;

        VkDevice vkDev = *device;
        VkDeviceSize bufSize = static_cast<VkDeviceSize>(width) * height * sizeof(float);

        // Create staging buffer.
        VkBufferCreateInfo bufInfo{VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO};
        bufInfo.size = bufSize;
        bufInfo.usage = VK_BUFFER_USAGE_TRANSFER_DST_BIT;
        VkBuffer stagingBuf;
        vkCreateBuffer(vkDev, &bufInfo, nullptr, &stagingBuf);

        VkMemoryRequirements memReqs;
        vkGetBufferMemoryRequirements(vkDev, stagingBuf, &memReqs);

        auto physDev = device->getPhysicalDevice();
        VkPhysicalDeviceMemoryProperties memProps;
        vkGetPhysicalDeviceMemoryProperties(*physDev, &memProps);

        uint32_t memType = 0;
        for (uint32_t i = 0; i < memProps.memoryTypeCount; ++i) {
            if ((memReqs.memoryTypeBits & (1u << i)) &&
                (memProps.memoryTypes[i].propertyFlags &
                 (VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT)) ==
                 (VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT)) {
                memType = i;
                break;
            }
        }

        VkDeviceMemory stagingMem;
        VkMemoryAllocateInfo memAlloc{VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO};
        memAlloc.allocationSize = memReqs.size;
        memAlloc.memoryTypeIndex = memType;
        vkAllocateMemory(vkDev, &memAlloc, nullptr, &stagingMem);
        vkBindBufferMemory(vkDev, stagingBuf, stagingMem, 0);

        // Command buffer.
        VkCommandPool cmdPool;
        VkCommandPoolCreateInfo poolInfo{VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO};
        poolInfo.queueFamilyIndex = static_cast<uint32_t>(queueFamily);
        poolInfo.flags = VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT;
        vkCreateCommandPool(vkDev, &poolInfo, nullptr, &cmdPool);

        VkCommandBuffer cmd;
        VkCommandBufferAllocateInfo allocCmd{VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO};
        allocCmd.commandPool = cmdPool;
        allocCmd.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY;
        allocCmd.commandBufferCount = 1;
        vkAllocateCommandBuffers(vkDev, &allocCmd, &cmd);

        VkFence fence;
        VkFenceCreateInfo fenceInfo{VK_STRUCTURE_TYPE_FENCE_CREATE_INFO};
        vkCreateFence(vkDev, &fenceInfo, nullptr, &fence);

        // Record copy.
        VkCommandBufferBeginInfo beginInfo{VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO};
        beginInfo.flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;
        vkBeginCommandBuffer(cmd, &beginInfo);

        VkImage srcImage = depthImage->vk(device->deviceID);

        // Transition: READ_ONLY_OPTIMAL → TRANSFER_SRC
        VkImageMemoryBarrier toTransfer{VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER};
        toTransfer.oldLayout = VK_IMAGE_LAYOUT_DEPTH_STENCIL_READ_ONLY_OPTIMAL;
        toTransfer.newLayout = VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL;
        toTransfer.srcAccessMask = VK_ACCESS_SHADER_READ_BIT;
        toTransfer.dstAccessMask = VK_ACCESS_TRANSFER_READ_BIT;
        toTransfer.image = srcImage;
        toTransfer.subresourceRange = {VK_IMAGE_ASPECT_DEPTH_BIT, 0, 1, 0, 1};
        vkCmdPipelineBarrier(cmd,
            VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT, VK_PIPELINE_STAGE_TRANSFER_BIT,
            0, 0, nullptr, 0, nullptr, 1, &toTransfer);

        VkBufferImageCopy region{};
        region.imageSubresource = {VK_IMAGE_ASPECT_DEPTH_BIT, 0, 0, 1};
        region.imageExtent = {width, height, 1};
        vkCmdCopyImageToBuffer(cmd, srcImage, VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL,
                               stagingBuf, 1, &region);

        // Transition back: TRANSFER_SRC → READ_ONLY_OPTIMAL
        VkImageMemoryBarrier toReadOnly{VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER};
        toReadOnly.oldLayout = VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL;
        toReadOnly.newLayout = VK_IMAGE_LAYOUT_DEPTH_STENCIL_READ_ONLY_OPTIMAL;
        toReadOnly.srcAccessMask = VK_ACCESS_TRANSFER_READ_BIT;
        toReadOnly.dstAccessMask = VK_ACCESS_SHADER_READ_BIT;
        toReadOnly.image = srcImage;
        toReadOnly.subresourceRange = {VK_IMAGE_ASPECT_DEPTH_BIT, 0, 1, 0, 1};
        vkCmdPipelineBarrier(cmd,
            VK_PIPELINE_STAGE_TRANSFER_BIT, VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT,
            0, 0, nullptr, 0, nullptr, 1, &toReadOnly);

        vkEndCommandBuffer(cmd);

        // Submit and wait.
        auto queue = device->getQueue(static_cast<uint32_t>(queueFamily));
        VkQueue vkQueue = *queue;
        VkSubmitInfo submitInfo{VK_STRUCTURE_TYPE_SUBMIT_INFO};
        submitInfo.commandBufferCount = 1;
        submitInfo.pCommandBuffers = &cmd;
        vkQueueSubmit(vkQueue, 1, &submitInfo, fence);
        vkWaitForFences(vkDev, 1, &fence, VK_TRUE, UINT64_MAX);

        // Map and analyze.
        void* mapped = nullptr;
        vkMapMemory(vkDev, stagingMem, 0, bufSize, 0, &mapped);
        const float* data = static_cast<const float*>(mapped);
        uint32_t total = width * height;
        uint32_t nearCount = 0, midCount = 0, bgCount = 0;
        float minD = 1.0f, maxD = 0.0f;

        for (uint32_t i = 0; i < total; ++i) {
            float d = data[i];
            if (d < minD) minD = d;
            if (d > maxD) maxD = d;
            if (d >= 0.9999f) bgCount++;
            else if (d >= 0.5f) midCount++;
            else nearCount++;
        }

        std::printf("[EASIR] Frame %d depth stats: %ux%u pixels\n", inst.m_frameIndex, width, height);
        std::printf("[EASIR]   min=%.8f  max=%.8f\n", minD, maxD);
        std::printf("[EASIR]   near(<0.5)=%u  mid(0.5-0.9999)=%u  bg(>=0.9999)=%u\n",
                    nearCount, midCount, bgCount);
        std::printf("[EASIR]   %% geometry = %.2f%%\n",
                    100.0f * static_cast<float>(nearCount + midCount) / static_cast<float>(total));

        uint32_t cx = width / 2, cy = height / 2;
        std::printf("[EASIR]   Center pixels: ");
        for (int dy = -2; dy <= 2; ++dy) {
            uint32_t idx = (cy + dy) * width + cx;
            if (idx < total) std::printf("%.6f ", data[idx]);
        }
        std::printf("\n");
        std::fflush(stdout);

        // Cleanup.
        vkUnmapMemory(vkDev, stagingMem);
        vkDestroyFence(vkDev, fence, nullptr);
        vkFreeCommandBuffers(vkDev, cmdPool, 1, &cmd);
        vkDestroyCommandPool(vkDev, cmdPool, nullptr);
        vkDestroyBuffer(vkDev, stagingBuf, nullptr);
        vkFreeMemory(vkDev, stagingMem, nullptr);
    }

    static void decrement() { instance().m_framesRemaining--; }

private:
    int m_framesRemaining = 0;
    int m_frameIndex = 0;

    static FrameLogger& instance() {
        static FrameLogger inst;
        return inst;
    }
};

} // namespace easir
