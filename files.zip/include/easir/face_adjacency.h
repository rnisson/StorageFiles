#pragma once

/**
 * @file face_adjacency.h
 * @brief Face adjacency structure and flood-fill selection for triangle meshes.
 *
 * Builds an edge-based adjacency graph from a VertexIndexDraw node's index buffer.
 * Supports flood-fill selection with a dihedral angle threshold for interactive
 * triangle region selection in the editor.
 */

#include "trace.h"

#include <cmath>
#include <cstdint>
#include <functional>
#include <queue>
#include <unordered_map>
#include <unordered_set>
#include <vector>

#include <vsg/maths/vec3.h>
#include <vsg/nodes/VertexIndexDraw.h>
#include <vsg/core/Array.h>

namespace easir {

struct FaceAdjacency {
    /// For each face, the list of adjacent face indices (sharing an edge).
    std::vector<std::vector<uint32_t>> adjacentFaces;

    /// Unit normal per face.
    std::vector<vsg::vec3> faceNormals;

    /// Flattened copy of the index buffer as uint32.
    std::vector<uint32_t> indices;

    /// Total face (triangle) count.
    uint32_t faceCount = 0;

    /// Lookup: raw vertex index -> list of face indices containing that vertex.
    std::unordered_map<uint32_t, std::vector<uint32_t>> vertexToFaces;
};

// -----------------------------------------------------------------------
//  Build
// -----------------------------------------------------------------------

/// Build face adjacency from a VertexIndexDraw node.
/// Returns empty FaceAdjacency if the node has no valid indexed triangle data.
inline FaceAdjacency buildFaceAdjacency(vsg::VertexIndexDraw* vid) {
    FaceAdjacency fa;
    if (!vid || !vid->indices || vid->arrays.empty()) return fa;

    // --- Extract vertex positions (binding 0) ---
    const vsg::vec3Array* positions = nullptr;
    if (vid->arrays[0]) {
        positions = dynamic_cast<const vsg::vec3Array*>(vid->arrays[0]->data.get());
    }
    if (!positions || positions->size() == 0) return fa;

    // --- Extract index buffer ---
    auto* idxData = vid->indices->data.get();
    if (!idxData) return fa;

    if (auto* u16 = dynamic_cast<const vsg::ushortArray*>(idxData)) {
        fa.indices.reserve(u16->size());
        for (size_t i = 0; i < u16->size(); ++i)
            fa.indices.push_back(static_cast<uint32_t>(u16->at(i)));
    } else if (auto* u32 = dynamic_cast<const vsg::uintArray*>(idxData)) {
        fa.indices.reserve(u32->size());
        for (size_t i = 0; i < u32->size(); ++i)
            fa.indices.push_back(u32->at(i));
    } else {
        return fa;  // unsupported index type
    }

    if (fa.indices.size() < 3) return fa;
    fa.faceCount = static_cast<uint32_t>(fa.indices.size() / 3);

    // --- Position dedup (quantize to ~1e-5 resolution) ---
    // Maps raw vertex index -> canonical vertex ID for edge hashing.
    // This handles meshes where Assimp duplicated vertices at the same position.
    struct Vec3Hash {
        size_t operator()(const std::tuple<int32_t, int32_t, int32_t>& v) const {
            auto h1 = std::hash<int32_t>{}(std::get<0>(v));
            auto h2 = std::hash<int32_t>{}(std::get<1>(v));
            auto h3 = std::hash<int32_t>{}(std::get<2>(v));
            return h1 ^ (h2 * 2654435761u) ^ (h3 * 40503u);
        }
    };

    constexpr float quantScale = 1e5f;
    std::unordered_map<std::tuple<int32_t, int32_t, int32_t>, uint32_t, Vec3Hash> posToCanonical;
    std::vector<uint32_t> canonicalId(positions->size());
    uint32_t nextCanonical = 0;

    for (size_t i = 0; i < positions->size(); ++i) {
        const auto& p = positions->at(i);
        auto key = std::make_tuple(
            static_cast<int32_t>(std::round(p.x * quantScale)),
            static_cast<int32_t>(std::round(p.y * quantScale)),
            static_cast<int32_t>(std::round(p.z * quantScale))
        );
        auto [it, inserted] = posToCanonical.emplace(key, nextCanonical);
        if (inserted) ++nextCanonical;
        canonicalId[i] = it->second;
    }

    // --- Build edge-to-face map ---
    // Edge key: pack two canonical vertex IDs into uint64 (sorted).
    auto edgeKey = [](uint32_t a, uint32_t b) -> uint64_t {
        if (a > b) std::swap(a, b);
        return (static_cast<uint64_t>(a) << 32) | static_cast<uint64_t>(b);
    };

    std::unordered_map<uint64_t, std::vector<uint32_t>> edgeToFaces;
    edgeToFaces.reserve(fa.faceCount * 3);

    for (uint32_t f = 0; f < fa.faceCount; ++f) {
        uint32_t i0 = fa.indices[f * 3 + 0];
        uint32_t i1 = fa.indices[f * 3 + 1];
        uint32_t i2 = fa.indices[f * 3 + 2];

        uint32_t c0 = canonicalId[i0];
        uint32_t c1 = canonicalId[i1];
        uint32_t c2 = canonicalId[i2];

        edgeToFaces[edgeKey(c0, c1)].push_back(f);
        edgeToFaces[edgeKey(c1, c2)].push_back(f);
        edgeToFaces[edgeKey(c0, c2)].push_back(f);
    }

    // --- Build adjacency lists ---
    fa.adjacentFaces.resize(fa.faceCount);
    for (const auto& [key, faces] : edgeToFaces) {
        // Record adjacency for all face pairs sharing this edge.
        for (size_t i = 0; i < faces.size(); ++i) {
            for (size_t j = i + 1; j < faces.size(); ++j) {
                fa.adjacentFaces[faces[i]].push_back(faces[j]);
                fa.adjacentFaces[faces[j]].push_back(faces[i]);
            }
        }
    }

    // --- Compute face normals ---
    fa.faceNormals.resize(fa.faceCount, vsg::vec3{0.0f, 0.0f, 0.0f});
    for (uint32_t f = 0; f < fa.faceCount; ++f) {
        const auto& v0 = positions->at(fa.indices[f * 3 + 0]);
        const auto& v1 = positions->at(fa.indices[f * 3 + 1]);
        const auto& v2 = positions->at(fa.indices[f * 3 + 2]);

        vsg::vec3 e1{v1.x - v0.x, v1.y - v0.y, v1.z - v0.z};
        vsg::vec3 e2{v2.x - v0.x, v2.y - v0.y, v2.z - v0.z};
        vsg::vec3 n{
            e1.y * e2.z - e1.z * e2.y,
            e1.z * e2.x - e1.x * e2.z,
            e1.x * e2.y - e1.y * e2.x
        };
        float len = std::sqrt(n.x * n.x + n.y * n.y + n.z * n.z);
        if (len > 1e-12f) {
            fa.faceNormals[f] = vsg::vec3{n.x / len, n.y / len, n.z / len};
        }
    }

    // --- Build vertexToFaces lookup ---
    for (uint32_t f = 0; f < fa.faceCount; ++f) {
        fa.vertexToFaces[fa.indices[f * 3 + 0]].push_back(f);
        fa.vertexToFaces[fa.indices[f * 3 + 1]].push_back(f);
        fa.vertexToFaces[fa.indices[f * 3 + 2]].push_back(f);
    }

    // --- Diagnostic statistics ---
    {
        uint32_t maxNeighbors = 0, isolated = 0, nonManifoldEdges = 0;
        uint64_t totalNeighbors = 0;
        for (uint32_t f = 0; f < fa.faceCount; ++f) {
            auto sz = static_cast<uint32_t>(fa.adjacentFaces[f].size());
            if (sz > maxNeighbors) maxNeighbors = sz;
            totalNeighbors += sz;
            if (sz == 0) ++isolated;
        }
        for (const auto& [key, faces] : edgeToFaces) {
            if (faces.size() > 2) ++nonManifoldEdges;
        }
        // Max faces per vertex
        uint32_t maxFacesPerVertex = 0;
        for (const auto& [v, faces] : fa.vertexToFaces) {
            if (faces.size() > maxFacesPerVertex)
                maxFacesPerVertex = static_cast<uint32_t>(faces.size());
        }
        EASIR_LOG("[EASIR] Adjacency stats: %u faces, %zu unique verts (deduped from %zu)\n",
                  fa.faceCount, posToCanonical.size(), positions->size());
        EASIR_LOG("[EASIR] Adjacency: max neighbors/face=%u, avg=%.1f, isolated=%u\n",
                  maxNeighbors, fa.faceCount > 0 ? totalNeighbors / (double)fa.faceCount : 0.0,
                  isolated);
        EASIR_LOG("[EASIR] Adjacency: non-manifold edges (>2 faces)=%u, max faces/vertex=%u\n",
                  nonManifoldEdges, maxFacesPerVertex);
    }

    return fa;
}

// -----------------------------------------------------------------------
//  Triangle lookup from intersection
// -----------------------------------------------------------------------

/// Find the face index from intersection vertex indices.
/// Returns UINT32_MAX if not found.
inline uint32_t findFaceFromVertexIndices(const FaceAdjacency& fa,
                                           uint32_t v0, uint32_t v1, uint32_t v2) {
    auto it = fa.vertexToFaces.find(v0);
    if (it == fa.vertexToFaces.end()) return UINT32_MAX;

    for (uint32_t f : it->second) {
        uint32_t fi0 = fa.indices[f * 3 + 0];
        uint32_t fi1 = fa.indices[f * 3 + 1];
        uint32_t fi2 = fa.indices[f * 3 + 2];
        // Check if the three vertex indices match (any order).
        std::unordered_set<uint32_t> faceVerts{fi0, fi1, fi2};
        if (faceVerts.count(v0) && faceVerts.count(v1) && faceVerts.count(v2)) {
            return f;
        }
    }
    return UINT32_MAX;
}

// -----------------------------------------------------------------------
//  Flood fill
// -----------------------------------------------------------------------

/// Flood-fill from a start face, expanding to adjacent faces where the dihedral
/// angle between neighbors is <= angleThresholdRad.
inline std::unordered_set<uint32_t> floodFill(const FaceAdjacency& fa,
                                               uint32_t startFace,
                                               float angleThresholdRad) {
    std::unordered_set<uint32_t> selected;
    if (startFace >= fa.faceCount) {
        EASIR_LOG("[EASIR] FloodFill: ERROR startFace %u >= faceCount %u\n",
                  startFace, fa.faceCount);
        return selected;
    }

    const auto& startNormal = fa.faceNormals[startFace];
    EASIR_LOG("[EASIR] FloodFill: start face=%u, threshold=%.3f rad (%.1f deg), "
              "normal=(%.3f,%.3f,%.3f), neighbors=%zu\n",
              startFace, angleThresholdRad, angleThresholdRad * 180.0f / 3.14159265f,
              startNormal.x, startNormal.y, startNormal.z,
              fa.adjacentFaces[startFace].size());

    selected.insert(startFace);
    std::queue<uint32_t> queue;
    queue.push(startFace);

    uint32_t bfsIterations = 0;
    uint32_t maxQueueSize = 1;
    uint32_t outOfBoundsNeighbors = 0;

    while (!queue.empty()) {
        if (queue.size() > maxQueueSize) maxQueueSize = static_cast<uint32_t>(queue.size());
        uint32_t current = queue.front();
        queue.pop();
        ++bfsIterations;

        if (current >= fa.faceCount) {
            EASIR_LOG("[EASIR] FloodFill: ERROR current face %u >= faceCount %u at iteration %u\n",
                      current, fa.faceCount, bfsIterations);
            break;
        }

        const auto& currentNormal = fa.faceNormals[current];
        float currentLen = currentNormal.x * currentNormal.x +
                           currentNormal.y * currentNormal.y +
                           currentNormal.z * currentNormal.z;
        if (currentLen < 0.5f) continue;

        for (uint32_t neighbor : fa.adjacentFaces[current]) {
            if (neighbor >= fa.faceCount) {
                ++outOfBoundsNeighbors;
                continue;
            }
            if (selected.count(neighbor)) continue;

            const auto& neighborNormal = fa.faceNormals[neighbor];
            float neighborLen = neighborNormal.x * neighborNormal.x +
                                neighborNormal.y * neighborNormal.y +
                                neighborNormal.z * neighborNormal.z;
            if (neighborLen < 0.5f) continue;

            float dot = currentNormal.x * neighborNormal.x +
                        currentNormal.y * neighborNormal.y +
                        currentNormal.z * neighborNormal.z;
            if (dot > 1.0f) dot = 1.0f;
            if (dot < -1.0f) dot = -1.0f;
            float angle = std::acos(dot);

            if (angle <= angleThresholdRad) {
                selected.insert(neighbor);
                queue.push(neighbor);
            }
        }
    }

    EASIR_LOG("[EASIR] FloodFill: done — %zu selected, %u BFS iterations, "
              "max queue=%u, OOB neighbors=%u\n",
              selected.size(), bfsIterations, maxQueueSize, outOfBoundsNeighbors);

    return selected;
}

} // namespace easir
