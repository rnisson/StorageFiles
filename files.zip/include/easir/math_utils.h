#pragma once

/**
 * @file math_utils.h
 * @brief Shared math helpers (pose composition, quaternion <-> Euler).
 */

#include <array>
#include <cmath>

#include <vsg/maths/mat4.h>
#include <vsg/maths/quat.h>
#include <vsg/maths/vec3.h>

namespace easir {

/// Build a 4x4 model matrix from position and a unit quaternion (x,y,z,w).
inline vsg::dmat4 pose_to_matrix_d(const vsg::dvec3& pos, const vsg::dquat& q) {
    const double x = q.x, y = q.y, z = q.z, w = q.w;
    return vsg::dmat4(
        1.0 - 2.0*(y*y + z*z),  2.0*(x*y + w*z),         2.0*(x*z - w*y),         0.0,
        2.0*(x*y - w*z),         1.0 - 2.0*(x*x + z*z),  2.0*(y*z + w*x),         0.0,
        2.0*(x*z + w*y),         2.0*(y*z - w*x),         1.0 - 2.0*(x*x + y*y),  0.0,
        pos.x,                   pos.y,                   pos.z,                   1.0
    );
}

/// Build a 4x4 model matrix that rotates about an arbitrary pivot point in
/// the CHILD's body frame. Composition: T(pos) * R(q) * T(-pivot).
/// Effect: the point `pivot` in child coordinates lands at `pos` in parent
/// coordinates regardless of rotation, i.e. rotation happens about `pivot`
/// rather than the mesh origin.
inline vsg::dmat4 pose_to_matrix_d_pivot(const vsg::dvec3& pos,
                                          const vsg::dquat& q,
                                          const vsg::dvec3& pivot) {
    vsg::dmat4 m = pose_to_matrix_d(pos, q);
    // Apply T(-pivot) on the right: the rotation block rotates -pivot and
    // adds it to the existing translation column.
    // m = m * T(-pivot)  =>  m.col3 += m * (-pivot, 0)
    const double px = -pivot.x, py = -pivot.y, pz = -pivot.z;
    m(3,0) += m(0,0)*px + m(1,0)*py + m(2,0)*pz;
    m(3,1) += m(0,1)*px + m(1,1)*py + m(2,1)*pz;
    m(3,2) += m(0,2)*px + m(1,2)*py + m(2,2)*pz;
    return m;
}

inline vsg::dvec3 array_to_dvec3(const std::array<double, 3>& a) {
    return vsg::dvec3{a[0], a[1], a[2]};
}

inline vsg::dquat array_to_dquat(const std::array<double, 4>& a) {
    return vsg::dquat{a[0], a[1], a[2], a[3]};
}

/// Convert intrinsic ZYX Euler angles (degrees) to a unit quaternion.
/// Intrinsic ZYX means: rotate about body Z, then about the new body Y,
/// then about the new body X. This matches the convention exposed in the
/// editor's optional Euler input — users editing one axis at a time.
/// Input order is (x, y, z) = (roll, pitch, yaw) in degrees.
inline vsg::dquat euler_zyx_intrinsic_to_quat(const vsg::dvec3& eulerDeg) {
    const double deg2rad = 3.14159265358979323846 / 180.0;
    const double rx = eulerDeg.x * deg2rad * 0.5;
    const double ry = eulerDeg.y * deg2rad * 0.5;
    const double rz = eulerDeg.z * deg2rad * 0.5;

    const double cx = std::cos(rx), sx = std::sin(rx);
    const double cy = std::cos(ry), sy = std::sin(ry);
    const double cz = std::cos(rz), sz = std::sin(rz);

    // q = qz * qy * qx   (intrinsic ZYX)
    vsg::dquat q;
    q.w = cz * cy * cx + sz * sy * sx;
    q.x = cz * cy * sx - sz * sy * cx;
    q.y = cz * sy * cx + sz * cy * sx;
    q.z = sz * cy * cx - cz * sy * sx;
    return q;
}

/// Inverse of euler_zyx_intrinsic_to_quat — extract ZYX Euler angles (degrees)
/// from a quaternion. Handles the gimbal-lock case at pitch = ±90° by falling
/// back to a stable but non-unique decomposition.
inline vsg::dvec3 quat_to_euler_zyx_intrinsic(const vsg::dquat& q) {
    const double rad2deg = 180.0 / 3.14159265358979323846;

    // Normalise just in case.
    double n = std::sqrt(q.x*q.x + q.y*q.y + q.z*q.z + q.w*q.w);
    double x = q.x/n, y = q.y/n, z = q.z/n, w = q.w/n;

    // pitch (Y) = asin(2(wy - zx)), clamped.
    double sinp = 2.0 * (w*y - z*x);
    if (sinp >  1.0) sinp =  1.0;
    if (sinp < -1.0) sinp = -1.0;
    double pitch = std::asin(sinp);

    double roll, yaw;
    if (std::fabs(sinp) > 0.99999) {
        // Gimbal lock: pitch ≈ ±90°.
        roll = 0.0;
        yaw  = std::atan2(-2.0*(x*y - w*z), 1.0 - 2.0*(y*y + z*z));
    } else {
        roll = std::atan2(2.0*(w*x + y*z), 1.0 - 2.0*(x*x + y*y));
        yaw  = std::atan2(2.0*(w*z + x*y), 1.0 - 2.0*(y*y + z*z));
    }
    return vsg::dvec3{roll * rad2deg, pitch * rad2deg, yaw * rad2deg};
}

} // namespace easir
