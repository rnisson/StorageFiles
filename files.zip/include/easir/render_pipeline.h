#pragma once

/**
 * @file render_pipeline.h
 * @brief RenderPipeline and RenderPass abstractions.
 *
 * The pipeline owns an ordered list of RenderPass objects and executes them
 * in sequence each frame.  Each pass operates on the same VSG scene graph and
 * command graph, adding Vulkan commands or scene nodes as required.
 *
 * Extending the pipeline with a new effect (bloom, shadow mapping, atmosphere,
 * etc.) means deriving a new class from RenderPass and registering it in
 * RenderPipeline::build().
 */

#include <memory>
#include <string>
#include <unordered_map>
#include <vector>

#include <vsg/all.h>
#include <vsgXchange/all.h>

#include "config.h"
#include "semantic_map.h"
#include "semantic_visitor.h"
#include "state.h"
#include "trace.h"

namespace easir {

// ---------------------------------------------------------------------------
// RenderContext — data shared across all passes in a single render call
// ---------------------------------------------------------------------------

struct RenderContext {
    vsg::ref_ptr<vsg::Viewer>   viewer;
    vsg::ref_ptr<vsg::Group>    scene_root;
    const EasirConfig*           config  = nullptr;
    const EasirState*            state   = nullptr;
    uint64_t                    frame   = 0;
};

// ---------------------------------------------------------------------------
// RenderPass base class
// ---------------------------------------------------------------------------

/**
 * @brief Abstract base class for a single rendering pass.
 *
 * Subclass this to implement shadow mapping, star field generation, bloom,
 * atmospheric scattering, etc.  For the initial scaffold only ForwardPass
 * is provided.
 */
class RenderPass {
public:
    explicit RenderPass(std::string name) : m_name(std::move(name)) {}
    virtual ~RenderPass() = default;

    RenderPass(const RenderPass&)            = delete;
    RenderPass& operator=(const RenderPass&) = delete;

    /// Called once after the pass is created; set up VSG objects here.
    virtual void setup(RenderContext& ctx) = 0;

    /// Called each frame to record pass-specific commands / updates.
    virtual void execute(RenderContext& ctx) = 0;

    /// Called when the renderer is shutting down.
    virtual void teardown([[maybe_unused]] RenderContext& ctx) {}

    [[nodiscard]] const std::string& name() const noexcept { return m_name; }

protected:
    std::string m_name;
};

// ---------------------------------------------------------------------------
// ForwardPass — basic forward-shading pass (initial scaffold)
// ---------------------------------------------------------------------------

/**
 * @brief Forward-shading pass.
 *
 * Loads the scene objects declared in EasirConfig, applies a single directional
 * light (the sun), and renders them.  This is the starting point; additional
 * lighting models and material complexity will be layered in later.
 */
class ForwardPass final : public RenderPass {
public:
    ForwardPass() : RenderPass("ForwardPass") {}

    void setup(RenderContext& ctx) override;
    void execute(RenderContext& ctx) override;

    /// Get the resolved asset path for the first scene object (for editor mode).
    std::filesystem::path first_asset_path() const {
        if (m_asset_paths.empty()) return {};
        return m_asset_paths.begin()->second;
    }

    /// Material map from semantic visitor (for live recoloring in editor).
    using MaterialMap = std::unordered_map<std::string, vsg::ref_ptr<vsg::PhongMaterialValue>>;
    /// Legacy combined map across all assets. Prefer material_map_for(id).
    const MaterialMap& material_map() const { return m_materialMap; }
    /// Per-asset material map (keyed by scene_object id). Empty if asset not loaded.
    const MaterialMap& material_map_for(const std::string& id) const {
        static const MaterialMap empty;
        auto it = m_per_asset_material_maps.find(id);
        return it == m_per_asset_material_maps.end() ? empty : it->second;
    }

    /// Sun light reference (for editor light direction reset).
    vsg::ref_ptr<vsg::DirectionalLight> sun_light() const { return m_sun_light; }

    /// Public access to per-object transforms (keyed by SceneObjectConfig::id).
    const std::unordered_map<std::string, vsg::ref_ptr<vsg::MatrixTransform>>&
    object_transforms() const { return m_object_transforms; }

    /// Get the resolved asset path for a given scene object id, or empty if not loaded.
    std::filesystem::path asset_path(const std::string& id) const {
        auto it = m_asset_paths.find(id);
        return it == m_asset_paths.end() ? std::filesystem::path{} : it->second;
    }

    // ----- Joint registry (articulation) -----
    //
    // Phase L: per-spacecraft namespacing. The registry is nested by top-level
    // scene_object id, so two spacecraft can each carry a joint with the same
    // local name (e.g. two probes both with `panel_left_hinge`) without collision.
    // The owner is the OUTER map key — JointBinding no longer carries it.

    struct JointBinding {
        vsg::ref_ptr<vsg::MatrixTransform> transform;
        vsg::dvec3 homePos{0.0, 0.0, 0.0};
        vsg::dquat homeQuat{0.0, 0.0, 0.0, 1.0};
        vsg::dvec3 pivotOffset{0.0, 0.0, 0.0};  // in child body frame
    };

    /// Joint bindings nested as `map<topLevelAssetId, map<jointName, binding>>`.
    using JointMap = std::unordered_map<std::string, JointBinding>;
    using JointTreeMap = std::unordered_map<std::string, JointMap>;

    /// Register a joint binding. Collisions are allowed across different
    /// `topLevelId` values, but disallowed within the same tree. The
    /// per-tree collision check upstream (load_articulated, editor's
    /// is_joint_name_taken) should catch dupes before they reach this call;
    /// the inline guard here is a defensive safety net that logs and skips.
    void register_joint(const std::string& topLevelId,
                        const std::string& jointName,
                        vsg::ref_ptr<vsg::MatrixTransform> xform,
                        const vsg::dvec3& homePos,
                        const vsg::dquat& homeQuat,
                        const vsg::dvec3& pivotOffset = {0.0, 0.0, 0.0}) {
        auto& tree = m_joints[topLevelId];
        auto it = tree.find(jointName);
        if (it != tree.end()) {
            EASIR_LOG("[EASIR] WARN joint collision in tree '%s': '%s' (skipping, keeping first)\n",
                        topLevelId.c_str(), jointName.c_str());
            return;
        }
        JointBinding b;
        b.transform = xform;
        b.homePos = homePos;
        b.homeQuat = homeQuat;
        b.pivotOffset = pivotOffset;
        tree.emplace(jointName, std::move(b));
        EASIR_LOG("[EASIR] joint registered: top='%s' joint='%s' home=(%f,%f,%f) quat=(%f,%f,%f,%f) pivot=(%f,%f,%f)\n",
                    topLevelId.c_str(), jointName.c_str(),
                    homePos.x, homePos.y, homePos.z,
                    homeQuat.x, homeQuat.y, homeQuat.z, homeQuat.w,
                    pivotOffset.x, pivotOffset.y, pivotOffset.z);
    }

    /// Read-only access to the full nested registry (for serialization /
    /// editor inspection). Iterate as `for (auto& [topId, jointMap] : joints())`.
    const JointTreeMap& joints() const { return m_joints; }

    /// Convenience pointer lookup. Returns nullptr if either the top-level
    /// tree is missing or the joint is missing within that tree.
    const JointBinding* joint_for(const std::string& topLevelId,
                                   const std::string& jointName) const {
        auto outerIt = m_joints.find(topLevelId);
        if (outerIt == m_joints.end()) return nullptr;
        auto innerIt = outerIt->second.find(jointName);
        if (innerIt == outerIt->second.end()) return nullptr;
        return &innerIt->second;
    }

    /// Remove a joint binding by (top, name). Returns true if a binding was
    /// removed. If the tree becomes empty as a result, the outer entry is
    /// pruned too so the registry stays compact.
    bool unregister_joint(const std::string& topLevelId,
                          const std::string& jointName) {
        auto outerIt = m_joints.find(topLevelId);
        if (outerIt == m_joints.end()) {
            EASIR_LOG("[EASIR] unregister_joint: top='%s' not found\n",
                        topLevelId.c_str());
            return false;
        }
        size_t erased = outerIt->second.erase(jointName);
        if (erased == 0) {
            EASIR_LOG("[EASIR] unregister_joint: top='%s' joint='%s' not found\n",
                        topLevelId.c_str(), jointName.c_str());
            return false;
        }
        EASIR_LOG("[EASIR] joint unregistered: top='%s' joint='%s'\n",
                    topLevelId.c_str(), jointName.c_str());
        if (outerIt->second.empty()) {
            m_joints.erase(outerIt);
        }
        return true;
    }

    /// Store per-asset materials from outside (used when renderer.cpp loads
    /// children articulated subtrees and needs the forward pass to own their
    /// materials for later lookup).
    void set_material_map_for(const std::string& id, MaterialMap map) {
        m_per_asset_material_maps[id] = std::move(map);
    }

private:
    MaterialMap m_materialMap;
    std::unordered_map<std::string, MaterialMap> m_per_asset_material_maps;
    vsg::ref_ptr<vsg::DirectionalLight> m_sun_light;
    vsg::ref_ptr<vsg::Group>            m_scene_objects_group;

    /// Per-object transform nodes, keyed by SceneObjectConfig::id.
    std::unordered_map<std::string, vsg::ref_ptr<vsg::MatrixTransform>> m_object_transforms;

    /// Resolved asset paths per object id (for semantic map lookup).
    std::unordered_map<std::string, std::filesystem::path> m_asset_paths;

    /// Joint bindings nested by top-level scene_object id, then joint name.
    /// Phase L: per-spacecraft namespacing — see register_joint() for details.
    JointTreeMap m_joints;
};

// ---------------------------------------------------------------------------
// RenderPipeline
// ---------------------------------------------------------------------------

/**
 * @brief Owns and executes the ordered sequence of render passes.
 *
 * Build the pipeline once with build(config), then call execute(ctx) each frame.
 * The set of passes created is determined by EasirConfig::pipeline.
 */
class RenderPipeline {
public:
    RenderPipeline() = default;
    ~RenderPipeline() = default;

    RenderPipeline(const RenderPipeline&)            = delete;
    RenderPipeline& operator=(const RenderPipeline&) = delete;

    /// Creates all passes enabled in the config and calls setup() on each.
    void build(const EasirConfig& config, RenderContext& ctx);

    /// Executes all passes in order for the current frame.
    void execute(RenderContext& ctx);

    /// Shuts down all passes.
    void teardown(RenderContext& ctx);

    /// Returns the number of passes in the pipeline.
    [[nodiscard]] std::size_t pass_count() const noexcept { return m_passes.size(); }

    /// Access a pass by index (for inspection / testing).
    [[nodiscard]] RenderPass& pass(std::size_t i) { return *m_passes.at(i); }

    /// Get the forward pass (first pass), or nullptr.
    ForwardPass* forward_pass() {
        if (m_passes.empty()) return nullptr;
        return dynamic_cast<ForwardPass*>(m_passes[0].get());
    }

private:
    std::vector<std::unique_ptr<RenderPass>> m_passes;
};

} // namespace easir
