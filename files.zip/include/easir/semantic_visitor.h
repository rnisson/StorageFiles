#pragma once

/**
 * @file semantic_visitor.h
 * @brief SemanticMaterialVisitor — replaces PBR materials with flat semantic colors.
 *
 * Traverses a VSG scene graph produced by vsgXchange's GLB loader and swaps
 * each StateGroup's PBR pipeline + descriptors with a flat-shaded pipeline
 * whose color is determined by the SemanticColorMap.
 *
 * Must be applied BEFORE vsg::Viewer::compile() so that the modified
 * StateGroups are compiled into valid Vulkan pipelines.
 */

#include "semantic_map.h"
#include "trace.h"

#include <vsg/all.h>

#include <string>
#include <vector>

namespace easir {

class SemanticMaterialVisitor : public vsg::Visitor {
public:
    explicit SemanticMaterialVisitor(const SemanticColorMap& colorMap)
        : m_colorMap(colorMap)
    {
        // Use Phong shader set — supports lighting for optional "semantic shading"
        // toggle. Default material uses emissive only (= flat), toggling shading
        // shifts to diffuse (N·L lighting).
        m_flatShaderSet = vsg::createPhongShaderSet();
    }

    // Track node names as we descend (names stored by vsgXchange on transforms/groups).
    void apply(vsg::Node& node) override {
        node.traverse(*this);
    }

    void apply(vsg::Group& group) override {
        push_name(group);
        group.traverse(*this);
        pop_name();
    }

    void apply(vsg::MatrixTransform& mt) override {
        push_name(mt);
        mt.traverse(*this);
        pop_name();
    }

    void apply(vsg::StateGroup& sg) override {
        if (m_nameStack.empty()) {
            // No ancestor with a name — skip (shouldn't happen for GLB-loaded content).
            sg.traverse(*this);
            return;
        }

        const std::string& node_name = m_nameStack.back();
        vsg::vec4 color = m_colorMap.color_for_node(node_name);

        EASIR_TRACE("SemanticVisitor: node '%s' -> color (%.0f, %.0f, %.0f)",
                    node_name.c_str(), color.x * 255.0f, color.y * 255.0f, color.z * 255.0f);

        // Extract VertexInputState from the existing PBR pipeline so the new
        // flat-color pipeline uses the same vertex attribute bindings.
        vsg::ref_ptr<vsg::VertexInputState> existingVertexInput;
        for (auto& sc : sg.stateCommands) {
            auto bgp = sc.cast<vsg::BindGraphicsPipeline>();
            if (bgp && bgp->pipeline) {
                for (auto& ps : bgp->pipeline->pipelineStates) {
                    auto vis = ps.cast<vsg::VertexInputState>();
                    if (vis) {
                        existingVertexInput = vis;
                        break;
                    }
                }
                if (existingVertexInput) break;
            }
        }

        // Build the flat-color pipeline.
        auto config = vsg::GraphicsPipelineConfigurator::create(m_flatShaderSet);

        // Copy vertex input state from the existing PBR pipeline so that
        // vertex attribute bindings match the VertexIndexDraw geometry.
        if (existingVertexInput) {
            for (auto& ps : config->pipelineStates) {
                if (ps.cast<vsg::VertexInputState>()) {
                    ps = existingVertexInput;
                    break;
                }
            }
        }

        // Assign PhongMaterial — emissive only (flat) by default.
        // Semantic shading toggle shifts to diffuse (N·L lighting).
        // emissive = color, diffuse = 0 → output = color (no lighting).
        auto mat = vsg::PhongMaterialValue::create();
        mat->value().ambient  = vsg::vec4{0.0f, 0.0f, 0.0f, 1.0f};
        mat->value().diffuse  = vsg::vec4{0.0f, 0.0f, 0.0f, 1.0f};
        mat->value().specular = vsg::vec4{0.0f, 0.0f, 0.0f, 1.0f};
        mat->value().emissive = color;
        mat->value().shininess = 0.0f;
        // Mark as dynamic so VSG re-uploads to GPU when dirty() is called.
        mat->properties.dataVariance = vsg::DYNAMIC_DATA;
        config->assignDescriptor("material", mat);

        config->init();

        // Replace the StateGroup's state commands with the flat-color pipeline.
        sg.stateCommands.clear();
        config->copyTo(sg.stateCommands);

        // Store material reference for live recoloring in editor mode.
        auto shortName = extract_short_name(node_name);
        m_materialMap[shortName] = mat;

        ++m_replacedCount;

        // Continue traversal into children (there may be nested StateGroups).
        sg.traverse(*this);
    }

    int replaced_count() const noexcept { return m_replacedCount; }

    /// Map of short node name -> material reference (for live recoloring in editor).
    using MaterialMap = std::unordered_map<std::string, vsg::ref_ptr<vsg::PhongMaterialValue>>;
    const MaterialMap& material_map() const { return m_materialMap; }

private:
    const SemanticColorMap& m_colorMap;
    vsg::ref_ptr<vsg::ShaderSet> m_flatShaderSet;
    std::vector<std::string> m_nameStack;
    int m_replacedCount = 0;
    MaterialMap m_materialMap;

    static std::string extract_short_name(const std::string& full_name) {
        auto last_open = full_name.rfind('[');
        if (last_open == std::string::npos) return full_name;
        auto close = full_name.find(']', last_open + 1);
        if (close == std::string::npos || close <= last_open) return full_name;
        return full_name.substr(last_open + 1, close - last_open - 1);
    }

    void push_name(vsg::Object& obj) {
        std::string name;
        if (obj.getValue("name", name) && !name.empty()) {
            m_nameStack.push_back(std::move(name));
        } else {
            // Push empty string as placeholder so pop_name stays balanced.
            m_nameStack.push_back({});
        }
    }

    void pop_name() {
        if (!m_nameStack.empty()) {
            m_nameStack.pop_back();
        }
    }
};

} // namespace easir
