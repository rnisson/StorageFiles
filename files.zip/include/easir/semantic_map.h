#pragma once

/**
 * @file semantic_map.h
 * @brief SemanticColorMap — maps glTF node names to flat semantic colors.
 *
 * Used by the semantic render mode to replace PBR materials with flat colors
 * that encode component identity (bus, panel, dish, etc.).
 *
 * The mapping is loaded from a JSON file named <model_stem>_semantic_map.json
 * located alongside the .glb asset.  If no file is found, each node is
 * assigned a deterministic visually-distinct color (auto mode).
 */

#include <array>
#include <filesystem>
#include <string>
#include <unordered_map>

#include <vsg/maths/vec4.h>

namespace easir {

class SemanticColorMap {
public:
    /**
     * @brief Load a semantic map for the given model asset.
     *
     * Looks for <stem>_semantic_map.json next to @p glb_path.
     * If the file is missing, returns an empty map (auto-color mode).
     * Logs to console in both cases.
     */
    static SemanticColorMap load(const std::filesystem::path& glb_path);

    /**
     * @brief Get the semantic color for a glTF node name.
     *
     * If an explicit map was loaded, returns the mapped color.
     * Otherwise returns a deterministic random color based on the node name.
     *
     * @param node_name  Full node name as stored by vsgXchange
     *                   (e.g. "Aqua_Reduced_v0014 [Layer24]").
     */
    vsg::vec4 color_for_node(const std::string& node_name) const;

    /// True if an explicit JSON map was loaded (vs auto-color mode).
    bool has_explicit_map() const noexcept { return m_has_map; }

private:
    bool m_has_map = false;

    /// node short name (e.g. "Layer24") -> RGBA color [0..1]
    std::unordered_map<std::string, vsg::vec4> m_node_to_color;

    /// Extract the bracketed short name from a full vsgXchange node name.
    /// "Aqua_Reduced_v0014 [Layer24]" -> "Layer24"
    /// Returns the full name if no brackets found.
    static std::string extract_short_name(const std::string& full_name);

    /// Generate a deterministic visually-distinct color from a string hash.
    static vsg::vec4 auto_color(const std::string& name);
};

} // namespace easir
