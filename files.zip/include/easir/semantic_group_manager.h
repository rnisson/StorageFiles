#pragma once

/**
 * @file semantic_group_manager.h
 * @brief SemanticGroupManager — manages semantic groups and node assignments.
 *
 * Used by editor mode to interactively build semantic maps:
 *   - Groups have a name, color, and list of assigned nodes
 *   - "Unassigned" is a permanent group (cannot be deleted/renamed)
 *   - Nodes can be moved between groups
 *   - Save/load to/from <model_stem>_semantic_map.json
 */

#include "trace.h"

#include <algorithm>
#include <array>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>

#include <nlohmann/json.hpp>
#include <vsg/maths/vec4.h>

namespace easir {

struct SemanticGroup {
    int         id;
    std::string name;
    std::array<float, 3> color;  // RGB [0..1]
    std::vector<std::string> nodes;  // short node names
    bool        permanent = false;   // true for "Unassigned"
};

/// A user-created node carved from a parent mesh node by face selection.
struct CustomNodeDef {
    std::string name;               // e.g., "custom_1"
    std::string parent;             // short name of the parent mesh node
    std::vector<uint32_t> faces;    // face indices in the parent's index buffer
};

/// A child asset reference — a separate mesh file attached at a named joint.
/// Stored in the parent's semantic map JSON under the "children" array.
struct ChildAssetRef {
    std::string assetPath;          // relative (to parent JSON dir) or absolute
    std::string jointName;          // globally-unique within the spacecraft tree
    std::array<double, 3> localPosition    = {0.0, 0.0, 0.0};
    std::array<double, 4> localOrientation = {0.0, 0.0, 0.0, 1.0};  // [x,y,z,w]
    /// Optional: rotation pivot in the CHILD's body frame. When non-zero,
    /// rotations happen about (pivot_offset) rather than the mesh origin —
    /// useful for OBJs whose origin isn't at the intended hinge point.
    /// Applied as: matrix = T(localPosition) * R(localOrientation) * T(-pivot_offset).
    std::array<double, 3> pivotOffset      = {0.0, 0.0, 0.0};
};

class SemanticGroupManager {
public:
    /// Initialize with the list of all node short names discovered in the scene.
    /// All nodes start in the "Unassigned" group.
    void init(const std::vector<std::string>& all_node_names,
              const std::filesystem::path& asset_path) {
        m_asset_path = asset_path;
        m_groups.clear();
        m_next_id = 1;

        // Create the permanent "Unassigned" group.
        SemanticGroup unassigned;
        unassigned.id = 0;
        unassigned.name = "Unassigned";
        unassigned.color = {0.5f, 0.5f, 0.5f};
        unassigned.nodes = all_node_names;
        unassigned.permanent = true;
        m_groups.push_back(std::move(unassigned));

        m_all_nodes = all_node_names;
    }

    /// Try to load an existing semantic map JSON. Returns true if loaded.
    bool load() {
        auto json_path = derive_json_path();
        if (!std::filesystem::exists(json_path)) return false;

        std::ifstream ifs(json_path);
        if (!ifs) return false;

        nlohmann::json root;
        try { ifs >> root; } catch (...) { return false; }

        if (!root.contains("classes") || !root["classes"].is_object()) return false;

        // Clear existing groups except Unassigned.
        m_groups.erase(
            std::remove_if(m_groups.begin(), m_groups.end(),
                           [](const SemanticGroup& g) { return !g.permanent; }),
            m_groups.end());

        // Put all nodes back in Unassigned.
        m_groups[0].nodes = m_all_nodes;

        // Load each class.
        for (auto& [class_name, class_def] : root["classes"].items()) {
            std::array<float, 3> color = {1.0f, 0.0f, 1.0f};
            if (class_def.contains("color") && class_def["color"].is_array() &&
                class_def["color"].size() >= 3) {
                color = {
                    class_def["color"][0].get<float>() / 255.0f,
                    class_def["color"][1].get<float>() / 255.0f,
                    class_def["color"][2].get<float>() / 255.0f,
                };
            }

            std::vector<std::string> nodes;
            if (class_def.contains("nodes") && class_def["nodes"].is_array()) {
                for (auto& n : class_def["nodes"]) {
                    nodes.push_back(n.get<std::string>());
                }
            }

            SemanticGroup group;
            group.id = m_next_id++;
            group.name = class_name;
            group.color = color;
            group.nodes = nodes;
            group.permanent = false;
            m_groups.push_back(std::move(group));

            // Remove these nodes from Unassigned.
            for (const auto& n : nodes) {
                auto& un = m_groups[0].nodes;
                un.erase(std::remove(un.begin(), un.end(), n), un.end());
            }
        }

        // Load custom nodes if present.
        m_customNodes.clear();
        if (root.contains("custom_nodes") && root["custom_nodes"].is_object()) {
            for (auto& [cn_name, cn_def] : root["custom_nodes"].items()) {
                CustomNodeDef def;
                def.name = cn_name;
                def.parent = cn_def.value("parent", "");
                if (cn_def.contains("faces") && cn_def["faces"].is_array()) {
                    for (auto& f : cn_def["faces"]) {
                        def.faces.push_back(f.get<uint32_t>());
                    }
                }
                m_customNodes[cn_name] = std::move(def);

                // Add to all_nodes if not already present.
                if (std::find(m_all_nodes.begin(), m_all_nodes.end(), cn_name) == m_all_nodes.end()) {
                    m_all_nodes.push_back(cn_name);
                }

                // Ensure custom node is in Unassigned if not already in a group.
                if (find_node_group(cn_name) < 0) {
                    m_groups[0].nodes.push_back(cn_name);
                }
            }
            EASIR_LOG("[EASIR]   %zu custom nodes loaded\n", m_customNodes.size());
        }

        // Load child asset refs if present.
        m_children.clear();
        if (root.contains("children") && root["children"].is_array()) {
            for (auto& c : root["children"]) {
                ChildAssetRef ref;
                ref.assetPath = c.value("asset_path", "");
                ref.jointName = c.value("joint_name", "");
                if (c.contains("local_position") && c["local_position"].is_array() &&
                    c["local_position"].size() >= 3) {
                    ref.localPosition = {
                        c["local_position"][0].get<double>(),
                        c["local_position"][1].get<double>(),
                        c["local_position"][2].get<double>(),
                    };
                }
                if (c.contains("local_orientation") && c["local_orientation"].is_array() &&
                    c["local_orientation"].size() >= 4) {
                    ref.localOrientation = {
                        c["local_orientation"][0].get<double>(),
                        c["local_orientation"][1].get<double>(),
                        c["local_orientation"][2].get<double>(),
                        c["local_orientation"][3].get<double>(),
                    };
                }
                if (c.contains("pivot_offset") && c["pivot_offset"].is_array() &&
                    c["pivot_offset"].size() >= 3) {
                    ref.pivotOffset = {
                        c["pivot_offset"][0].get<double>(),
                        c["pivot_offset"][1].get<double>(),
                        c["pivot_offset"][2].get<double>(),
                    };
                }
                if (ref.assetPath.empty() || ref.jointName.empty()) {
                    EASIR_LOG("[EASIR]   WARN: skipping child with missing asset_path or joint_name\n");
                    continue;
                }
                EASIR_LOG("[EASIR]   child: joint='%s' asset='%s' pos=(%f,%f,%f) quat=(%f,%f,%f,%f)\n",
                          ref.jointName.c_str(), ref.assetPath.c_str(),
                          ref.localPosition[0], ref.localPosition[1], ref.localPosition[2],
                          ref.localOrientation[0], ref.localOrientation[1],
                          ref.localOrientation[2], ref.localOrientation[3]);
                m_children.push_back(std::move(ref));
            }
            EASIR_LOG("[EASIR]   %zu child assets in JSON\n", m_children.size());
        }

        EASIR_LOG("[EASIR] Loaded semantic map: %s (%zu classes)\n",
                    json_path.filename().string().c_str(), m_groups.size() - 1);
        return true;
    }

    /// Check if the save file already exists on disk.
    bool save_file_exists() const { return std::filesystem::exists(derive_json_path()); }

    /// Get the save file path.
    std::filesystem::path save_path() const { return derive_json_path(); }

    /// Save the current groups to JSON.
    bool save() const {
        auto json_path = derive_json_path();

        nlohmann::json root;
        root["model"] = m_asset_path.filename().string();

        nlohmann::json classes = nlohmann::json::object();
        for (const auto& g : m_groups) {
            if (g.permanent) continue;  // Don't save Unassigned.

            nlohmann::json cls;
            cls["color"] = {
                static_cast<int>(g.color[0] * 255.0f),
                static_cast<int>(g.color[1] * 255.0f),
                static_cast<int>(g.color[2] * 255.0f),
            };
            cls["nodes"] = g.nodes;
            classes[g.name] = cls;
        }
        root["classes"] = classes;

        // Save custom nodes if any.
        if (!m_customNodes.empty()) {
            nlohmann::json customSection = nlohmann::json::object();
            for (const auto& [name, def] : m_customNodes) {
                nlohmann::json cn;
                cn["parent"] = def.parent;
                cn["faces"] = def.faces;
                customSection[name] = cn;
            }
            root["custom_nodes"] = customSection;
        }

        // Save child asset refs only when non-empty (backward compat).
        if (!m_children.empty()) {
            nlohmann::json childrenArr = nlohmann::json::array();
            for (const auto& ref : m_children) {
                nlohmann::json c;
                c["asset_path"] = ref.assetPath;
                c["joint_name"] = ref.jointName;
                c["local_position"]    = ref.localPosition;
                c["local_orientation"] = ref.localOrientation;
                // Only write pivot_offset when non-zero (backward compat).
                if (ref.pivotOffset[0] != 0.0 ||
                    ref.pivotOffset[1] != 0.0 ||
                    ref.pivotOffset[2] != 0.0) {
                    c["pivot_offset"] = ref.pivotOffset;
                }
                childrenArr.push_back(std::move(c));
            }
            root["children"] = std::move(childrenArr);
            EASIR_LOG("[EASIR]   writing %zu child assets to JSON\n", m_children.size());
        }

        std::ofstream ofs(json_path);
        if (!ofs) {
            EASIR_LOG("[EASIR] Error: could not write %s\n", json_path.string().c_str());
            return false;
        }
        ofs << root.dump(2);
        EASIR_LOG("[EASIR] Saved semantic map: %s\n", json_path.filename().string().c_str());
        return true;
    }

    // ----- Group management -----

    int add_group(const std::string& name, std::array<float, 3> color) {
        SemanticGroup g;
        g.id = m_next_id++;
        g.name = name;
        g.color = color;
        g.permanent = false;
        m_groups.push_back(std::move(g));
        return g.id;
    }

    void delete_group(int id) {
        auto it = std::find_if(m_groups.begin(), m_groups.end(),
                               [id](const SemanticGroup& g) { return g.id == id; });
        if (it == m_groups.end() || it->permanent) return;

        // Move nodes back to Unassigned.
        auto& unassigned = m_groups[0].nodes;
        for (auto& n : it->nodes) {
            unassigned.push_back(n);
        }
        m_groups.erase(it);
    }

    /// Assign a node (by short name) to a group. Removes it from its current group.
    void assign_node(const std::string& short_name, int target_group_id) {
        // Remove from current group.
        for (auto& g : m_groups) {
            auto& nodes = g.nodes;
            auto it = std::find(nodes.begin(), nodes.end(), short_name);
            if (it != nodes.end()) {
                nodes.erase(it);
                break;
            }
        }
        // Add to target group.
        for (auto& g : m_groups) {
            if (g.id == target_group_id) {
                g.nodes.push_back(short_name);
                return;
            }
        }
    }

    /// Find which group a node belongs to. Returns group id, or -1.
    int find_node_group(const std::string& short_name) const {
        for (const auto& g : m_groups) {
            for (const auto& n : g.nodes) {
                if (n == short_name) return g.id;
            }
        }
        return -1;
    }

    /// Get group by id (or nullptr).
    SemanticGroup* group_by_id(int id) {
        for (auto& g : m_groups) {
            if (g.id == id) return &g;
        }
        return nullptr;
    }

    const SemanticGroup* group_by_id(int id) const {
        for (const auto& g : m_groups) {
            if (g.id == id) return &g;
        }
        return nullptr;
    }

    /// Get the color for a node (based on its group). Returns auto-color for Unassigned.
    vsg::vec4 color_for_node(const std::string& short_name) const {
        for (const auto& g : m_groups) {
            for (const auto& n : g.nodes) {
                if (n == short_name) {
                    if (g.permanent) {
                        // Unassigned: use auto-color.
                        return auto_color(short_name);
                    }
                    return vsg::vec4{g.color[0], g.color[1], g.color[2], 1.0f};
                }
            }
        }
        return vsg::vec4{1.0f, 0.0f, 1.0f, 1.0f};  // magenta fallback
    }

    std::vector<SemanticGroup>& groups() { return m_groups; }
    const std::vector<SemanticGroup>& groups() const { return m_groups; }

    const std::vector<std::string>& all_nodes() const { return m_all_nodes; }

    // ----- Custom node management -----

    /// Create a custom node from a face selection. Returns the generated name.
    /// Enforces no-overlap: overlapping faces are removed from existing custom nodes.
    std::string create_custom_node(const std::string& parent,
                                    const std::vector<uint32_t>& faces,
                                    const std::string& requested_name = "") {
        std::string name = requested_name.empty()
            ? ("custom_" + std::to_string(m_nextCustomId++))
            : requested_name;
        // Ensure uniqueness.
        while (m_customNodes.count(name) > 0) {
            name = "custom_" + std::to_string(m_nextCustomId++);
        }

        // No-overlap enforcement: remove these faces from existing custom nodes
        // with the same parent.
        std::unordered_set<uint32_t> faceSet(faces.begin(), faces.end());
        std::vector<std::string> toRemove;
        for (auto& [cn_name, cn] : m_customNodes) {
            if (cn.parent != parent) continue;
            cn.faces.erase(
                std::remove_if(cn.faces.begin(), cn.faces.end(),
                               [&](uint32_t f) { return faceSet.count(f) > 0; }),
                cn.faces.end());
            if (cn.faces.empty()) {
                toRemove.push_back(cn_name);
            }
        }
        for (const auto& dead : toRemove) {
            delete_custom_node(dead);
        }

        CustomNodeDef def;
        def.name = name;
        def.parent = parent;
        def.faces = faces;
        m_customNodes[name] = std::move(def);

        // Add to all_nodes and Unassigned group.
        m_all_nodes.push_back(name);
        m_groups[0].nodes.push_back(name);  // Unassigned

        EASIR_LOG("[EASIR] Created custom node '%s' from '%s' (%zu faces)\n",
                    name.c_str(), parent.c_str(), faces.size());
        return name;
    }

    /// Delete a custom node, returning its faces to the parent's ownership.
    void delete_custom_node(const std::string& name) {
        auto it = m_customNodes.find(name);
        if (it == m_customNodes.end()) return;

        // Remove from whichever semantic group it's in.
        for (auto& g : m_groups) {
            auto& nodes = g.nodes;
            nodes.erase(std::remove(nodes.begin(), nodes.end(), name), nodes.end());
        }

        // Remove from all_nodes.
        m_all_nodes.erase(
            std::remove(m_all_nodes.begin(), m_all_nodes.end(), name),
            m_all_nodes.end());

        m_customNodes.erase(it);
        EASIR_LOG("[EASIR] Deleted custom node '%s'\n", name.c_str());
    }

    bool is_custom_node(const std::string& name) const {
        return m_customNodes.count(name) > 0;
    }

    const CustomNodeDef* custom_node(const std::string& name) const {
        auto it = m_customNodes.find(name);
        return it != m_customNodes.end() ? &it->second : nullptr;
    }

    std::vector<const CustomNodeDef*> custom_nodes_for_parent(const std::string& parent) const {
        std::vector<const CustomNodeDef*> result;
        for (const auto& [name, def] : m_customNodes) {
            if (def.parent == parent) result.push_back(&def);
        }
        return result;
    }

    const std::unordered_map<std::string, CustomNodeDef>& custom_nodes() const {
        return m_customNodes;
    }

    // ----- Child asset management (articulation) -----

    const std::vector<ChildAssetRef>& children() const { return m_children; }
    std::vector<ChildAssetRef>& children() { return m_children; }

    void add_child(ChildAssetRef ref) {
        EASIR_LOG("[EASIR] add_child: joint='%s' asset='%s'\n",
                  ref.jointName.c_str(), ref.assetPath.c_str());
        m_children.push_back(std::move(ref));
    }

    bool remove_child(const std::string& jointName) {
        auto it = std::find_if(m_children.begin(), m_children.end(),
                               [&](const ChildAssetRef& r) { return r.jointName == jointName; });
        if (it == m_children.end()) {
            EASIR_LOG("[EASIR] remove_child: joint '%s' not found\n", jointName.c_str());
            return false;
        }
        EASIR_LOG("[EASIR] remove_child: joint='%s' asset='%s'\n",
                  jointName.c_str(), it->assetPath.c_str());
        m_children.erase(it);
        return true;
    }

    /// Extract short name from full vsgXchange node name.
    static std::string extract_short_name(const std::string& full_name) {
        auto last_open = full_name.rfind('[');
        if (last_open == std::string::npos) return full_name;
        auto close = full_name.find(']', last_open + 1);
        if (close == std::string::npos || close <= last_open) return full_name;
        return full_name.substr(last_open + 1, close - last_open - 1);
    }

private:
    std::vector<SemanticGroup> m_groups;
    std::vector<std::string> m_all_nodes;  // all short names
    std::filesystem::path m_asset_path;
    int m_next_id = 1;
    std::unordered_map<std::string, CustomNodeDef> m_customNodes;
    int m_nextCustomId = 1;
    std::vector<ChildAssetRef> m_children;

    std::filesystem::path derive_json_path() const {
        return m_asset_path.parent_path() /
               (m_asset_path.stem().string() + "_semantic_map.json");
    }

    /// Sequential index + golden-ratio auto-color with random session offset.
    /// The random offset ensures the same name gets different colors across sessions,
    /// avoiding confusion when a custom node's auto-color happens to match a group color.
    static vsg::vec4 auto_color(const std::string& name) {
        static std::unordered_map<std::string, int> name_to_index;
        static int next_index = 0;
        // Random hue offset per session (seeded from clock on first call).
        static float hue_offset = []() {
            auto seed = static_cast<unsigned>(
                std::chrono::steady_clock::now().time_since_epoch().count());
            return std::fmod(seed * 0.0000001f, 1.0f);
        }();

        auto it = name_to_index.find(name);
        if (it == name_to_index.end()) {
            name_to_index[name] = next_index++;
            it = name_to_index.find(name);
        }

        constexpr float golden_ratio_conjugate = 0.618033988749895f;
        float h = std::fmod(it->second * golden_ratio_conjugate + hue_offset, 1.0f);
        // HSV to RGB (s=0.85, v=0.95)
        float c = 0.95f * 0.85f;
        float x = c * (1.0f - std::fabs(std::fmod(h * 6.0f, 2.0f) - 1.0f));
        float m = 0.95f - c;
        float r, g, b;
        int sector = static_cast<int>(h * 6.0f) % 6;
        switch (sector) {
            case 0: r = c; g = x; b = 0; break;
            case 1: r = x; g = c; b = 0; break;
            case 2: r = 0; g = c; b = x; break;
            case 3: r = 0; g = x; b = c; break;
            case 4: r = x; g = 0; b = c; break;
            default: r = c; g = 0; b = x; break;
        }
        return vsg::vec4{r + m, g + m, b + m, 1.0f};
    }
};

} // namespace easir
