#pragma once

/**
 * @file draw_call_split.h
 * @brief DrawCallSplitVisitor — splits a VertexIndexDraw into per-custom-node
 *        draw calls with separate materials.
 *
 * Runs after SemanticMaterialVisitor. For each named mesh node that has custom
 * nodes defined in the SemanticGroupManager, this visitor partitions the index
 * buffer and creates separate StateGroup+VID pairs with distinct materials.
 *
 * The original VID is cached for revert/re-split when custom nodes change.
 */

#include "semantic_group_manager.h"

#include <vsg/all.h>

#include <cstdio>
#include <string>
#include <unordered_map>
#include <unordered_set>

namespace easir {

class DrawCallSplitVisitor : public vsg::Visitor {
public:
    using MaterialMap = std::unordered_map<std::string, vsg::ref_ptr<vsg::PhongMaterialValue>>;

    /// @param deepCopy If true, deep-copy vertex data for each subset VID.
    ///   Use true for runtime splits (after initial compile) to avoid GPU buffer conflicts.
    ///   Use false for startup splits (before compile) where lightweight wrappers suffice.
    DrawCallSplitVisitor(const SemanticGroupManager& groupMgr,
                         const MaterialMap& existingMaterials,
                         bool deepCopy = false)
        : m_groupMgr(groupMgr)
        , m_existingMaterials(existingMaterials)
        , m_deepCopy(deepCopy)
    {
        m_shaderSet = vsg::createPhongShaderSet();
    }

    void apply(vsg::Node& node) override { node.traverse(*this); }

    void apply(vsg::Group& group) override {
        push_name(group);
        process_node(group);
        group.traverse(*this);
        pop_name();
    }

    void apply(vsg::MatrixTransform& mt) override {
        push_name(mt);
        process_node(mt);
        mt.traverse(*this);
        pop_name();
    }

    /// Get the material map with all new materials (for live recoloring).
    const MaterialMap& new_materials() const { return m_newMaterials; }

    /// Get the original VIDs (for reverting splits).
    struct OriginalVID {
        vsg::ref_ptr<vsg::StateGroup> stateGroup;
        vsg::ref_ptr<vsg::VertexIndexDraw> vid;
    };
    const std::unordered_map<std::string, OriginalVID>& original_vids() const {
        return m_originalVIDs;
    }

    /// Map of parent-short-name -> original StateGroup (for external revert caches).
    using OriginalVIDMap = std::unordered_map<std::string, vsg::ref_ptr<vsg::StateGroup>>;

    /// Bytes of vertex data deep-copied during this split (runtime only).
    size_t deep_copy_bytes() const { return m_deepCopyBytes; }

private:
    const SemanticGroupManager& m_groupMgr;
    const MaterialMap& m_existingMaterials;
    vsg::ref_ptr<vsg::ShaderSet> m_shaderSet;
    std::vector<std::string> m_nameStack;
    MaterialMap m_newMaterials;
    std::unordered_map<std::string, OriginalVID> m_originalVIDs;
    bool m_deepCopy = false;
    size_t m_deepCopyBytes = 0;  // cumulative deep-copy memory

    void push_name(vsg::Object& obj) {
        std::string name;
        if (obj.getValue("name", name) && !name.empty()) {
            m_nameStack.push_back(std::move(name));
        } else {
            m_nameStack.push_back({});
        }
    }

    void pop_name() {
        if (!m_nameStack.empty()) m_nameStack.pop_back();
    }

    static std::string extract_short_name(const std::string& full_name) {
        auto last_open = full_name.rfind('[');
        if (last_open == std::string::npos) return full_name;
        auto close = full_name.find(']', last_open + 1);
        if (close == std::string::npos || close <= last_open) return full_name;
        return full_name.substr(last_open + 1, close - last_open - 1);
    }

    void process_node(vsg::Group& group) {
        if (m_nameStack.empty() || m_nameStack.back().empty()) return;

        std::string shortName = extract_short_name(m_nameStack.back());
        auto customNodes = m_groupMgr.custom_nodes_for_parent(shortName);
        if (customNodes.empty()) return;

        // Find the StateGroup child containing a VertexIndexDraw.
        vsg::StateGroup* targetSG = nullptr;
        vsg::VertexIndexDraw* targetVID = nullptr;
        size_t sgChildIdx = 0;

        for (size_t i = 0; i < group.children.size(); ++i) {
            auto* sg = dynamic_cast<vsg::StateGroup*>(group.children[i].get());
            if (!sg) continue;
            for (auto& child : sg->children) {
                auto* vid = dynamic_cast<vsg::VertexIndexDraw*>(child.get());
                if (vid) {
                    targetSG = sg;
                    targetVID = vid;
                    sgChildIdx = i;
                    break;
                }
            }
            if (targetVID) break;
        }

        if (!targetSG || !targetVID) return;

        // Cache the original for revert.
        if (m_originalVIDs.find(shortName) == m_originalVIDs.end()) {
            m_originalVIDs[shortName] = {
                vsg::ref_ptr<vsg::StateGroup>(targetSG),
                vsg::ref_ptr<vsg::VertexIndexDraw>(targetVID)
            };
        }

        // Extract the index buffer.
        auto* idxData = targetVID->indices->data.get();
        std::vector<uint32_t> allIndices;
        if (auto* u16 = dynamic_cast<const vsg::ushortArray*>(idxData)) {
            allIndices.reserve(u16->size());
            for (size_t i = 0; i < u16->size(); ++i)
                allIndices.push_back(static_cast<uint32_t>(u16->at(i)));
        } else if (auto* u32 = dynamic_cast<const vsg::uintArray*>(idxData)) {
            allIndices.reserve(u32->size());
            for (size_t i = 0; i < u32->size(); ++i)
                allIndices.push_back(u32->at(i));
        } else {
            return;  // unknown index format
        }

        uint32_t totalFaces = static_cast<uint32_t>(allIndices.size() / 3);

        // Build set of all claimed faces.
        std::unordered_set<uint32_t> claimedFaces;
        for (const auto* cn : customNodes) {
            for (uint32_t f : cn->faces) {
                if (f < totalFaces) claimedFaces.insert(f);
            }
        }

        // Extract VertexInputState from the existing pipeline.
        vsg::ref_ptr<vsg::VertexInputState> vertexInput;
        for (auto& sc : targetSG->stateCommands) {
            auto bgp = sc.cast<vsg::BindGraphicsPipeline>();
            if (bgp && bgp->pipeline) {
                for (auto& ps : bgp->pipeline->pipelineStates) {
                    auto vis = ps.cast<vsg::VertexInputState>();
                    if (vis) { vertexInput = vis; break; }
                }
                if (vertexInput) break;
            }
        }

        // Create the splitter group.
        auto splitterGroup = vsg::Group::create();

        // Helper to create a StateGroup + VID for a face subset.
        auto createSubset = [&](const std::vector<uint32_t>& faceIndices,
                                const std::string& nodeName,
                                vsg::vec4 color) {
            if (faceIndices.empty()) return;

            auto newIdxArray = vsg::uintArray::create(
                static_cast<uint32_t>(faceIndices.size() * 3));
            uint32_t idx = 0;
            for (uint32_t f : faceIndices) {
                newIdxArray->at(idx++) = allIndices[f * 3 + 0];
                newIdxArray->at(idx++) = allIndices[f * 3 + 1];
                newIdxArray->at(idx++) = allIndices[f * 3 + 2];
            }

            auto subVID = vsg::VertexIndexDraw::create();
            if (m_deepCopy) {
                // Runtime split: deep-copy vertex data to avoid GPU buffer conflicts.
                for (auto& buf : targetVID->arrays) {
                    if (!buf || !buf->data) continue;
                    auto cloned = buf->data->clone({});
                    auto clonedData = cloned.cast<vsg::Data>();
                    subVID->arrays.push_back(vsg::BufferInfo::create(clonedData));
                    m_deepCopyBytes += buf->data->dataSize();
                }
            } else {
                // Startup split (before compile): lightweight wrappers suffice.
                vsg::DataList arrayData;
                for (auto& buf : targetVID->arrays) {
                    if (buf && buf->data) arrayData.push_back(buf->data);
                }
                subVID->assignArrays(arrayData);
            }
            subVID->assignIndices(newIdxArray);
            subVID->indexCount = static_cast<uint32_t>(newIdxArray->size());
            subVID->instanceCount = 1;

            auto config = vsg::GraphicsPipelineConfigurator::create(m_shaderSet);
            if (vertexInput) {
                for (auto& ps : config->pipelineStates) {
                    if (ps.cast<vsg::VertexInputState>()) { ps = vertexInput; break; }
                }
            }

            auto mat = vsg::PhongMaterialValue::create();
            mat->value().ambient  = vsg::vec4{0.0f, 0.0f, 0.0f, 1.0f};
            mat->value().diffuse  = vsg::vec4{0.0f, 0.0f, 0.0f, 1.0f};
            mat->value().specular = vsg::vec4{0.0f, 0.0f, 0.0f, 1.0f};
            mat->value().emissive = color;
            mat->value().shininess = 0.0f;
            mat->properties.dataVariance = vsg::DYNAMIC_DATA;
            config->assignDescriptor("material", mat);
            config->init();

            auto newSG = vsg::StateGroup::create();
            config->copyTo(newSG->stateCommands);
            newSG->addChild(subVID);
            splitterGroup->addChild(newSG);

            m_newMaterials[nodeName] = mat;
        };

        // 1. Create subsets for each custom node.
        for (const auto* cn : customNodes) {
            std::vector<uint32_t> validFaces;
            for (uint32_t f : cn->faces) {
                if (f < totalFaces) validFaces.push_back(f);
            }
            vsg::vec4 color = m_groupMgr.color_for_node(cn->name);
            createSubset(validFaces, cn->name, color);
        }

        // 2. Create the remainder subset (unclaimed faces).
        std::vector<uint32_t> remainderFaces;
        for (uint32_t f = 0; f < totalFaces; ++f) {
            if (claimedFaces.count(f) == 0) {
                remainderFaces.push_back(f);
            }
        }
        vsg::vec4 parentColor = m_groupMgr.color_for_node(shortName);
        createSubset(remainderFaces, shortName, parentColor);

        // Replace the original StateGroup with the splitter group.
        group.children[sgChildIdx] = splitterGroup;

        EASIR_LOG("[EASIR] Split '%s': %zu custom nodes + remainder (%zu faces)\n",
                    shortName.c_str(), customNodes.size(), remainderFaces.size());
    }
};

} // namespace easir
