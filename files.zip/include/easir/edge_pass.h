#pragma once

/**
 * @file edge_pass.h
 * @brief Post-process edge detection pass for silhouette/crease/semantic edges.
 *
 * Reads the depth buffer from an offscreen scene render and applies edge
 * detection, outputting edges as line_color on background_color.
 */

#include <vsg/all.h>
#include "config.h"

namespace easir {

/**
 * @brief Creates a post-process render subgraph for edge detection.
 *
 * Returns a StateGroup containing a full-screen triangle with an edge
 * detection fragment shader that samples the provided depth image.
 *
 * @param depthImageView  Depth image from the offscreen scene pass (must have SAMPLED_BIT).
 * @param renderModes     Render mode config (edge_* parameters).
 * @param width           Depth image width in pixels.
 * @param height          Depth image height in pixels.
 * @return A scene subgraph, or nullptr on failure.
 */
vsg::ref_ptr<vsg::Node> createEdgeDetectionPass(
    vsg::ref_ptr<vsg::ImageView> depthImageView,
    const RenderModesConfig& renderModes,
    uint32_t width,
    uint32_t height);

} // namespace easir
